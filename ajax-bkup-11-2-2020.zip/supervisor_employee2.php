<?php
require_once('../config/config.php');

$select_client = "select `emp_ids` from tbl_supervisors where id='".$_REQUEST[supervisor_id]."'";
$client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
mysqli_data_seek($client_data,0);
$employee_id = explode(',',$dtaClnt['emp_ids']);
if( mysqli_num_rows($client_data) > 0 ) {
    $dtaClnt = mysqli_fetch_assoc($client_data);
    foreach($employee_id as $this_id) {
        $customer ="select `first_name` from tbl_users where user_id='".$this_id."'";
        $customer_data = mysqli_query($con, $customer) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($customer_data,0);
        $customers = mysqli_fetch_assoc($customer_data);
        //print_r($customers['first_name']);
    }//die;

    $message='{"status":"success","msg":"List of employees","response_data":'.json_encode($response_data).'}';
}else{
    $message='{"status":"failure","msg":"There is no employees associated with this ca"}';
}


echo $message; die();
?>

