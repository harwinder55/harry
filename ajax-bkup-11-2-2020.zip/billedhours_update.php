<?php
require_once('../config/config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 //print_r($_REQUEST);die;
    $_REQUEST['in_time'] = str_replace(':','.',$_REQUEST['in_time']);
    $_REQUEST['out_time'] = str_replace(':','.',$_REQUEST['out_time']);
    $query = "Update tbl_timesheet_data Set sick_hours ='".$_REQUEST['sick_hours']."' ,in_time ='".$_REQUEST['in_time']."',out_time ='".$_REQUEST['out_time']."',per_diem ='".$_REQUEST['per_diem']."',billed_hours ='".$_REQUEST['billed_hours']."',special_notes ='".$_REQUEST['special_notes']."' where data_id =".$_REQUEST['data_id']."";

            if (mysqli_query($con,$query) === TRUE) {
                $_SESSION['message'] = 'Billed hours updated successfully';
                //header('location:'.MAIN_URL.'billed-reports.php');
            }
            else{
                $_SESSION['message'] = 'Some Error Occurs!';
                //header('location:'.MAIN_URL.'billing.php');
            }
}
?>