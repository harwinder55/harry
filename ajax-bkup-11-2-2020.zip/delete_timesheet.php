<?php
require_once('../config/config.php');

// $response_data = array();


if(isset($_REQUEST["data_id"]) && $_REQUEST["delete"] =="true"){
	mysqli_query($con,"DELETE FROM tbl_timesheet_data WHERE data_id =".$_REQUEST["data_id"]);
	$message='{"status":"success","msg":"Timesheet entry has been deleted.","response_data":""}';
}else{
	$message='{"status":"success","msg":"Please retry.","response_data":""}';
}
echo $message; die();
?>