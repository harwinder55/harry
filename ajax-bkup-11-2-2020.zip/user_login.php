<?php
require_once('../config/config.php');

$emp_id=$_REQUEST['emp_id'];
$password=$_REQUEST['password'];
$_SESSION['emp_id'] = $emp_id;

$sql="select * from tbl_users where emp_no='".$emp_id."'";
$data=mysqli_query($con,$sql) or die('Problem in line 10');
$row_count=mysqli_num_rows($data);
$message='';
if($row_count>0) {
    $row=mysqli_fetch_assoc($data);
    if($_REQUEST['emp_id']==$row['emp_no']) {
        if($_REQUEST['emp_id']==$row['emp_no']&&$_REQUEST['password']==$row['password']) {
            if($row['status']!=0) {
                $_SESSION['user_type'] = 'user';
                foreach($row as $userDataKey => $userDataValue) {
                    $_SESSION[$userDataKey] = $userDataValue;
                }
                $message='{"status":"success","msg":"Welcome '.$_SESSION['name'].'"}';
            }
            else {
                $message='{"status":"failure","msg":"User Not Active"}';
            }
        } else {
            $message='{"status":"failure","msg":"Invalid Password"}';
        }
    }
} else{
    $message='{"status":"failure","msg":"User not exist"}';
}
echo $message; die();