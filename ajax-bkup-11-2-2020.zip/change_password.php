<?php
require_once('../config/config.php');
$user_details  =  (array)json_decode($_REQUEST['data']);



if($_SESSION['user_type']=='Admin') {

$check_current_password = mysqli_query($con,"Select password from tbl_admin where user_id='".$_SESSION[user_id]."' AND password='".$user_details[current_password]."'");

} else if($_SESSION['user_type']=='Supervisor') {

	 $check_current_password = mysqli_query($con,"Select password from tbl_supervisors where login_id ='".$_SESSION[login_id]."' AND password='".$user_details[current_password]."'");

} else {

	$check_current_password = mysqli_query($con,"Select password from tbl_users where user_id ='".$_SESSION[user_id]."' AND password='".$user_details[current_password]."'");
}


$count = mysqli_num_rows($check_current_password);
if($count>0){

	if($_SESSION['user_type']=='Admin') {

    $update_password="UPDATE `tbl_admin` SET `password`='".$user_details[new_password]."' WHERE `user_id`='".$_SESSION[user_id]."'";

} else if($_SESSION['user_type']=='Supervisor') {

	$update_password="UPDATE `tbl_supervisors` SET `password`='".$user_details[new_password]."' WHERE `login_id`='".$_SESSION[login_id]."'";

} else {

	$update_password="UPDATE `tbl_users` SET `password`='".$user_details[new_password]."' WHERE `user_id`='".$_SESSION[user_id]."'";

}
    if (mysqli_query($con,$update_password) === TRUE) {
        echo "success";
    }

}
else{
    echo "incorrect";

}
