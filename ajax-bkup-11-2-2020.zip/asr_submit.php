<?php
require_once '../config/config.php';
require_once '../admin-v2/inc/functions.php';
$user_details = (array) json_decode($_REQUEST['data']);
//print_r($user_details);
$status = 'New in progress';
$params = array();
if ($_REQUEST['action'] == 'submit') {
    $status = 'Submitted';
    $params[] = "submitted_at='" . getUTCDatetime() . "'";
    $params[] = "submitted_user_type='" . $_SESSION['user_type'] . "'";
}

unset($_REQUEST['action']);
$asr_id = $_REQUEST['asr_id'];

unset($_REQUEST['asr_id']);


$select_asr = "select * from tbl_asr where id='" . $asr_id . "'";
$asr_data = mysqli_query($con, $select_asr) or die('Something Problem in DB Connection or Query');
$asr_details = mysqli_fetch_assoc($asr_data);


$select_client = "select * from tbl_client where id='" . $asr_details['client_id'] . "'";
$client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
$client_details = mysqli_fetch_assoc($client_data);



$select_am = "select * from tbl_admin where user_id='" . $asr_details['account_manager_id'] . "'";
$am_data = mysqli_query($con, $select_am) or die('Something Problem in DB Connection or Query');
$am_details = mysqli_fetch_assoc($am_data);


$select_contract = "select * from tbl_contract where id='" . $asr_details['contract_id'] . "'";
$contract_data = mysqli_query($con, $select_contract) or die('Something Problem in DB Connection or Query');
$contract_details = mysqli_fetch_assoc($contract_data);

foreach (array_keys($_REQUEST) as $key) {
    $params[] = $key . "='" . str_replace("'","&#39;",$_REQUEST[$key]) . "'";
}
$params[] = "modified_at='" . getUTCDatetime() . "', modified_by='" . $_SESSION['user_id'] . "', status='" . $status . "'";
$query = "update tbl_asr set " . implode(",", $params) . " where id = '" . $asr_id . "'";
if (mysqli_query($con, $query) === true) {
    $asrNotificationsSent = 0;
    if(isset($client_details['asr_notifications_sent']) && $client_details['asr_notifications_sent']){
        $asrNotificationsSent = intval($client_details['asr_notifications_sent']);
    }
    if($asrNotificationsSent < 2) {
        $msg = 'Dear '.$client_details['contact_one_name'].',<br><br>';

        $msg .= 'Your Account Manager '.$am_details['first_name'].' '.$am_details['last_name'].' from Neptune Security Services Inc. has just completed an Account Status Update Report with regards to the Contract '.$contract_details['name'].' with us. Your satisfaction is our utmost priority and we encourage you to take a few minutes to review your Account Manager’s comments. You can do so by clicking on this link <a href="'.PATH.'/admin-v2/forms/asr/view-details.php?asr_id='.$asr_id.'" >'.PATH.'/admin-v2/forms/asr/view-details.php?asr_id='.$asr_id.'</a>';
        $msg .= '<br>We believe that open communication is an important part of achieving excellence in client satisfaction, therefore, you will receive an email with a link for the first two Account Status Update Reports that your Account Manager completes. We encourage you to review them as soon as you receive these emails. <b>If you have any questions or concerns about the contents of the Reports, we encourage you to either:</b><br><br>';
        $msg .= 'a) fill in a Customer Feedback Report with your concerns on our Customer Care Portal,<br>';
        $msg .= 'b) or, send us an email at customer.relations@neptune-security.com<br>';
		$msg .= '<br>You will always have access to all completed Account Status Update Reports and Customer Feedback Reports on the Portal<br>';
		$msg .= '<br>To access the customer care portal please login into https://p1.neptunetimesheets.com using the Credentials that have been sent to you by your Account Manager';
		$msg .= '<br><br>';
        $msg .= '<br>If you experience any technical difficulties, please call Operations Manager or General Manager at 1-855-445-8048.<br>';
        $msg .= '<br>We thank you for your time. Your partnership means the world to us!<br>';
        $msg .= '<br>';
        $msg .= 'Sincerely,<br>';
        $msg .= 'Neptune’s Operation team';

        
        $msg = wordwrap($msg, 70);

       // $select_om = "select * from tbl_users where user_id='" . $am_details['master_id'] . "' LIMIT 1";

       /// $om_data = mysqli_query($con, $select_om) or die('Something Problem in DB Connection or Query');
       // $om_details = mysqli_fetch_assoc($om_data);


        $to = $client_details['contact_one_email'];
       

       $subject = 'New Account Status Update Report ASR received - Contract '.$contract_details['name'].' for the period of '.$asr_details['period'];
     
        $toArr = array();
        $toArr[] = array('email'=>$to,'name'=>$client_details['contact_one_name']);
       // $toArr[] = array('email'=>'ranjeet.infome@gmail.com','name'=>$client_details['contact_one_name']);
        $ccArr = array();
        $ccArr[] = array('email'=>'customer.relations@neptune-security.com','name'=>'Neptune Customer Relations');
    
        $ccArr[] = array('email'=>$am_details['email'],'name'=>$am_details['first_name']);
    
        //if($om_details){
         //   $ccArr[] = array('email'=>$om_details['email'],'name'=>$om_details['first_name']);
       // }
        
        
        //send_email($toArr, $ccArr, $subject, $msg);

        $asrNotificationsSent++;

        $queryClientUpdate = "update tbl_client set asr_notifications_sent=" .$asrNotificationsSent. " where id = '" . $client_details['id']. "'";
        if (mysqli_query($con, $queryClientUpdate) === true) {
        }


        $countEmailcounter = "select email_counter from tbl_client where id = '" . $client_details['id']. "'";
        $counterdetail = mysqli_query($con, $countEmailcounter) or die('Something Problem in DB Connection or Query');
        $ec_details = mysqli_fetch_assoc($counterdetail);

        if($ec_details['email_counter'] < 2){
            $counter = $ec_details['email_counter'] +1;
            $queryClientemaicounter = "update tbl_client set email_counter = ".$counter." where id = '" . $client_details['id']. "'";
        mysqli_query($con, $queryClientemaicounter);
        }
      
        
        


    }
    echo "success";
    logger($_SESSION["user_id"], strtolower($_SESSION["user_type"]), "ASR Submit", "Submitted ASR " . $asr_id, $insert_user);

} else {
    echo "Something went wrong : <br>" . mysqli_error($con);
}