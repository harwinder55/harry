<?php
require_once('../config/config.php');

$response_data = array();


$all_sites_employee_setting_file = "/var/www/html/cache/all_sites_employee_setting";
$all_sites_employees = file_get_contents($all_sites_employee_setting_file);     
$user_ids = json_decode($all_sites_employees,true);

if(in_array($_REQUEST["user_id"], $user_ids) ){
        $select_client = "SELECT ts.client_id,ts.id,ts.site_name, ts.latitude, ts.longitude FROM tbl_sites ts WHERE 1=1";
}else{
        $select_user_assigned_site_id	=	"SELECT assigned_site_id FROM `tbl_users` WHERE user_id =".$_REQUEST["user_id"]." LIMIT 1";
        $select_user_assigned_site_id_data = mysqli_query($con, $select_user_assigned_site_id) or die('Something Problem in DB Connection or Query');
        $select_user_assigned_site_ids = mysqli_fetch_assoc($select_user_assigned_site_id_data);
        // print_r($select_user_assigned_site_ids);
	$select_client = "SELECT ts.client_id,ts.id,ts.site_name, ts.latitude, ts.longitude FROM tbl_sites ts WHERE ts.id IN (".$select_user_assigned_site_ids["assigned_site_id"].")";
}

	$client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
	$client_details = mysqli_fetch_all($client_data,MYSQLI_ASSOC);
        
        foreach($client_details as $index=>$client_detail){
            if( $client_detail["latitude"]==null ){
                unset($client_details[$index]["latitude"]);
                unset($client_details[$index]["longitude"]);
            }
        }
        
	$response_data["client_details"] = $client_details;
	// print_r($price_details);
	
	
	
	$select_price = "select * from tbl_price";
	$price_data = mysqli_query($con, $select_price) or die('Something Problem in DB Connection or Query');
	$price_details = mysqli_fetch_all($price_data,MYSQLI_ASSOC);
	$response_data["price_details"] = $price_details;
	 // print_r($price_details);
	
$message='{"status":"success","msg":"Employee site and price list","response_data":'.json_encode($response_data).'}';
echo $message; die();
?>