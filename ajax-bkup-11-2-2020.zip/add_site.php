<?php
require_once('../config/config.php');
require_once('../admin-v2/inc/functions.php');
$user_details  =  (array)json_decode($_REQUEST['data']);
//print_r($user_details);
$insert_site="INSERT INTO `tbl_sites`(site_id, site_name, latitude, longitude) VALUES('".$user_details['site_id']."','".$user_details['site_name']."','".$user_details['latitude']."','".$user_details['longitude']."')";
if (mysqli_query($con,$insert_site) === TRUE) {
    echo "success";
    logger($_SESSION["user_id"],strtolower($_SESSION["user_type"]),"Site add","added a new site ".$user_details['site_name'],$insert_user);

} else { 
    echo "Something went wrong : <br>" . mysqli_error($con);
}

