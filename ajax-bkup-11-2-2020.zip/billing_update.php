<?php
require_once('../config/config.php');

$date = date('Y-m-d h:i:s');
$invoices = "Select id from tbl_invoice order by `id` desc";
$resu = mysqli_query($con,$invoices);
$invoice = mysqli_fetch_assoc($resu);

if(isset($invoice))
    $invoice_id = $invoice['id'] +1;
else
    $invoice_id = 1;

$result = str_pad($invoice_id, 4, '0', STR_PAD_LEFT);
$invoice_num = 'INV-'.date('m').'/'.date('y').'/'.$result;

$query = "INSERT INTO tbl_invoice(invoice_num,invoice_date) VALUES('".$invoice_num."','".$date."')";
if (mysqli_query($con, $query) === TRUE) {
    foreach ($_REQUEST['data_id'] as $item) {
        $query1 = "Update tbl_timesheet_data Set billed = 1, invoice_num = '" . $invoice_num . "',invoice_date = '" . $date . "'  where data_id =" . $item . "";
        if (mysqli_query($con, $query1) === TRUE) {
            $_SESSION['message'] = 'Record billed successfully';
            // $_SESSION['data'] = $_REQUEST['data_id'];
            header('location:' . MAIN_URL . 'billed-reports.php');
        }

    }
}



//print_r($result);die;


?>