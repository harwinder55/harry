<?php
require_once('../config/config.php');

//error_log("view timesheet = ". json_encode($_REQUEST) );

$response_data = array();
if(isset($_REQUEST["date_range"]) && isset($_REQUEST["user_id"]))
	{ 
		$view_timesheet_date_range = explode("_",$_REQUEST["date_range"]);
		
		$date1 = date_create($view_timesheet_date_range[0]);
		$date2 = date_create($view_timesheet_date_range[1]);
		$diff = date_diff($date1,$date2);
		$days = $diff->format("%a");

		$dates = date_range($view_timesheet_date_range[0], date('Y-m-d', strtotime($view_timesheet_date_range[0] . "+ 13 days")), "+1 day", "Y-m-d");
		
		$active_employee_query = "SELECT * FROM tbl_users tu WHERE tu.user_id =".$_REQUEST["user_id"]." LIMIT 1";
		
	$active_employee_result = mysqli_query($con,$active_employee_query);
		while($user_basic_details = mysqli_fetch_assoc($active_employee_result)) 
		{ 
			$user_value = array();
			$select     = "select * from tbl_timesheet_data where user_id='" . $user_basic_details["user_id"] . "' AND survey_handset_datetime BETWEEN '".$view_timesheet_date_range[0]."' AND '".$view_timesheet_date_range[1]."'";
			$user_timesheet_data = mysqli_query($con, $select) or die('Something Problem in DB Connection or Query'. mysqli_error($con));
                        $user_timesheet_details = mysqli_fetch_all($user_timesheet_data,MYSQLI_ASSOC);
                        
                        $response_data = array();
                        
                        foreach ($user_timesheet_details as $key=>$user_timesheet_detail){
                            $response_data[ $user_timesheet_detail["survey_handset_datetime"] ][] = $user_timesheet_detail;
                        }
                        
		}	
	}
	$response = array();  
	$response['status'] ="success";
	$response['msg'] ="Add-edit your timesheet.";
        $response['locked'] ="false";

        
        $locking_base_date = strtotime("1 day", strtotime($view_timesheet_date_range[1]));
        $locking_base_date = date("Y-m-d H:i:s", strtotime('+10 hours',$locking_base_date));
        
        if ($view_timesheet_date_range[1] != "" && strtotime($locking_base_date) < time()) {
            $response['locked'] ="true";            
            $response['msg'] ="Your timesheet is locked.";
        }
        
        $period = new DatePeriod(
            new DateTime($view_timesheet_date_range[0]),
            new DateInterval('P1D'),
            new DateTime($view_timesheet_date_range[1])
       );
        
       $dayName = array(
            'Mon' => 'Lundi/ Monday',
            'Tue' => 'Mardi/ Tuesday',
            'Wed' => 'Mercredi/ Wednesday',
            'Thu' => 'Jeudi/ Thursday',
            'Fri' => 'Vendredi/ Friday',
            'Sat' => 'Samedi/ Saturday',
            'Sun' => 'Dimanche/ Sunday'
        ); 
        
        
       foreach ($period as $key => $value) {
            $response['response_data'][$key]['data'] =$response_data[$value->format('Y-m-d')];
            $response['response_data'][$key]['date'] =$value->format('Y-m-d');
            $response['response_data'][$key]['day'] = $dayName[$value->format('D')];

        } 
        
echo json_encode($response);
?>