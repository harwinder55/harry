<?php
require_once('../config/config.php');


$query = "select * from tbl_timesheet_range where status=1 GROUP BY start_date ORDER BY id DESC";

$result = mysqli_query($con,$query);

if( mysqli_num_rows($result) > 0 ){
	$response_data = array();
	$doc_count =0;
	while($data_timesheet_range = mysqli_fetch_assoc($result)) {
		$response_data[$doc_count]["timesheet_date_range_key"] = $data_timesheet_range["start_date"].'_'.$data_timesheet_range["end_date"];
		$response_data[$doc_count]["timesheet_date_range_value"] = date("d-M-y",strtotime($data_timesheet_range["start_date"])).' to '.date("d-M-y",strtotime($data_timesheet_range["end_date"]));
		
		$doc_count ++ ;
	}
	
	$message='{"status":"success","msg":"Date range list","response_data":'.json_encode($response_data).'}';
}else{
	$message='{"status":"failure","msg":"'.$user_type.' is not active, Please contact administrator."}';
}	


echo $message; die();
?>