<?php
require_once('../config/config.php');


	$vacation_insert_query="INSERT INTO  `tbl_vacations`(user_id,vacation_from_date,vacation_to_date) VALUES ('".$_REQUEST['user_id']."','".date('Y-m-d', strtotime($_REQUEST['vacation_from_date']))."','".date('Y-m-d', strtotime($_REQUEST['vacation_to_date']))."')";
	
if( $_REQUEST['user_id']!="" && $_REQUEST['vacation_from_date']!="" && $_REQUEST['vacation_to_date']!="" && $_REQUEST['first_name']!="" && $_REQUEST['last_name']!=""){
	if(mysqli_query($con,$vacation_insert_query)){
		$supervisor_details = mysqli_query($con,'SELECT first_name, email FROM tbl_supervisors WHERE FIND_IN_SET('.$_REQUEST["user_id"].',emp_ids)');
	
		while($supervisor_data = mysqli_fetch_assoc($supervisor_details)) { 
		
				$to = $supervisor_data["email"];
				$subject = "New Vacation application";
				
				$txt = '<table width="100%" border="0" cellspacing="0" cellpadding="0" align="">
								  <tr><td height="55"></td></tr>
								  <tr>
									<td align="left">
									  <div class="contentEditableContainer contentTextEditable">
										<div class="contentEditable" align="">
										  <h2 >Hi there,</h2>
										</div>
									  </div>
									</td>
								  </tr>

								  <tr><td height="15"> </td></tr>

								  <tr>
									<td align="left">
									  <div class="contentEditableContainer contentTextEditable">
										<div class="contentEditable" align="">
										  <p >
											One of the employee <strong>'.$_REQUEST["first_name"].' '.$_REQUEST["last_name"].'</strong> has applied for a new vacation from '.date('Y-m-d', strtotime($_REQUEST['vacation_from_date'])).' to '.date('Y-m-d', strtotime($_REQUEST['vacation_to_date'])).'. 
											<br>
											<br>
											Please login to <a href="https://neptunetimesheets.com">neptunetimesheets.com</a> and then open this link <a href="<?php echo MAIN_URL; ?>vacations.php?user_id%5B%5D='.$_REQUEST["user_id"].'">open</a> to see all the applied vacations by this employee.
											<br>
											<br>
											Cheers!!!
											<br>
											<span style="color:#222222;">Neptune Tech Team</span>
										  </p>
										</div>
									  </div>
									</td>
								  </tr>

								  <tr><td height="55"></td></tr>

								  
								  <tr><td height="20"></td></tr>
								</table>';
				
				// $headers = "From: no-reply@neptunetimesheets.com" . "\r\n" .
				// "CC: skbca2@gmail.com";

				$headers = "From: no-reply@neptunetimesheets.com\r\n";
				//$headers .= "Reply-To: ". strip_tags($_POST['req-email']) . "\r\n";
				$headers .= "CC: arif390@@gmail.com\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
		
				echo mail($to,$subject,$txt,$headers);
		
		}
	  $message='{"status":"success","msg":"Vacations submitted successfully.","response_data":"-"}';
	}else{
		$message='{"status":"failure","msg":"Please try again."}';
	}	
}else{
	$message='{"status":"failure","msg":"Please retry with all values."}';
}	


echo $message; die();
?>