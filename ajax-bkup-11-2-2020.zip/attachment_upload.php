<?php
//timesheet_date_range, attachment_title, attachment_file,user_id
require_once('../config/config.php');

// echo ("attachment_upload.php api called");

$myfile = fopen(PATH."/ajax/newfile.txt", "w") or die("Unable to open file!");
echo $txt = json_encode($_FILES);
fwrite($myfile, $txt);
echo $txt = json_encode($_REQUEST);
fwrite($myfile, $txt);
fclose($myfile);


if( $_REQUEST['user_id']!="" && $_REQUEST['timesheet_date_range']!="" && $_REQUEST['attachment_title']!=""){

	if(isset($_FILES['attachment_file'])) {
      $errors= array();
      $file_name = $_FILES['attachment_file']['name'];
      $file_size =$_FILES['attachment_file']['size'];
      $file_tmp =$_FILES['attachment_file']['tmp_name'];
      $file_type=$_FILES['attachment_file']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['attachment_file']['name'])));
    }
   
	$vacation_insert_query="INSERT INTO  `tbl_attachments`(user_id,attachment_title,attachment_type,timesheet_date_range) VALUES ('".$_REQUEST['user_id']."', '".$_POST['attachment_title']."','".$file_ext."','".$_POST['timesheet_date_range']."')";
	
	if(mysqli_query($con,$vacation_insert_query)){
		if(empty($errors)==true){
			
			if (!file_exists(PATH.'/cache/attachments/'.$_REQUEST["user_id"])) {
				mkdir(PATH.'/cache/attachments/'.$_REQUEST["user_id"], 0777, true);
			}
			move_uploaded_file($file_tmp,PATH.'/cache/attachments/'.$_REQUEST["user_id"].'/'.(mysqli_insert_id($con)).'-'.$_POST['timesheet_date_range'].'.'.$file_ext);
			
			$message='{"status":"success","msg":"Attachment Listing of ::: '.$response_data[0]["employee_name"].'","response_data":'.json_encode($response_data).'}';
		}	
	}else{
		$message='{"status":"failure","msg":"Please retry."}';
	}
}else{
	$message='{"status":"failure","msg":"Invalid arguments."}';
}
echo $message; die();
?>