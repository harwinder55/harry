<?php
require_once('../config/config.php');
require_once('../admin-v2/inc/functions.php');
$user_details  =  (array)json_decode($_REQUEST['data']);
error_reporting(1);
$insert_user="INSERT INTO `tbl_location`(client_id,site_id,site_name) VALUES('".$user_details['client_id']."','".$user_details['site_id']."','".$user_details['site_name']."')";
if (mysqli_query($con,$insert_user) === TRUE) {
    echo "success";
    logger($_SESSION["user_id"],strtolower($_SESSION["user_type"]),"New site add","New site added successfully ".$user_details['site_name'],$insert_user);
    return "success";
}else{
    return "Something went wrong : <br>" . mysqli_error($con);
}

?>