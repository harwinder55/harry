<?php
require_once('../config/config.php');
require_once('../admin-v2/inc/functions.php');
$user_details  =  (array)json_decode($_REQUEST['data']);
error_reporting(1);
	$insert_user="INSERT INTO `tbl_price`(prime_type,price) VALUES('".$user_details['prime_rate']."','".$user_details['rate']."')";
	if (mysqli_query($con,$insert_user) === TRUE) {
        echo "success";
        logger($_SESSION["user_id"],strtolower($_SESSION["user_type"]),"Site price add","Site price added successfully ".$user_details['rate'],$insert_user);
        return "success";
	}else{
		return "Something went wrong : <br>" . mysqli_error($con);
	}
	
	