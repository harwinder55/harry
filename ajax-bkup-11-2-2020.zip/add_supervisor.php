<?php
require_once('../config/config.php');
require_once('../admin-v2/inc/functions.php');
$user_details  =  (array)json_decode($_REQUEST['data']);

if(!empty($user_details['login_id'])){


			$login_id = $user_details['login_id'];

		$select_sup	=	"SELECT * FROM `tbl_supervisors` WHERE login_id ='$login_id'";
        $select_sup_data = mysqli_query($con, $select_sup) or die('Something Problem in DB Connection or Query');
        $select_sup_ids = mysqli_fetch_assoc($select_sup_data);
        if(count($select_sup_ids)>0){

				$message='{"status":"exists","msg":"login id already exists"}';
				//echo $message; 
				echo "exists";
				die();

        }  else {

$insert_user="INSERT INTO `tbl_supervisors`(login_id,password,mobile_no,email,first_name,last_name
) VALUES('".$user_details['login_id']."','".$user_details['password']."','".$user_details['mobile_no']."','".$user_details['email']."' ,'".$user_details['first_name']."','".$user_details['last_name']."')";
if (mysqli_query($con,$insert_user) === TRUE) {
    echo "success";
    logger($_SESSION["user_id"],strtolower($_SESSION["user_type"]),"supervisor add","added a new supervisor ".$user_details['first_name']." ".$user_details['last_name'],$insert_user);
}
else if (mysqli_errno($con) == 1062) {
    echo "duplicate";
}else{
    echo "Something went wrong : <br>" . mysqli_error($con);
}

}
}

