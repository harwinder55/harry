<?php
require_once('../config/config.php');
require_once('../admin-v2/inc/functions.php');
$user_details  =  (array)json_decode($_REQUEST['data']);


if(!empty($user_details['emp_number'])){

		$empno = $user_details['emp_number'];

		$select_emp	=	"SELECT * FROM `tbl_users` WHERE emp_no ='$empno'";
        $select_emp_data = mysqli_query($con, $select_emp) or die('Something Problem in DB Connection or Query');
        $select_emp_ids = mysqli_fetch_assoc($select_emp_data);
        if(count($select_emp_ids)>0){

				$message='{"status":"exists","msg":"emp no already exists"}';
				//echo $message; 
				echo "exists";
				die();

        }  else {


$insert_user = "INSERT INTO `tbl_users`(emp_no,first_name,last_name,phone,mobile,email,address1,address2,city,province,postal_code,dob,class,class_from_date,password,assigned_site_id,bsp_number,expiry_date) VALUES('".$user_details['emp_number']."','".$user_details['first_name']."','".$user_details['last_name']."','".$user_details['phone']."' ,'".$user_details['mobile']."','".$user_details['email']."','".$user_details['address1']."','".$user_details['address2']."','".$user_details['city']."','".$user_details['province']."','".$user_details['postal_code']."','".$user_details['dob']."','".$user_details['classes']."','".$user_details['class_from_date']."','".$user_details['pass_create_open_file']."','".$user_details['assigned_site_id']."','".$user_details['bsp_number']."','".$user_details['expiry_date']."')";
if (mysqli_query($con,$insert_user) === TRUE) {
    $last_id = $con->insert_id;
    $insert_user_class="INSERT INTO `tbl_employee_class`(user_id,class,class_assign_date) VALUES('".$last_id."','".$user_details['classes']."','".$user_details['class_from_date']."')";
}
if (mysqli_query($con,$insert_user_class) === TRUE) {
    echo "success";
    logger($_SESSION["user_id"],strtolower($_SESSION["user_type"]),"employee add","added a new employee ".$user_details['first_name']." ".$user_details['last_name'],$insert_user);
}
else if (mysqli_errno($con) == 1062) {
    echo "duplicate";
} else {
    echo "Something went wrong : <br>" . mysqli_error($con);
}
}


}
