<?php
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

$ch = new redis_class();

class redis_class{
	private $redis, $connected = 0;


	function __construct(){
                
            
        }

	public function flushAll()
            {
                if($this->connected == 0) $this->connect();
                return $this->redis->flushAll();
            }
        function set_hmset($hmset_key,$value){
		if($this->connected == 0) $this->connect();
	        $this->redis->hMSet('hmset:'.$hmset_key, array(json_encode($value) ) );  
//                echo strtotime($value["survey_handset_datetime"])."<br>";
                return $this->redis->zAdd('date', strtotime($value["survey_handset_datetime"]), $hmset_key);        
	}
	
        function get_hmset_range_data($start_date,$end_date){
		if($this->connected == 0) $this->connect();    
                $hash_keys = $this->redis->zRangeByScore('date', $start_date, $end_date); /* array('val0' => 0, 'val2' => 2, 'val10' => 10)*/
                
                $this->redis->multi();
                foreach($hash_keys as $hashKey) {
                    $this->redis->HGETALL("hmset:".$hashKey);
                }  
                return $results = $this->redis->exec();
        }
            
        function set_value($name,$value){
		if($this->connected == 0) $this->connect();
		return $this->redis->set($name, $value);
	}
	
        function remove_key($key){
		if($this->connected == 0) $this->connect();		
		$info = $this->redis->info();
                if(version_compare($info['redis_version'],'4.0.0') == -1){ // less
                    return $this->redis->delete($key);
                }elseif(version_compare($info['redis_version'],'4.0.0') == 0){ // equal
                    return $this->redis->unlink($key);
                }elseif(version_compare($info['redis_version'],'4.0.0') == 1){ // greater
                    return $this->redis->unlink($key);
                }
	}
        
	function get_value($name){
		if($this->connected == 0) $this->connect();
		return $this->redis->get($name);
	}
	function get_keys($key_name){
		if($this->connected == 0) $this->connect();
		return $this->redis->keys($key_name);
	}
	
	
	/** Check key / value exist or not used for duration **/
	function check_value($name){
		if($this->connected == 0) $this->connect();		
		return $this->redis->EXISTS($name);
	}	

	function connect(){
		$this->redis = new Redis();
		$server_endpoint = "127.0.0.1";
		$server_port = 6379;
		$this->redis->pconnect($server_endpoint, $server_port);
//		$this->redis->auth(REDIS_AUTH);
		$this->redis->select("1");  
		$this->connected = 1;
	}
}