<?php
$limit = ini_get('memory_limit');
ini_set('memory_limit', -1);
require_once('/var/www/html/config/config.php');
require_once('redis_class.php');


//delete all redis data first
$ch->flushAll();




$select     = "select * from tbl_timesheet_data";  

$user_data = mysqli_query($con, $select) or die('Something Problem in DB Connection or Query');


$counter = 0;

while ($rows = mysqli_fetch_assoc($user_data)) {

    $counter++;        
    $ch->set_hmset($rows["data_id"],$rows); 
    
//    $user_value[date('Y-m-d', strtotime($rows['survey_handset_datetime']))][] = $rows;
    
//    HMSET courseassignmentdata:1 name sujeet course basics date "12 june 2018"
//    HMSET courseassignmentdata:2 name sujeet1 course basics1 date "19 june 2018"
//    ZADD entry_date 138 "1"
//    ZADD entry_date 139 "2"
//    ZRANGEBYSCORE entry_date 1 2
//    
//    
//    HGETALL courseassignmentdata:3
//    
//    
//    
//    echo json_encode( $rows );
    //$ch->set_value( "data_".$rows["data_id"]."_".$rows["user_id"]."_".$rows["survey_handset_datetime"] , json_encode( $rows ));
    
}



echo $counter ." keys has been created";





//$list = $ch->get_keys("*");




//print_r($list);
ini_set('memory_limit', $limit);