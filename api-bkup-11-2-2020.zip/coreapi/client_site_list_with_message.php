<?php
header('Access-Control-Allow-Origin: *');
header("Content-Type: application/json;charset=utf-8");
require_once('../config/config.php');

$latest_app_version = 'v6';
$survey_data = array();

$response = array();
$response["status"] = "success";
$client_array = array();
$client_array[1] = array("client_name" => "Tata",
    "site_list" => array(
        "1"=>"patna",
        "2"=>"Shimla",
    )
);
$client_array[4] = array("client_name" => "CI",
    "site_list" => array(
        "1121"=>"Badarpur",
        "28989"=>"Noida",
        "12738"=>"FBD",
    )
);
$response["data"] = $client_array;
echo json_encode($response);die;
if(isset($_REQUEST['user_id']) && $_REQUEST['user_id'] !== "") {
    $user_id = $_REQUEST['user_id'];
    $user_survey_query="SELECT survey_id FROM tbl_user_survey WHERE user_id='".mysqli_real_escape_string($con,$user_id)."' GROUP BY survey_id";
    $user_survey_data=mysqli_query($con,$user_survey_query) or die('Problem '.mysqli_error());
    $user_survey_row_count=mysqli_num_rows($user_survey_data);

    if(isset($_REQUEST['mobile_app_version']) && $_REQUEST['mobile_app_version'] !== "") {
        $mobile_app_version = $_REQUEST['mobile_app_version'];
        if($mobile_app_version == $latest_app_version){//user have the latest APK
            if($user_survey_row_count > 0) {
                while($user_survey=mysqli_fetch_array($user_survey_data,MYSQLI_ASSOC)){
                    $survey_id = $user_survey['survey_id'];
                    $survey_data["form_fields"][$survey_id] = trim(file_get_contents(PATH.'/cache/survey_fields/'.$user_survey['survey_id']),' ');
                }
            }
        } else {
            //using the old apk//download the latest APK //logout
            if($user_survey_row_count > 0) {
                while($user_survey=mysqli_fetch_array($user_survey_data,MYSQLI_ASSOC)){
                    $survey_id = $user_survey['survey_id'];
                    $survey_data["form_fields"][$survey_id] = '<script>alert("This app is outdated, Please update!");logout();</script>';
                }
            }
            $script_to_be_executed = "update";
        }
    } else {
        //download the latest APK //logout
        if($user_survey_row_count > 0) {
            while($user_survey=mysqli_fetch_array($user_survey_data,MYSQLI_ASSOC)){
                $survey_id = $user_survey['survey_id'];
                $survey_data["form_fields"][$survey_id] = '<script>alert("This app is outdated, Please update!");logout();</script>';
            }
        }
    }
}else {
    //download the latest APK //logout
}

if($script_to_be_executed == "logout") {
    $survey_data["script_to_be_executed"] = '<script>if(localStorage.getItem("login") == 1){logout();}</script>';
}else if($script_to_be_executed == "update") {
    $survey_data["script_to_be_executed"] = '<script>if(localStorage.getItem("login") == 1){logout();}</script><div class="alert alert-info" role="alert" style="position: fixed; z-index: 9999; width: 100%; height: 100%;"><h1>You are using an outdated APK.<br> Please download and install new APK.</h1><a class="btn btn-danger" href="http://52.220.111.24/apk/hcl-android-'.$latest_app_version.'.apk" target="_blank">Download APK</a> </div>';
}
echo json_encode( $survey_data );