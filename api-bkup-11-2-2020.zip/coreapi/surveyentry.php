<?php
$message;
$user_id = $_REQUEST['user_id'];
$form_data = explode('&',(json_decode($_REQUEST['survey_form_field'])->survey_form_field));

if (!file_exists(PATH.'/cache/log/'.date('Y-m-d').'/'.$user_id)) {
    mkdir(PATH.'/cache/log/'.date('Y-m-d').'/'.$user_id, 0777, true);
}
foreach($form_data as $survey_form_field_temp) {
    $survey_form_field_temp = explode("=",$survey_form_field_temp);
    if($_REQUEST[$survey_form_field_temp[0]]=="survey_handset_datetime") continue;
    $_REQUEST[$survey_form_field_temp[0]] = $survey_form_field_temp[1];
}
file_put_contents(PATH.'/cache/log/'.date('Y-m-d').'/log',json_encode($_REQUEST).PHP_EOL , FILE_APPEND);
$response = array();

$insert_query = "INSERT INTO tbl_timesheet_data (user_id,survey_handset_datetime,client_id,site_id,in_time,out_time,premium_id) 
						VALUES ('".$_REQUEST['user_id']."',
						'".str_replace("+"," ",str_replace("%3A",":",$_REQUEST['survey_handset_datetime']))."',
						'".$_REQUEST['client_id']."',
						'".$_REQUEST['site_id']."',
						'".str_replace("%3A",":",$_REQUEST['in_time'])."',
						'".str_replace("%3A",":",$_REQUEST['out_time'])."',
						'".$_REQUEST['premium_id']."'						
						)";

file_put_contents(PATH.'/cache/log/'.date('Y-m-d').'/log',$insert_query.PHP_EOL , FILE_APPEND);
if(mysqli_query($con,$insert_query)) {
    $response["survey_data_id"] = mysqli_insert_id($con);
    $response["status"] = "success";
    $response["msg"] = "inserted";
}else {
    $response["status"] = "failure";
    $response["msg"] = "not inserted";

}
echo json_encode($response);
?>