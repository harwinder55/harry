<?php

$user_id	= $_REQUEST['user_id'];
$survey_id	= $_REQUEST['survey_id'];
$new_image_name = $user_id.'_'.$survey_id.'_'.$_FILES["file"]["name"];
$status = move_uploaded_file($_FILES["file"]["tmp_name"], PATH."/cache/log/surveyphoto/".$new_image_name);
echo $new_image_name;