<?php
header('Access-Control-Allow-Origin: *');
require_once('../../config/config.php');
if(isset($_REQUEST['user_id']) && $_REQUEST['user_id']!='') {
    $user_id = $_REQUEST['user_id'];
    $attandance_details = mysqli_query($con,"SELECT ts.survey_name, COUNT(tsa.survey_id) as survey_count, DATE(tsa.attandence_date) FROM `tbl_survey_attandence` tsa,`tbl_survey` ts  WHERE tsa.survey_id = ts.survey_id AND  tsa.user_id =$user_id AND DATE(tsa.attandence_date) = CURRENT_DATE GROUP BY tsa.survey_id ORDER BY tsa.attandence_id DESC");

    if(($attandance_details->num_rows) >= 1) {
        echo '<h5 class="text-center"><b>Summary of '.date('d-m-Y(h:i A)').'</b></h5>
						<table class="table table-bordered "><thead>
							<tr>
								<th>Survey</th>
								<th>Count</th>
							</tr>
				</thead><tbody>';
        while ($attandance_detail = mysqli_fetch_assoc($attandance_details)) {
            echo '<tr>
								<td>'.$attandance_detail['survey_name'].'</td>
								<td>'.$attandance_detail['survey_count'].'</td>
							</tr>';
        }
        echo '</tbody></table>';
    }else {
        echo 'API error: No data for this user.';
    }
}else {
    echo 'API error: Invalid userid.<br> Please take a screenshot and send to admin';
}