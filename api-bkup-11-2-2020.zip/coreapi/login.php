<?php
require_once('../../config/config.php');
$login_id=$_REQUEST['login_id'];
$password=$_REQUEST['password'];
$mobile_app_version = $_REQUEST['mobile_app_version'];

$login_query="select * from tbl_users where phone='".mysqli_real_escape_string($con,$login_id)."'";
$login_query_data=mysqli_query($con,$login_query) or die('Problem in line 6'.mysqli_error());
$login_row_count=mysqli_num_rows($login_query_data);
$message = array();
if($login_row_count > 0) {
    $login_data=mysqli_fetch_array($login_query_data,MYSQLI_ASSOC );
    if($_REQUEST['login_id'] == $login_data['phone']) {
        if($_REQUEST['login_id'] == $login_data['phone'] && $_REQUEST['password'] == $login_data['password']) {
            mysqli_query($con,"UPDATE tbl_users SET mobile_app_version='".$mobile_app_version."' , last_login='".date('Y-m-d H:i:s')."' , device_details='".$_SERVER['HTTP_USER_AGENT']."' WHERE phone='".mysqli_real_escape_string($con,$login_id)."'");
            if($login_data['status'] != 0) {
                $message["status"] = "success";
                $message["user_data"] = array();
                foreach($login_data as $user_data_key => $user_data_value) {
                    $message["user_data"][$user_data_key] = $user_data_value;
                }
            }
            else {
                $message["status"] = "failure";
                $message["msg"] = "User Not Active";
            }
        }
        else {
            $message["status"] = "failure";
            $message["msg"] = "Invalid ID/Password";
        }
    }
}
else {
    $message["status"] = "failure";
    $message["msg"] = "User not exist";
}
echo json_encode($message); die();
