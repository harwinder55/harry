<?php
$message = '';
$userid = $_REQUEST['userid'];
$survey_id = $_REQUEST['survey_id'];
if($userid != ""){
    $tbl_users_sql="select * from tbl_users where userid='$userid' and status=1";
    $tbl_users_data=mysqli_query($con,$tbl_users_sql) or die('Problem in line 6'.mysql_error());
    $tbl_users_row=mysqli_num_rows($tbl_users_data);
    $message='';
    if($tbl_users_row > 0) {
        $tbl_user_survey_sql="select * from tbl_user_survey where	user_id='$userid' and survey_id='$survey_id' and user_survey_status=1";
        $tbl_user_survey_data=mysqli_query($con,$tbl_user_survey_sql) or die('Problem in line 6'.mysql_error());
        $tbl_user_survey_row=mysqli_num_rows($tbl_user_survey_data);
        if($tbl_user_survey_row > 0) {
            $tbl_survey_sql="select * from tbl_survey where survey_id='$survey_id' and survey_status=1";
            $tbl_survey_data=mysqli_query($con,$tbl_survey_sql) or die('Problem in line 6'.mysql_error());
            $tbl_survey_row=mysqli_num_rows($tbl_survey_data);
            $message='';

            if($tbl_survey_row > 0) {
                $tbl_survey_meta_sql="select * from tbl_survey_meta where survey_id='$survey_id' and survey_frm_field_status=1";
                $tbl_survey_meta_data=mysqli_query($con,$tbl_survey_meta_sql) or die('Problem in line 6'.mysql_error());
                $tbl_survey_meta_row=mysqli_num_rows($tbl_survey_meta_data);
                $a=1;
                $message.='{"survey": [';
                while($tbl_survey_meta_data_row = mysqli_fetch_array($tbl_survey_meta_data)) {
                    $survey_meta_id=$tbl_survey_meta_data_row['survey_meta_id'];
                    $survey_frm_field_name=$tbl_survey_meta_data_row['survey_frm_field_name'];
                    $survey_frm_field_type =$tbl_survey_meta_data_row['survey_frm_field_type'];
                    $survey_frm_field_placeholder =$tbl_survey_meta_data_row['survey_frm_field_placeholder'];
                    $survey_frm_field_validation_rule=$tbl_survey_meta_data_row['survey_frm_field_validation_rule'];
                    $survey_frm_field_validation_msg=$tbl_survey_meta_data_row['survey_frm_field_validation_msg'];
                    $message.='{
								"survey_meta_id": "'.$survey_meta_id.'",
								"survey_frm_field_name": "'.$survey_frm_field_name.'",
								"survey_frm_field_type": "'.$survey_frm_field_type .'",
								"survey_frm_field_placeholder": "'.$survey_frm_field_placeholder.'",
								"survey_frm_field_validation_rule": "'.$survey_frm_field_validation_rule .'",
								"survey_frm_field_validation_msg": "'.$survey_frm_field_validation_msg.'"
								}';


                    if($tbl_survey_meta_row != $a) {
                        $message.=',';
                    }
                    $a++;
                }
                $message.=']}';
            }
            else {
                $message.='{"status":"failure","msg":"This survey not Active"}';
            }
        }
        else {
            $message.='{"status":"failure","msg":"This survey not Active for you "}';

        }
    }
    else {
        $message.='{"status":"failure","msg":"User Not Active"}';

    }
}
else {
    $tbl_survey_meta_sql="select * from tbl_survey_meta where survey_id='$survey_id'";
    $tbl_survey_meta_data=mysqli_query($con,$tbl_survey_meta_sql) or die('Problem in line 6'.mysql_error());
    $tbl_survey_meta_row=mysqli_num_rows($tbl_survey_meta_data);
    $a=1;
    $message.='{"survey": [';
    while($tbl_survey_meta_data_row=mysqli_fetch_array($tbl_survey_meta_data)) {
        $survey_meta_id=$tbl_survey_meta_data_row['survey_meta_id'];
        $survey_frm_field_name=$tbl_survey_meta_data_row['survey_frm_field_name'];
        $survey_frm_field_type =$tbl_survey_meta_data_row['survey_frm_field_type'];
        $survey_frm_field_placeholder =$tbl_survey_meta_data_row['survey_frm_field_placeholder'];
        $survey_frm_field_validation_rule=$tbl_survey_meta_data_row['survey_frm_field_validation_rule'];
        $survey_frm_field_validation_msg=$tbl_survey_meta_data_row['survey_frm_field_validation_msg'];
        $message.='{
								"survey_meta_id": "'.$survey_meta_id.'",
								"survey_frm_field_name": "'.$survey_frm_field_name.'",
								"survey_frm_field_type": "'.$survey_frm_field_type .'",
								"survey_frm_field_placeholder": "'.$survey_frm_field_placeholder.'",
								"survey_frm_field_validation_rule": "'.$survey_frm_field_validation_rule .'",
								"survey_frm_field_validation_msg": "'.$survey_frm_field_validation_msg.'"
								}';


        if($tbl_survey_meta_row != $a) {
            $message.=',';
        }
        $a++;

    }
    $message.=']}';
}