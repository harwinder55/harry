<?php
header('Access-Control-Allow-Origin: *'); 
date_default_timezone_set('asia/kolkata');
require_once('../config/config.php');
		
$apilist =array('login','surveydetails','surveyentry','surveyfromfields');
$apitype = $_REQUEST['apitype'];
in_array($apitype,$apilist);
$message;
//if(isset($apitype))
if($apitype!='')
{
		if(in_array($apitype,$apilist)){
				require_once('coreapi/'.$apitype.'.php');
		}
		else{
		$message='{"status":"failure","msg":"API type not exist"}';
		}
}
else
{
		$message='{"status":"failure","msg":"API type is blank please fill the API type"}';
}
		echo $message;