<?php
require_once('config_p1.php');

$query  = "DELETE FROM tbl_vacations WHERE id='".$_REQUEST[emp_id]."'";
if ($con->query($query) === TRUE) {
    $quer2 = "Select * from tbl_vacations WHERE id='".$_REQUEST[emp_id]."'";
    $res_clnt = mysqli_query($con, $quer2);
    $row_clnt = mysqli_fetch_assoc($res_clnt);
    $query1 = "Select * from tbl_users WHERE user_id='".$row_clnt['user_id']."'";
    $result = mysqli_query($con, $query1);
    $user_details = mysqli_fetch_assoc($result);
    if ($con->query($query1) === TRUE) {
        logger($row_clnt['user_id'], "Employee vacation delete", "Employee vacation deleted successfully " . $user_details['first_name'] . " " . $user_details['last_name'], $query);
    }
    $_SESSION['message'] = 'Record deleted successfully';
} else {
    $_SESSION['message'] = 'Error deleting record: '.$con->error;
}
header('location:'.MAIN_URL.'vacations.php');
?>