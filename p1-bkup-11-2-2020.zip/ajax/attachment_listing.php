<?php
require_once('config_p1.php');


$query = "SELECT tu.emp_no, tu.first_name, tu.last_name, tu.phone, ta.* FROM tbl_attachments ta, tbl_users tu WHERE ta.`user_id`=tu.`user_id` AND ta.user_id = ".$_REQUEST["user_id"]." ORDER BY ta.id DESC";

$result = mysqli_query($con,$query);

if( mysqli_num_rows($result) > 0 ){
	$response_data = array();
	$doc_count =0;
	while($rows = mysqli_fetch_assoc($result)) {
		$response_data[$doc_count]["employee_name"] = $rows['emp_no']."-".$rows['first_name'] ." ".$rows['last_name'];
		$response_data[$doc_count]["attachment_title"] = $rows["attachment_title"];
		$timesheet_date_range = explode("_",$rows['timesheet_date_range']);
		$response_data[$doc_count]["timesheet_date_range"] = date( 'j-M-Y',strtotime($timesheet_date_range[0]))." to ".date( 'j-M-Y',strtotime($timesheet_date_range[1]));
		$response_data[$doc_count]["attached_on"] = date( 'j-M-Y',strtotime($rows['created']));
		$response_data[$doc_count]["attachment_url"] = PATH."/cache/attachments/".$rows['user_id']."/".$rows['id']."-".$rows['timesheet_date_range'].".".$rows['attachment_type'];
		$doc_count ++ ;
	}
	
	$message='{"status":"success","msg":"Attachment Listing of ::: '.$response_data[0]["employee_name"].'","response_data":'.json_encode($response_data).'}';
}else{
	$message='{"status":"failure","msg":"Seems that there is not any attachment upload by you for the selected date range."}';
}	


echo $message; die();
?>