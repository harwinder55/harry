<?php
require_once('config_p1.php');

$query = "select `emp_ids`,`site_id` from tbl_supervisors where id='".$_REQUEST[supervisor_id]."'";
$result = mysqli_query($con, $query);
$message= array();
if( mysqli_num_rows($result) > 0 ) {
    $employee_data = mysqli_fetch_assoc($result);
    $employee_ids = explode(',',$employee_data['emp_ids']);
    $response_data = array();
    $sites_data = array();
    $doc_count =0;
    foreach($employee_ids as $employee_id) {
        $query ="select `user_id`,`emp_no`,`first_name` from tbl_users where user_id='".$employee_id."'";
        $result = mysqli_query($con, $query) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($result,0);
        $customers = mysqli_fetch_assoc($result);
        $response_data[$doc_count] = $customers;
        $doc_count ++ ;
    }
    $site_ids = explode(',',$employee_data['site_id']);
    foreach($site_ids as $site_id) {
        $query = "select `id`,`site_id`,`site_name` from tbl_sites where id='".$site_id."'";
        $result = mysqli_query($con, $query) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($result,0);
        $sites = mysqli_fetch_assoc($result);
        $sites_data[$doc_count] = $sites;
        $doc_count ++ ;
    }
    $message=[
        'status' => 'success',
        'msg' =>'list of employees associated with this category',
        'response_data' => json_encode($response_data),
        'sites_data' =>json_encode($sites_data)
    ];
} else {
    $message=[
        'status' =>'failure',
        'msg' =>'There is no employees associated with this ca'
    ];
}
echo(json_encode($message));die;
?>




