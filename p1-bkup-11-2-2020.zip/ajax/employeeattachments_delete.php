<?php
require_once('config_p1.php');

$query  = "DELETE FROM tbl_attachments WHERE id='".$_REQUEST[emp_id]."'";
if ($con->query($query) === TRUE) {
    $_SESSION['message'] = 'Record deleted successfully';
} else {
    $_SESSION['message'] = 'Error deleting record: '.$con->error;
}
header('location:'.MAIN_URL.'employee-attachments.php');
?>