<?php
require_once('config_p1.php');
$payload  =  $_REQUEST;
//$ip = $_SERVER['REMOTE_ADDR'];
//$result = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
////print_r ($result);
////error_log($ip."=". $result->lat."=".$result->lon);//48.156,17.142
//
//
//
////Detect special conditions devices
//$iPod    = stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
//$iPhone  = stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
//$iPad    = stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
//$Android = stripos($_SERVER['HTTP_USER_AGENT'],"Android");
//$webOS   = stripos($_SERVER['HTTP_USER_AGENT'],"webOS");
//
////do something with this information
//if( $iPod || $iPhone || $iPad ){
//    //browser reported as an iPhone/iPod touch -- do something here
//    $payload['punch_out_location']= $result->lat.",".$result->lon;
//}else {
//    //Android device
//    //$payload['punch_out_location']= $result->lat."=".$result->lon;
//}

//error_reporting(1);
if( $payload['punch_out_location']!="" && $payload['punch_in_id']!="" ){
//    $insert_query = "INSERT INTO `naptune_timesheet`.`tbl_attendance` (`user_id`, `site_id`, `punch_in_location`, `punch_in_datetime`) VALUES ('".$payload['user_id']."', '".$payload['site_id']."', '".$payload['punch_in_location']."', '".date("Y-m-d H:i:s")."')";
    $insert_query = "UPDATE `tbl_attendance` SET `punch_out_location`='".$payload['punch_out_location']."', `punch_out_datetime`='".date("Y-m-d H:i:s")."' WHERE `id`='".$payload['punch_in_id']."'";
    mysqli_query($con,$insert_query);
    if (mysqli_affected_rows($con) == 1 ) {
        $response_data = array();
        $response_data["punchout_time"] =  date("Y-m-d H:i A");
        $response_data["punchout_location"] = $payload['punch_out_location'];
        $message='{"status":"success","msg":"punch out done.","response_data":'.json_encode($response_data).'}';
    }else{
        $message='{"status":"error","msg":"Please retry.","response_data":""}';
    }
}else{
        $message='{"status":"error","msg":"invalid data.","response_data":""}'; 
}
echo $message;
?>