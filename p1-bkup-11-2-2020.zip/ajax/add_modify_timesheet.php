<?php
require_once('config_p1.php');

//error_log("add-edit timesheet = ". json_encode($_REQUEST) );

if (isset($_REQUEST) && $_REQUEST["in_time"] != '') {
        $_REQUEST['in_time'] = ltrim($_REQUEST['in_time'], '0');
        $_REQUEST['out_time'] = ltrim($_REQUEST['out_time'], '0');
		
	$_REQUEST['base_rate'] = $_REQUEST['base_rate_1'];
	if(isset($_REQUEST['base_rate_2']) && $_REQUEST['base_rate_2']!=""){
		$_REQUEST['base_rate'] .= ".".$_REQUEST['base_rate_2'];
	}else{
		$_REQUEST['base_rate'] .= ".00";
	}
	
	$_REQUEST['site_prime'] = $_REQUEST['site_prime_1'];
	if(isset($_REQUEST['site_prime_2']) && $_REQUEST['site_prime_2']!=""){
		$_REQUEST['site_prime'] .= ".".$_REQUEST['site_prime_2'];
	}else{
		$_REQUEST['site_prime'] .= ".00";
	}
	
        if($_REQUEST["timesheet_action"] == "update"){
		$insert_update_query = "UPDATE tbl_timesheet_data SET 
		site_id=" . $_REQUEST['site_id'] . ",
		in_time='" . $_REQUEST['in_time'] . "',
		out_time='" . $_REQUEST['out_time'] . "',
		site_prime='" . $_REQUEST['site_prime'] . "',
		premium_id='" . $_REQUEST['primt_type'] . "',
		base_rate='" . $_REQUEST['base_rate'] . "',
		special_notes='" . $_REQUEST['notes'] . "',
		source='Updated on app' ,
		sick_hours='" . $_REQUEST['sick_hours'] . "',
		per_diem='" . $_REQUEST['per_diem'] . "',
		WHERE data_id = '" . $_REQUEST['data_id'] . "'";
	}else{
            if(!isset($_REQUEST['survey_handset_datetime']) || $_REQUEST['survey_handset_datetime']=="" || $_REQUEST['survey_handset_datetime']=="undefined"){
                $_REQUEST['survey_handset_datetime'] = date("Y-m-d");
            }
		$insert_update_query = "insert into tbl_timesheet_data(user_id,site_id,in_time,out_time,site_prime,premium_id,base_rate,special_notes,survey_handset_datetime,source,sick_hours,per_diem) VALUES(" . $_REQUEST['user_id'] . "," . $_REQUEST['site_id'] . ",'" . $_REQUEST['in_time'] . "','" . $_REQUEST['out_time'] . "','" . $_REQUEST['site_prime'] . "','" . $_REQUEST['primt_type'] . "','" . $_REQUEST['base_rate'] . "','" . $_REQUEST['notes'] . "','" . $_REQUEST['survey_handset_datetime'] . "', 'Added on app' ,'" . $_REQUEST['sick_hours'] . "','" . $_REQUEST['per_diem'] . "')";
	}
	
	
   $data = mysqli_query($con, $insert_update_query);// or die('Something Problem in DB Connection or Query');
   
   
    if (mysqli_errno($con) == 1062) {
        $message='{"status":"success","msg":"Duplicate entry.","response_data":""}';
    }else{
        $message='{"status":"success","msg":"Timesheethas been added/modified.","response_data":""}';
    }

}else{
	$message='{"status":"error","msg":"Please retry.","response_data":""}';
}
echo $message; die();
?> 