<?php
require_once('config_p1.php');


$query = "SELECT tu.emp_no, tu.first_name, tu.last_name, tu.phone, tv.* FROM tbl_vacations tv, tbl_users tu WHERE tv.`user_id`=tu.`user_id` AND tv.user_id =".$_REQUEST["user_id"]."";

$result = mysqli_query($con,$query);

if( mysqli_num_rows($result) > 0 ){
	$response_data = array();
	$doc_count =0;
	while($rows = mysqli_fetch_assoc($result)) {
		// $response_data[$doc_count]["employee_name"] = $rows['emp_no']."-".$rows['first_name'] ." ".$rows['last_name'];
		$response_data[$doc_count]["request_date"] = date( 'j-M-Y',strtotime($rows['created']));
		$response_data[$doc_count]["vacation_from_date"] = date( 'j-M-Y',strtotime($rows['vacation_from_date']));
		$response_data[$doc_count]["vacation_to_date"] = date( 'j-M-Y',strtotime($rows['vacation_to_date']));
		$response_data[$doc_count]["vacation_days"] = floor( (strtotime($rows['vacation_to_date'])-strtotime($rows['vacation_from_date'])) /(60*60*24))+1;
		$doc_count ++ ;
	}
	
	$message='{"status":"success","msg":"Vacations Listing of ::: '.$response_data[0]["employee_name"].'","response_data":'.json_encode($response_data).'}';
}else{
    	$message='{"status":"success","msg":"Vacations Listing of ::: '.$response_data[0]["employee_name"].'","response_data":'.json_encode($response_data).'}';
//	$message='{"status":"failure","msg":"'.$user_type.' is not active, Please contact administrator."}';
}

echo $message; die();
?>