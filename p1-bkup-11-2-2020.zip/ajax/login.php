<?php
require_once('config_p1.php');
error_log(  json_encode($_REQUEST)  );
$login_id  = $_REQUEST['login_id'];
$password  = $_REQUEST['password'];
$user_type = $_REQUEST['user_type'];

if($user_type == "Admin") {
    $sql="select * from tbl_admin where login_id='".$login_id."' AND password = '".$password."'";
}else if($user_type == "Supervisor") {
    $sql="select * from tbl_supervisors where login_id='".$login_id."' AND password = '".$password."'";
}else if($user_type == "Employee") {
    $sql="select * from tbl_users where emp_no='".$login_id."' AND password = '".$password."'";
}else {
    echo $message='{"status":"failure","msg":"User not exist"}';die;
}
$data=mysqli_query($con,$sql) or die('Problem in db connection');
$row_count=mysqli_num_rows($data);
$message='';
if($row_count > 0) {
    $response_data = array();
    $row=mysqli_fetch_assoc($data);
    if($row["status"] == 1) {
        foreach($row as $user_data_key => $user_data){
            $_SESSION[$user_data_key]=$user_data;
            if($user_data_key != "" && $user_data !="")
                $response_data[$user_data_key] = $user_data;
        }
        $response_data["first_name"] = "P1- ".$row["first_name"];
        $_SESSION["user_type"] = $user_type;
        $message='{"status":"success","msg":"Welcome '.$response_data['name'].'","response_data":'.json_encode($response_data).'}';
    } else {
        $message='{"status":"failure","msg":"'.$user_type.' is not active, Please contact administrator."}';
    }
} else {
    $message='{"status":"failure","msg":"'.$user_type.' not exist"}';
}
echo $message; die();