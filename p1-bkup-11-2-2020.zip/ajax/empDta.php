<?php
require_once('config_p1.php');
if(!empty($_REQUEST['supervisor_id']))
{
	$query = "select `emp_ids`,`site_id` from tbl_supervisors where id='".$_REQUEST['supervisor_id']."'";
	$result = mysqli_query($con, $query);
	$message= array();
	if( mysqli_num_rows($result) > 0 ) 
	{
		$employee_data = mysqli_fetch_assoc($result);
		$employee_ids = explode(',',$employee_data['emp_ids']);
		$response_data = array();
		$sites_data = array();
		$doc_count =0;
		foreach($employee_ids as $employee_id) 
		{
			$query ="select `user_id`,`first_name`, `emp_no` from tbl_users where user_id='".$employee_id."'";
			$result = mysqli_query($con, $query) or die('Something Problem in DB Connection or Query');
			mysqli_data_seek($result,0);
			$customers = mysqli_fetch_assoc($result);
		?>
		<option value="all">All site</option>
		<option value="<?php echo $customers['user_id'];?>"><?php echo $customers['first_name'].' '.$customers['last_name'];?>(<?php echo $customers['emp_no'];?>)</option>
		<?php
		}  
	} 
} else { echo "val";}
?>




