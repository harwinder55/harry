<?php
ob_start();
include 'inc/header.php';
if ( $_SESSION['user_type'] == 'Employee' ) { //&& (!in_array($_SESSION['user_id'],$_REQUEST['user_id']) || count($_REQUEST['user_id']) != 1) ){
    ob_end_clean();
    header( "location:" . PATH . "" );
    exit;
}
?>
    <div class="content-wrapper" style="min-height: 312px;">
        <section class="content-header">
            <h1 style="">
                Reporting module - Analytics & KPI
                <small>: Form selection</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li><a href="#">Analytics & KPI</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <?php if ( strtolower( $_SESSION['user_type'] ) == 'admin' ) { ?>
                                <div class="col-md-12">

                                    <div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box">
                                    ASR
                                </span>
                                        </div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box"  style="width: 610px;">
                                    <b>Account Status Report:</b> Will measure your contract KPIs for the selected period
                                </span>
                                        </div>
                                        <div style="display:inline-block;">
                                            <a href="<?php echo PATH . '/admin-v2/forms/asr/index.php' ?>"
                                               class="btn btn-small btn-green">View</a>

                                              <!-- <a href="<?php echo PATH . '/admin-v2/forms/asr/asr-archive.php' ?>"
                                               class="btn btn-small btn-green">ASRs Archive</a>-->
                                        </div>

                                    </div>

                                </div>


                               <!-- <div class="col-md-12" style="margin-top:10px;">

                                    <div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box">
                                    CFR
                                </span>
                                        </div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box"  style="width: 610px;">
                                    <b>Client's Feedback Report:</b> Scoring based on your Client's Feedback for the selected
                                    period
                                </span>
                                        </div>
                                        <div style="display:inline-block;">

                                            <a href="<?php echo PATH . 'admin-v2/forms/cfr/index.php' ?>"
                                               class="btn btn-small btn-green">View</a>


                                               <a href="<?php echo PATH . 'admin-v2/forms/cfr/cfr-archive.php' ?>"
                                               class="btn btn-small btn-green">CFRs Archive</a>
                                        </div>

                                    </div>

                                </div>-->

                            <?php } /*else if ( strtolower( $_SESSION['user_type'] ) == 'client' ) { ?>
                                <div>
                            <span class="kpi-item-title-box">
                                ASR
                            </span>
                                    <span class="kpi-item-title-box" style="width: 510px;">
                                <b>Account Status Report:</b> Will measure you contract KPIs for the select period 
                            </span>

                                    <a href="<?php echo PATH . 'admin-v2/forms/asr/index.php' ?>"
                                       class="btn btn-small btn-green" style="min-width: 210px;">View</a>


                                </div>
                                <div>
                            <span class="kpi-item-title-box">
                                CFR
                            </span>
                                    <span class="kpi-item-title-box" style="width: 510px;">
                                <b>Client's Feedback Report:</b> Submit a feedback regarding our services
                            </span>

                                    <a href="<?php echo PATH . 'admin-v2/forms/cfr/index.php?type=system' ?>"
                                       class="btn btn-small btn-green" style="min-width: 210px">Reply to new feedback request</a>
                                    <a href="<?php echo PATH . 'admin-v2/forms/cfr/index.php' ?>"
                                       class="btn btn-small btn-green" style="min-width: 210px">View List or Create New</a>

                                </div>


                            <?php } else if ( strtolower( $_SESSION['user_type'] ) == 'account manager' ) { ?>


                                <div class="col-md-12">

                                    <div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box">
                                    ASR
                                </span>
                                        </div>
                                        <div style="display:inline-block;">
                                <span class="kpi-item-title-box"  style="width: 530px;">
                                    <b>Account Status Report:</b> Will measure your contract KPIs for the selected period
                                </span>
                                        </div>
                                        <div style="display:inline-block;">
                                            <a href="<?php echo PATH . 'admin-v2/forms/asr/index.php' ?>"
                                               class="btn btn-small btn-green">View</a>
                                        </div>

                                    </div>

                                </div>

                            <?php } */?>
                        </div>
                        <hr/>

                    </div>
                </div>
            </div>
    </div>
    <style>
        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #00BCD4 !important;
        }

        .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
            color: #F44336 !important;
        }

        .daterangepicker td.in-range {
            background-color: #e0e0e0;
            border-color: transparent;
            color: #000;
            border-radius: 0;
        }

        .box-header div {
            margin-top: 10px !important;
        }

        .kpi-item-title-box {
            background: lightgray;
            margin-left: 4px;
            font-size: 15px;
            text-align: left;
            padding: 10px;
            display: inline-block;
            vertical-align: middle;
        }

        .btn.btn-small.btn-green {
            padding: 10px 15px;
            display: inline-block;
            vertical-align: middle;
        }
        .btn-green {
    background: #8fd055;
    background-image: initial;
    background-position-x: initial;
    background-position-y: initial;
    background-size: initial;
    background-repeat-x: initial;
    background-repeat-y: initial;
    background-attachment: initial;
    background-origin: initial;
    background-clip: initial;
    background-color: rgb(143, 208, 85);
    margin: 0 5px;
    color: white;
}

        .kpi-item-title-box span {
            color: black;
            font-size: 20px;
            margin: 5px;
        }

        .kpi-item-title-box * {
            margin: 5px;
        }

        .kpi-item-title-box btn:hover {
            color: white !important;
        }

        .kpi-item-title-box a:hover {
            color: white !important;
        }

        .btn:hover {
            color: white !important;
        }
    </style>
<?php include 'inc/footer.php'; ?>