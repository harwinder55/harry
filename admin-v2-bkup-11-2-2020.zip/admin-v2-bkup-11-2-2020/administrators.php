<?php
include('inc/header.php');
if($_GET['admin_id']) {
    echo $delete_sql="UPDATE `tbl_admin` SET `status`=".$_REQUEST["status"]." WHERE `user_id`=".$_GET['admin_id']."";
    mysqli_query($con,$delete_sql);
    logger(	$_SESSION["user_id"],strtolower($_SESSION["user_type"]),"admin 's Profile"," ".$_REQUEST["event"]." an admin profile of  ".$_REQUEST['first_name']." ".$_REQUEST['last_name'],$delete_sql);
}
?>
<div class="content-wrapper" style="min-height: 312px;">
    <section class="content-header">
        <h1 style="">Admin Users<small>#</small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">admin users</a></li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <div class="pull-left">
                            <h2 class="text-success no-margin"></h2>
                        </div>
                        <?php if($_SESSION['admin_type'] != 'Normal Admin'){?>
                            <div class="pull-right">
                                <div class="col-xs-12">
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#add_user"><i class="fa fa-user-plus" aria-hidden="true"></i> Add Admin</button>
                                </div>
                            </div>
                        <?php }?>
                    </div>
                    <div class="box-body">
                        <div class="col-sm-12">
                            <?php
                            $active_users = ' <table id="datatable1" class="table table-striped table-bordered" cellspacing="0" width="100%">';
                            $deactive_users = ' <table id="datatable2" class="table table-striped table-bordered" cellspacing="0" width="100%">';
                            $thead = '<thead>
								<tr>
									<th>Name</th>
									<th>Login ID</th>
									<th>Created on</th>
									<th>Admin type</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>';
                            $active_users .= $thead;
                            $deactive_users .= $thead;
                            $admin_result = mysqli_query($con,"select * from tbl_admin ORDER BY user_id DESC");
                            $activeCount = 1;
                            $deactiveCount = 1;
                            if(mysqli_num_rows($admin_result)!=0) {
                                while($admin_details=mysqli_fetch_array($admin_result)) {
                                    $usersTempRow ='';
                                    $usersTempRow .='<tr class="odd gradeX">';
                                    $usersTempRow .='<td class="col-sm-3">'.$admin_details['first_name'] .' '.$admin_details['last_name'].'</td>';
                                    $usersTempRow .='<td class="col-sm-2">'.$admin_details['login_id'].'</td>';

                                    $usersTempRow .='<td class="col-sm-2">'.date( 'jS M Y',strtotime($admin_details['submit_datetime'])).'</td>';

                                    $usersTempRow .='<td class="col-sm-2">'.$admin_details['admin_type'].'</td>';
                                    // print_r($_SESSION['admin_type']);
                                    // echo "sujeeeeeeeee";
                                    if($_SESSION['admin_type'] == 'Normal Admin') {
                                        $usersTempRow .='<td class="col-sm-2">-</td>';

                                        if($admin_details['status']==1) {
                                            $usersTempRow .='</tr>';
                                            $active_users .= $usersTempRow;
                                            $activeCount++;
                                        } else {
                                            $usersTempRow .='</tr>';
                                            $deactive_users .= $usersTempRow;
                                            $deactiveCount++;
                                        }
                                    } else {
                                        $usersTempRow .='<td class="col-sm-2">
								<a class="btn btn-xs btn-info" href="admin-profile.php?user_id='.$admin_details['user_id'].'"><i class="fa fa-user"></i> Profile</a>';

                                        if($admin_details['status']==1) {
                                            $usersTempRow .=' <a class="btn btn-xs btn-danger btn-activate-deactivate" rel="Deactivate"  href="?admin_id='.$admin_details['user_id'].'&status=0&first_name='.$admin_details['first_name'].'&last_name='.$admin_details['last_name'].'&event=Deactivated">
											<i class="fa fa-times-circle-o"></i> Deactivate
										</a></td>';
                                            $usersTempRow .='</tr>';
                                            $active_users .= $usersTempRow;
                                            $activeCount++;
                                        }else{
                                            $usersTempRow .=' <a class="btn btn-xs btn-success btn-activate-deactivate" rel="Activate" href="?admin_id='.$admin_details['user_id'].'&status=1&first_name='.$admin_details['first_name'].'&last_name='.$admin_details['last_name'].'&event=Activated">
											<i class="fa fa-check-circle-o"></i> Activate
										</a></td>';
                                            $usersTempRow .='</tr>';
                                            $deactive_users .= $usersTempRow;
                                            $deactiveCount++;
                                        }
                                    }
                                }
                            }							$active_users .='</tbody></table>';
                            $deactive_users .='</tbody></table>';

                            ?>
                            <div class="col-sm-12">
                                <div class="nav-tabs-custom">
                                    <ul class="nav nav-tabs">
                                        <li class="active">
                                            <a data-toggle="tab" href="#tab-activated-users"><span>Activated admin (<?php echo $activeCount-1; ?>)</span></a>
                                        </li>
                                        <li class="">
                                            <a data-toggle="tab" href="#tab-deactivated-users"><span>Deactivated admin (<?php echo $deactiveCount-1; ?>)</span></a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="tab-activated-users">
                                            <div class="row column-seperation">
                                                <?php echo $active_users; ?>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="tab-deactivated-users">
                                            <div class="row column-seperation">
                                                <?php echo $deactive_users; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
</div>
<script>
    $(document).ready(function () {
        $("#add_admin_form").validate({
            submitHandler: function (form) {
                var login_id = $("#login_id").val();
                var password = $("#password").val();
                var mobile_no = $("#mobile_no").val();
                var email = $("#email").val();
                var first_name = $("#first_name").val();
                var last_name = $("#last_name").val();
                var admin_type = $("#admin_type").val();
                $.ajax({
                    url: '<?php echo PATH; ?>/ajax/add_admin.php',
                    type: 'post',
                    data: {
                        data: '{"login_id":"' + login_id + '","password":"' + password + '","mobile_no":"' + mobile_no + '","email":"' + email + '","first_name":"' + first_name + '","last_name":"' + last_name + '","admin_type":"' + admin_type + '"}',
                    },
                    async: false,
                    success: function (data) {
                         data = data.trim();
                        if (data == 'success') {
                            swal({title: "", text: "An "+admin_type+" has been added.", type: "success", showCancelButton: false, confirmButtonColor: "#5bc0de", confirmButtonText: "Okay"}, function () {
                                location.reload();
                            });
                        } else if (data == 'duplicate') {
                            swal("Please recheck!", "This mobile number is already is use!", "error");
                        } else if (data == 'exists') {
                            swal("Please recheck!", "Login id already exists!", "error");
                            } else {
                            swal("Error!", data, "error");
                        }

                    }
                });
            }
        });

    });
</script>
<div class="modal fade" id="add_user">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Add Admin</h4>
            </div>
            <div class="modal-body">
                <div class="main-content new" style="padding: 0 !important;">
                    <div class="panel mb25">
                        <div class=panel-body>
                            <div class="row no-margin">
                                <div class="col-lg-12 adduser">
                                    <form id="add_admin_form" name="add_admin_form"  class="p-t-15" role="form"  action="">
                                        <div class="form-group adduser">
                                            <div class="col-sm-6">
                                                <label for="first-name">Login ID</label>
                                                <div> <input type="text" name="login_id" id="login_id" class="form-control" placeholder="Enter login Id" required> </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="first-name">Password</label>
                                                <div> <input type="password" name="password" id="password" class="form-control" placeholder="Enter Password" required> </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <label for="first-name">Mobile Number</label>
                                                <div> <input type="number" name="mobile_no" id="mobile_no" class="form-control" placeholder="Enter Mobile Number" required> </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="first-name">Email</label>
                                                <div> <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email ID" required> </div>
                                            </div>
                                        </div>
                                        <div class="form-group adduser">
                                            <div class="col-sm-6">
                                                <label for="first-name">First Name</label>
                                                <div> <input type="text" name="first_name" id="first_name" class="form-control" placeholder="Enter First Name" required> </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="last-name">Last Name</label>
                                                <div> <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Enter Last Name" required> </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <label for="last-name">Select Admin Type</label>
                                                <div>
                                                    <select name="admin_type" id="admin_type" class="form-control" required>
                                                        <option value="">Select an option</option>
                                                        <option value="Normal Admin">Normal Admin</option>
                                                        <option value="Super Admin">Super Admin</option>
                                                        <option value="Account Manager">Account Manager Admin</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="last-name">&nbsp;</label>
                                                <div>
                                                    <input type="submit" id="application-user" class="btn btn-primary button-next" value="Submit">
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php include('inc/footer.php'); ?>

