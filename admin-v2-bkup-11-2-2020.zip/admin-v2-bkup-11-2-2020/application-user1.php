<?php
include('inc/header.php');
$query = "select * from tbl_users";
$result = mysqli_query($con,$query);

?>
    <style type="text/css">
        .col-lg-12.adduser label {margin: 4% 0% 1% !important;    }
        .butta { margin-top: 5% !important; float: right; padding: 1% 1%;    }
        .form-group { margin-bottom: 0px;}
        a.btn.btn-info {
            padding: 3% 7%;
            margin: 1px 6px 0px 0px !important;
            font-size: 14px !IMPORTANT;
            border-radius: 2px;
        }
    </style>
    <div class="butta">
        <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add User</button>
    </div>
    <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
        <tr>
            <th>Emp No</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Mobile</th>
            <th>Email</th>
            <th>City</th>
            <th>Postal Code</th>
            <th>View Timesheet</th>
        </tr>
        </thead>
        <tbody>
        <?php while($rows = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $rows['emp_no']; ?></td>
                <td><?php echo $rows['first_name']." ".$rows['last_name']; ?></td>
                <td><?php echo $rows['phone']; ?></td>
                <td><?php echo $rows['mobile']; ?></td>
                <td><?php echo $rows['email']; ?></td>
                <td><?php echo $rows['city']; ?></td>
                <td><?php echo $rows['postal_code']; ?></td>
                <td><a class="btn btn-info" href="https://neptunetimesheets.com/admin/user-dashboard.php?emp_id=<?php echo $rows['emp_no']; ?>">View</a><a class="btn btn-info" data-toggle="modal" data-target="#myModaledit">Edit</a></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
    <script>
        /*
        $("#application-user").click(function(){
                     alert("hi");
                });
            $(document).ready(function () {
                $("#add_user_form").validate({
                    submitHandler: function (form) {
                        var emp_number = $("#emp_number").val();
                        var first_name = $("#first_name").val();
                        var last_name = $("#last_name").val();
                        var phone = $("#phone").val();
                        var mobile = $("#mobile").val();
                        var email = $("#email").val();
                        var address1 = $("#address1").val();
                        var address2 = $("#address2").val();
                        var city = $("#city").val();
                        var postal_code = $("#postal_code").val();
                        var dob = $("#dob").val();
                        var class_from_date = $("#class_from_date").val();
                        var province = $("#province").val();
                        var classes = $("#class").val();
                        var pass_create_open_file = $("#pass_create_open_file").val();

                        var querystring  = '{"first_name":"' + first_name + '","last_name":"' + last_name + '","address":"' + address + '","phone_num":"' + phone_num + '","email":"' + email + '","password":"' + password + '","dob":"' + dob + '","sin":"' + sin + '","emergency_contact_num":"' + emergency_contact_num + '","start_date":"' + start_date + '"}';
                        $.ajax({
                            url: '/ajax/add_user.php',
                    type: 'post',
                    data: {
                        data: '{"first_name":"' + first_name + '","last_name":"' + last_name + '","address":"' + address + '","phone_num":"' + phone_num + '","email":"' + email + '","password":"' + password + '","dob":"' + dob + '","sin":"' + sin + '","emergency_contact_num":"' + emergency_contact_num + '","start_date":"' + start_date + '"}',
                    },
                    async: false,
                    success: function (data) {
                         data = data.trim();
                        if (data == 'success') {
                            swal({title: "Wohoo!!!", text: "User has been added.", type: "success", showCancelButton: false, confirmButtonColor: "#5bc0de", confirmButtonText: "Okay"}, function () {
                                location.href = '/admin/user-promoters.php';
                            });
                        } else if (data == 'duplicate') {
                            swal("Please recheck!", "This mobile number is already is use!", "error");
                        } else {
                            swal("Error!", data, "error");
                        }

                    }
                });
            }
        });

    }); */

    </script>
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add User</h4>
                </div>
                <div class="modal-body">
                    <div class="main-content new" style="padding: 0 !important;">
                        <div class="panel mb25">
                            <div class="panel-body" style="padding: 0 !important;">
                                <div class="row no-margin">
                                    <div class="col-lg-12 adduser">
                                        <form id="add_user_form" name="add_user_form"  class="p-t-15" role="form"  action="">
                                            <div class="form-group adduser">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Employee Number</label>
                                                    <div> <input type="text" name="emp_number" id="emp_number" class="form-control" placeholder="Enter Employee Number"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Email</label>
                                                    <div> <input type="Email" name="email" id="email" class="form-control" placeholder="Enter Email ID"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group adduser">
                                                <div class="col-sm-6">
                                                    <label for="first-name">First Name</label>
                                                    <div> <input type="text" name="first_name" id="first_name" class="form-control" placeholder="Enter First Name"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="last-name">Last Name</label>
                                                    <div> <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Enter Last Name"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="address">Phone No.</label>
                                                    <div> <input type="text" name="phone" id="phone" class="form-control" placeholder="Enter Phone No."> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="phone-no">Mobile</label>
                                                    <div> <input type="text" name="mobile" id="mobile" class="form-control" placeholder="Enter Mobile"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Address1</label>
                                                    <div> <input type="Email" name="address1" id="address1" class="form-control" placeholder="Enter Address1"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Address2</label>
                                                    <div> <input type="text" name="address2" id="address2" class="form-control" placeholder="Enter Address2"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="sin">City</label>
                                                    <div> <input type="text" name="city" id="city" class="form-control" placeholder="Enter City Name"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="Emergeny-contact">Postal Code</label>
                                                    <div> <input type="text" name="postal_code" id="postal_code" class="form-control" placeholder="Enter Postal Code"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Date of Birth</label>
                                                    <div> <input type="date" name="dob" id="dob" class="form-control"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Class from Date</label>
                                                    <div> <input type="date" name="class_from_date" id="class_from_date" class="form-control"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-4">
                                                    <label for="first-name">Province</label>
                                                    <div> <input type="text" name="province" id="province" class="form-control" placeholder="Enter Province"> </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="first-name">Class</label>
                                                    <div> <input type="text" name="class" id="class" class="form-control" placeholder="Enter Class"> </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="first-name">Password</label>
                                                    <div> <input type="password" name="pass_create_open_file" id="pass_create_open_file" class="form-control" placeholder="Enter Password"> </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" id="application-user" class="btn btn-primary button-next">Submit</button>

                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="myModaledit" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Edit User Deatils</h4>
                </div>
                <div class="modal-body">
                    <div class="main-content new" style="padding: 0 !important;">
                        <div class="panel mb25">
                            <div class="panel-body" style="padding: 0 !important;">
                                <div class="row no-margin">
                                    <div class="col-lg-12 adduser">
                                        <form id="add_user_form" name="add_user_form"  class="p-t-15" role="form"  action="" method="post">
                                            <div class="form-group adduser">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Employee Number</label>
                                                    <div> <input type="text" name="emp_number" id="emp_number" class="form-control"  value= "<?php echo $_SESSION["emp_id"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Email</label>
                                                    <div> <input type="Email" name="email" id="email" class="form-control" value= "<?php echo $_SESSION["email"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group adduser">
                                                <div class="col-sm-6">
                                                    <label for="first-name">First Name</label>
                                                    <div> <input type="text" name="first_name" id="first_name" class="form-control"  value= "<?php echo $_SESSION["first_name"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="last-name">Last Name</label>
                                                    <div> <input type="text" name="last_name" id="last_name" class="form-control" value= "<?php echo $_SESSION["last_name"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="address">Phone No.</label>
                                                    <div> <input type="text" name="phone" id="phone" class="form-control" value= "<?php echo $_SESSION["phone"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="phone-no">Mobile</label>
                                                    <div> <input type="text" name="mobile" id="mobile" class="form-control" value= "<?php echo $_SESSION["mobile"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Address1</label>
                                                    <div> <input type="Email" name="address1" id="address1" class="form-control" value= "<?php echo $_SESSION["address1"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Address2</label>
                                                    <div> <input type="text" name="address2" id="address2" class="form-control" value= "<?php echo $_SESSION["Address2"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="sin">City</label>
                                                    <div> <input type="text" name="city" id="city" class="form-control" value= "<?php echo $_SESSION["city"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="Emergeny-contact">Postal Code</label>
                                                    <div> <input type="text" name="postal_code" id="postal_code" class="form-control" value= "<?php echo $_SESSION["postal_code"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-6">
                                                    <label for="first-name">Date of Birth</label>
                                                    <div> <input type="date" name="dob" id="dob" class="form-control" value= "<?php echo $_SESSION["dob"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label for="first-name">Class from Date</label>
                                                    <div> <input type="date" name="class_from_date" id="class_from_date" class="form-control" value= "<?php echo $_SESSION["class_from_date"]; ?>"> </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="col-sm-4">
                                                    <label for="first-name">Province</label>
                                                    <div> <input type="text" name="province" id="province" class="form-control" value= "<?php echo $_SESSION["province"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="first-name">Class</label>
                                                    <div> <input type="text" name="class" id="class" class="form-control" value= "<?php echo $_SESSION["class"]; ?>"> </div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label for="first-name">Password</label>
                                                    <div> <input type="password" name="pass_create_open_file" id="pass_create_open_file" class="form-control" value= "<?php echo $_SESSION["pass_create_open_file"]; ?>"> </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" id="application-user" class="btn btn-primary button-next">Submit</button>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php include('inc/footer.php'); ?>