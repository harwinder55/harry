<?php
ob_start();
include('inc/header.php');
$admin_query = "select * from tbl_admin where user_id='".$_REQUEST[user_id]."'";
$admin_query_result = mysqli_query($con,$admin_query);
$admin_details = mysqli_fetch_assoc($admin_query_result);
if(isset($_REQUEST['save'])) {
    $save_supervisors_profile="UPDATE `tbl_admin` SET first_name = '".$_REQUEST['first_name']."' , last_name = '".$_REQUEST['last_name']."' ,`mobile_no`='".$_REQUEST['mobile_no']."',`email`='".$_REQUEST['email']."' ,`password`='".$_REQUEST['password']."' WHERE user_id='".$_REQUEST['user_id']."'";
    if (mysqli_query($con,$save_supervisors_profile) === TRUE) {
        logger(	$_SESSION["user_id"],strtolower($_SESSION["user_type"]),"admin 's Profile","updated an admin profile of  ".$_REQUEST['first_name']." ".$_REQUEST['last_name'],$save_supervisors_profile);
        header('location:'.$_REQUEST["redirect_url"]);
    }
}
?>
<style>
    .non-editable-form input, .non-editable-form select {
        border: none;
        pointer-events: none;
        margin-top: -9px;
    }
    .non-editable-form .col-sm-12 {
        border-bottom: 1px solid #eee;
        padding-top: 13px;
    }
</style>
<div class="content-wrapper" style="min-height: 312px;">
    <section class="content-header">
        <h1 style="">
            <?php echo $admin_details["first_name"];?> <?php echo $supervisors_details["last_name"];?>'s Profile
            <small>#</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">My Profile</a></li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <div class="col-md-8">
                            <h2 class="text-success no-margin"></h2>
                        </div>
                        <div class="">
                            <div class="col-xs-12">

                            </div>
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="col-md-9 center">
                            <div class="box box-primary">
                                <div class="box-body box-profile">
                                    <h3 class="profile-username text-center">login Id : <?php echo $admin_details["login_id"];?></h3>
                                    <form id="update_user_form" name="update_user_form"  class="p-t-15 non-editable-form" role="form"  action="">
                                        <div class="form-group edit-user">
                                            <div class="col-sm-12">
                                                <label for="first-name"> First Name</label>
                                                <div class="col-sm-8 pull-right"> <input type="text" name="first_name" id="first_name" class="form-control" placeholder="Enter First Name" value="<?php echo $admin_details["first_name"];?>" required> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="first-name"> Last Name</label>
                                                <div class="col-sm-8 pull-right"> <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Enter Last Name" value="<?php echo $admin_details["last_name"];?>" required> </div>
                                            </div>

                                            <div class="col-sm-12">
                                                <label for="first-name"> Mobile</label>
                                                <div class="col-sm-8 pull-right"> <input type="number" name="mobile_no" id="mobile" class="form-control" placeholder="Enter Mobile" value="<?php echo $admin_details["mobile_no"];?>" required> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="first-name"> Email</label>
                                                <div class="col-sm-8 pull-right"> <input type="email" name="email" id="email" class="form-control" placeholder="Enter Email" value="<?php echo $admin_details["email"];?>" required>
                                                    <input type="hidden" id="redirect_url" name="redirect_url" value="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'] . "?" . $_SERVER['QUERY_STRING']; ?>">
                                                    <input type="hidden" name="user_id" value="<?php echo $_REQUEST['user_id']; ?>">
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="first-name"> Password</label>
                                                <div class="col-sm-8 pull-right"> <input type="text" name="password" id="password" class="form-control" placeholder="Enter password" value="<?php if($_SESSION['user_type'] == 'Admin' && $_SESSION['admin_type'] == 'Super Admin') { echo $admin_details["password"]; } else { echo '************'; }?>" required> </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <label for="first-name">&nbsp;</label>
                                                <div class="">
                                                    <input type="submit"  style="display:none;" name="save" value="Save" class="btn btn-success btn-save">
                                                    <a class="btn btn-warning btn-edit" >Edit</a>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<script>
    $(document).ready(function () {
        $("#update_user_form").validate({
            submitHandler: function (form) {
                form.submit();
            }
        });
        $("#update_user_form .btn-edit").click( function(){
            $(this).hide();
            $(".btn-save").show();
            $("#update_user_form").removeClass("non-editable-form");
        });

    });
</script>
<?php include('inc/footer.php'); ?>
