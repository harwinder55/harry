<?php
ob_start();
include('inc/header.php');
if($_SESSION['user_type'] == 'Employee' ) { //&& (!in_array($_SESSION['user_id'],$_REQUEST['user_id']) || count($_REQUEST['user_id']) != 1) ){
    ob_end_clean();
    header("location:".PATH."");
    exit;
}
if(!empty($_REQUEST['insert_schedule'])) {
    $tot1 = $_REQUEST['tot1'];
    $hurl=$_SERVER['HTTP_REFERER'];

    /***************************schedule 1*********************************/
    $emp_id1 = $_REQUEST['emp_id1'];

    if(!empty($_REQUEST['premium_id1']))
        $premium_ids1 = implode(',', $_REQUEST['premium_id1']);
    else
        $premium_ids1 = '0:00:00';

    if(!empty($_REQUEST['in_mon1']))
        $in_mon1 = @$_REQUEST['in_mon1'];
    else
        $in_mon1 = '0:00:00';

    if(!empty($_REQUEST['in_tue1']))
        $in_tue1 = @$_REQUEST['in_tue1'];
    else
        $in_tue1 = '0:00:00';

    if(!empty($_REQUEST['in_wed1']))
        $in_wed1 = @$_REQUEST['in_wed1'];
    else
        $in_wed1 = '0:00:00';

    if(!empty($_REQUEST['in_thu1']))
        $in_thu1 = @$_REQUEST['in_thu1'];
    else
        $in_thu1 = '0:00:00';

    if(!empty($_REQUEST['in_fri1']))
        $in_fri1 = @$_REQUEST['in_fri1'];
    else
        $in_fri1 = '0:00:00';

    if(!empty($_REQUEST['in_sat1']))
        $in_sat1 = @$_REQUEST['in_sat1'];
    else
        $in_sat1 = '0:00:00';

    if(!empty($_REQUEST['in_sun1']))
        $in_sun1 = @$_REQUEST['in_sun1'];
    else
        $in_sun1 = '0:00:00';

    if(!empty($_REQUEST['out_mon1']))
        $out_mon1 = @$_REQUEST['out_mon1'];
    else
        $out_mon1 = '0:00:00';

    if(!empty($_REQUEST['out_tue1']))
        $out_tue1 = @$_REQUEST['out_tue1'];
    else
        $out_tue1 = '0:00:00';

    if(!empty($_REQUEST['out_wed1']))
        $out_wed1 = @$_REQUEST['out_wed1'];
    else
        $out_wed1 = '0:00:00';

    if(!empty($_REQUEST['out_thu1']))
        $out_thu1 = @$_REQUEST['out_thu1'];
    else
        $out_thu1 = '0:00:00';

    if(!empty($_REQUEST['out_fri1']))
        $out_fri1 = @$_REQUEST['out_fri1'];
    else
        $out_fri1 = '0:00:00';

    if(!empty($_REQUEST['out_sat1']))
        $out_sat1 = @$_REQUEST['out_sat1'];

    else
        $out_sat1 = '0:00:00';

    if(!empty($_REQUEST['out_sun1']))
        $out_sun1 = @$_REQUEST['out_sun1'];
    else
        $out_sun1 = '0:00:00';

    if(!empty($_REQUEST['base_rate_mon1']))
        $base_rate_mon1 = @$_REQUEST['base_rate_mon1'];
    else
        $base_rate_mon1 = '0';

    if(!empty($_REQUEST['base_rate_tue1']))
        $base_rate_tue1 = @$_REQUEST['base_rate_tue1'];

    else
        $base_rate_tue1 = '0';

    if(!empty($_REQUEST['base_rate_wed1']))
        $base_rate_wed1 = @$_REQUEST['base_rate_wed1'];
    else
        $base_rate_wed1 = '0';

    if(!empty($_REQUEST['base_rate_thu1']))
        $base_rate_thu1 = @$_REQUEST['base_rate_thu1'];
    else
        $base_rate_thu1 = '0';

    if(!empty($_REQUEST['base_rate_fri1']))
        $base_rate_fri1 = @$_REQUEST['base_rate_fri1'];
    else
        $base_rate_fri1 = '0';

    if(!empty($_REQUEST['base_rate_sat1']))
        $base_rate_sat1 = @$_REQUEST['base_rate_sat1'];
    else
        $base_rate_sat1 = '0';

    if(!empty($_REQUEST['base_rate_sun1']))
        $base_rate_sun1 = @$_REQUEST['base_rate_sun1'];
    else
        $base_rate_sun1 = '0';

    if(!empty($_REQUEST['site_id_mon1']))
        $site_id_mon1 = @$_REQUEST['site_id_mon1'];
    else
        $site_id_mon1 = '0';

    if(!empty($_REQUEST['site_id_tue1']))
        $site_id_tue1 = @$_REQUEST['site_id_tue1'];
    else
        $site_id_tue1 = '0';

    if(!empty($_REQUEST['site_id_wed1']))
        $site_id_wed1 = @$_REQUEST['site_id_wed1'];
    else
        $site_id_wed1 = '0';

    if(!empty($_REQUEST['site_id_thu1']))
        $site_id_thu1 = @$_REQUEST['site_id_thu1'];
    else
        $site_id_thu1 = '0';

    if(!empty($_REQUEST['site_id_fri1']))
        $site_id_fri1 = @$_REQUEST['site_id_fri1'];
    else
        $site_id_fri1 = '0';

    if(!empty($_REQUEST['site_id_sat1']))
        $site_id_sat1 = @$_REQUEST['site_id_sat1'];
    else
        $site_id_sat1 = '0';

    if(!empty($_REQUEST['site_id_sun1']))
        $site_id_sun1 = @$_REQUEST['site_id_sun1'];
    else
        $site_id_sun1 = '0';

    if(!empty($_REQUEST['premium_id_mon1']))
        $premium_id_mon1 = implode(',', @$_REQUEST['premium_id_mon1']);
    else
        $premium_id_mon1 = '';

    if(!empty($_REQUEST['premium_id_tue1']))
        $premium_id_tue1 = implode(',', @$_REQUEST['premium_id_tue1']);
    else
        $premium_id_tue1 = '';

    if(!empty($_REQUEST['premium_id_wed1']))
        $premium_id_wed1 = implode(',', @$_REQUEST['premium_id_wed1']);
    else
        $premium_id_wed1 = '';

    if(!empty($_REQUEST['premium_id_thu1']))
        $premium_id_thu1 = implode(',', @$_REQUEST['premium_id_thu1']);
    else
        $premium_id_thu1 = '';

    if(!empty($_REQUEST['premium_id_fri1']))
        $premium_id_fri1 = implode(',', @$_REQUEST['premium_id_fri1']);
    else
        $premium_id_fri1 = '';

    if(!empty($_REQUEST['premium_id_sat1']))
        $premium_id_sat1 = implode(',', @$_REQUEST['premium_id_sat1']);
    else
        $premium_id_sat1 = '';

    if(!empty($_REQUEST['premium_id_sun1']))
        $premium_id_sun1 = implode(',', @$_REQUEST['premium_id_sun1']);
    else
        $premium_id_sun1 = '';

    $start_date1 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['start_date1']));
    $end_date1 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['end_date1']));

    /***************************schedule 2*********************************/

    $emp_id2 = @$_REQUEST['emp_id2'];

    if(!empty($_REQUEST['premium_id2']))
        $premium_ids2 = implode(',', $_REQUEST['premium_id2']);
    else
        $premium_ids2 = '0:00:00';

    if(!empty($_REQUEST['in_mon2']))
        $in_mon2 = @$_REQUEST['in_mon2'];
    else
        $in_mon2 = '0:00:00';

    if(!empty($_REQUEST['in_tue2']))
        $in_tue2 = @$_REQUEST['in_tue2'];
    else
        $in_tue2 = '0:00:00';

    if(!empty($_REQUEST['in_wed2']))
        $in_wed2 = @$_REQUEST['in_wed2'];
    else
        $in_wed2 = '0:00:00';

    if(!empty($_REQUEST['in_thu2']))
        $in_thu2 = @$_REQUEST['in_thu2'];
    else
        $in_thu2 = '0:00:00';

    if(!empty($_REQUEST['in_fri2']))
        $in_fri2 = @$_REQUEST['in_fri2'];
    else
        $in_fri2 = '0:00:00';

    if(!empty($_REQUEST['in_sat2']))
        $in_sat2 = @$_REQUEST['in_sat2'];
    else
        $in_sat2 = '0:00:00';

    if(!empty($_REQUEST['in_sun2']))
        $in_sun2 = @$_REQUEST['in_sun2'];
    else
        $in_sun2 = '0:00:00';

    if(!empty($_REQUEST['out_mon2']))
        $out_mon2 = @$_REQUEST['out_mon2'];
    else
        $out_mon2 = '0:00:00';

    if(!empty($_REQUEST['out_tue2']))
        $out_tue2 = @$_REQUEST['out_tue2'];
    else
        $out_tue2 = '0:00:00';

    if(!empty($_REQUEST['out_wed2']))
        $out_wed2 = @$_REQUEST['out_wed2'];
    else
        $out_wed2 = '0:00:00';

    if(!empty($_REQUEST['out_thu2']))
        $out_thu2 = @$_REQUEST['out_thu2'];
    else
        $out_thu2 = '0:00:00';

    if(!empty($_REQUEST['out_fri2']))
        $out_fri2 = @$_REQUEST['out_fri2'];
    else
        $out_fri2 = '0:00:00';

    if(!empty($_REQUEST['out_sat2']))
        $out_sat2 = @$_REQUEST['out_sat2'];

    else
        $out_sat2 = '0:00:00';

    if(!empty($_REQUEST['out_sun2']))
        $out_sun2 = @$_REQUEST['out_sun2'];
    else
        $out_sun2 = '0:00:00';

    if(!empty($_REQUEST['base_rate_mon2']))
        $base_rate_mon2 = @$_REQUEST['base_rate_mon2'];
    else
        $base_rate_mon2 = '0';

    if(!empty($_REQUEST['base_rate_tue2']))
        $base_rate_tue2 = @$_REQUEST['base_rate_tue2'];

    else
        $base_rate_tue2 = '0';

    if(!empty($_REQUEST['base_rate_wed2']))
        $base_rate_wed2 = @$_REQUEST['base_rate_wed2'];
    else
        $base_rate_wed2 = '0';

    if(!empty($_REQUEST['base_rate_thu2']))
        $base_rate_thu2 = @$_REQUEST['base_rate_thu2'];
    else
        $base_rate_thu2 = '0';

    if(!empty($_REQUEST['base_rate_fri2']))
        $base_rate_fri2 = @$_REQUEST['base_rate_fri2'];
    else
        $base_rate_fri2 = '0';

    if(!empty($_REQUEST['base_rate_sat2']))
        $base_rate_sat2 = @$_REQUEST['base_rate_sat2'];
    else
        $base_rate_sat2 = '0';

    if(!empty($_REQUEST['base_rate_sun2']))
        $base_rate_sun2 = @$_REQUEST['base_rate_sun2'];
    else
        $base_rate_sun2 = '0';

    if(!empty($_REQUEST['site_id_mon2']))
        $site_id_mon2 = @$_REQUEST['site_id_mon2'];
    else
        $site_id_mon2 = '0';

    if(!empty($_REQUEST['site_id_tue2']))
        $site_id_tue2 = @$_REQUEST['site_id_tue2'];
    else
        $site_id_tue2 = '0';

    if(!empty($_REQUEST['site_id_wed2']))
        $site_id_wed2 = @$_REQUEST['site_id_wed2'];
    else
        $site_id_wed2 = '0';

    if(!empty($_REQUEST['site_id_thu2']))
        $site_id_thu2 = @$_REQUEST['site_id_thu2'];
    else
        $site_id_thu2 = '0';

    if(!empty($_REQUEST['site_id_fri2']))
        $site_id_fri2 = @$_REQUEST['site_id_fri2'];
    else
        $site_id_fri2 = '0';

    if(!empty($_REQUEST['site_id_sat2']))
        $site_id_sat2 = @$_REQUEST['site_id_sat2'];
    else
        $site_id_sat2 = '0';

    if(!empty($_REQUEST['site_id_sun2']))
        $site_id_sun2 = @$_REQUEST['site_id_sun2'];
    else
        $site_id_sun2 = '0';

    if(!empty($_REQUEST['premium_id_mon2']))
        $premium_id_mon2 = implode(',', @$_REQUEST['premium_id_mon2']);
    else
        $premium_id_mon2 = '';

    if(!empty($_REQUEST['premium_id_tue2']))
        $premium_id_tue2 = implode(',', @$_REQUEST['premium_id_tue2']);
    else
        $premium_id_tue2 = '';

    if(!empty($_REQUEST['premium_id_wed2']))
        $premium_id_wed2 = implode(',', @$_REQUEST['premium_id_wed2']);
    else
        $premium_id_wed2 = '';

    if(!empty($_REQUEST['premium_id_thu2']))
        $premium_id_thu2 = implode(',', @$_REQUEST['premium_id_thu2']);
    else
        $premium_id_thu2 = '';

    if(!empty($_REQUEST['premium_id_fri2']))
        $premium_id_fri2 = implode(',', @$_REQUEST['premium_id_fri2']);
    else
        $premium_id_fri2 = '';

    if(!empty($_REQUEST['premium_id_sat2']))
        $premium_id_sat2 = implode(',', @$_REQUEST['premium_id_sat2']);
    else
        $premium_id_sat2 = '';

    if(!empty($_REQUEST['premium_id_sun2']))
        $premium_id_sun2 = implode(',', @$_REQUEST['premium_id_sun2']);
    else
        $premium_id_sun2 = '';

    $start_date2 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['start_date2']));
    $end_date2 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['end_date2']));

    /*****************************schedule 3*******************************/

    $emp_id3 = @$_REQUEST['emp_id3'];

    if(!empty($_REQUEST['premium_id3']))
        $premium_ids3 = implode(',', $_REQUEST['premium_id3']);
    else
        $premium_ids3 = '0:00:00';

    if(!empty($_REQUEST['in_mon3']))
        $in_mon3 = @$_REQUEST['in_mon3'];
    else
        $in_mon3 = '0:00:00';

    if(!empty($_REQUEST['in_tue3']))
        $in_tue3 = @$_REQUEST['in_tue3'];
    else
        $in_tue3 = '0:00:00';

    if(!empty($_REQUEST['in_wed3']))
        $in_wed3 = @$_REQUEST['in_wed3'];
    else
        $in_wed3 = '0:00:00';

    if(!empty($_REQUEST['in_thu3']))
        $in_thu3 = @$_REQUEST['in_thu3'];
    else
        $in_thu3 = '0:00:00';

    if(!empty($_REQUEST['in_fri3']))
        $in_fri3 = @$_REQUEST['in_fri3'];
    else
        $in_fri3 = '0:00:00';

    if(!empty($_REQUEST['in_sat3']))
        $in_sat3 = @$_REQUEST['in_sat3'];
    else
        $in_sat3 = '0:00:00';

    if(!empty($_REQUEST['in_sun3']))
        $in_sun3 = @$_REQUEST['in_sun3'];
    else
        $in_sun3 = '0:00:00';

    if(!empty($_REQUEST['out_mon3']))
        $out_mon3 = @$_REQUEST['out_mon3'];
    else
        $out_mon3 = '0:00:00';

    if(!empty($_REQUEST['out_tue3']))
        $out_tue3 = @$_REQUEST['out_tue3'];
    else
        $out_tue3 = '0:00:00';

    if(!empty($_REQUEST['out_wed3']))
        $out_wed3 = @$_REQUEST['out_wed3'];
    else
        $out_wed3 = '0:00:00';

    if(!empty($_REQUEST['out_thu3']))
        $out_thu3 = @$_REQUEST['out_thu3'];
    else
        $out_thu3 = '0:00:00';

    if(!empty($_REQUEST['out_fri3']))
        $out_fri3 = @$_REQUEST['out_fri3'];
    else
        $out_fri3 = '0:00:00';

    if(!empty($_REQUEST['out_sat3']))
        $out_sat3 = @$_REQUEST['out_sat3'];

    else
        $out_sat3 = '0:00:00';

    if(!empty($_REQUEST['out_sun3']))
        $out_sun3 = @$_REQUEST['out_sun3'];
    else
        $out_sun3 = '0:00:00';

    if(!empty($_REQUEST['base_rate_mon3']))
        $base_rate_mon3 = @$_REQUEST['base_rate_mon3'];
    else
        $base_rate_mon3 = '0';

    if(!empty($_REQUEST['base_rate_tue3']))
        $base_rate_tue3 = @$_REQUEST['base_rate_tue3'];

    else
        $base_rate_tue3 = '0';

    if(!empty($_REQUEST['base_rate_wed3']))
        $base_rate_wed3 = @$_REQUEST['base_rate_wed3'];
    else
        $base_rate_wed3 = '0';

    if(!empty($_REQUEST['base_rate_thu3']))
        $base_rate_thu3 = @$_REQUEST['base_rate_thu3'];
    else
        $base_rate_thu3 = '0';

    if(!empty($_REQUEST['base_rate_fri3']))
        $base_rate_fri3 = @$_REQUEST['base_rate_fri3'];
    else
        $base_rate_fri3 = '0';

    if(!empty($_REQUEST['base_rate_sat3']))
        $base_rate_sat3 = @$_REQUEST['base_rate_sat3'];
    else
        $base_rate_sat3 = '0';

    if(!empty($_REQUEST['base_rate_sun3']))
        $base_rate_sun3 = @$_REQUEST['base_rate_sun3'];
    else
        $base_rate_sun3 = '0';

    if(!empty($_REQUEST['site_id_mon3']))
        $site_id_mon3 = @$_REQUEST['site_id_mon3'];
    else
        $site_id_mon3 = '0';

    if(!empty($_REQUEST['site_id_tue3']))
        $site_id_tue3 = @$_REQUEST['site_id_tue3'];
    else
        $site_id_tue3 = '0';

    if(!empty($_REQUEST['site_id_wed3']))
        $site_id_wed3 = @$_REQUEST['site_id_wed3'];
    else
        $site_id_wed3 = '0';

    if(!empty($_REQUEST['site_id_thu3']))
        $site_id_thu3 = @$_REQUEST['site_id_thu3'];
    else
        $site_id_thu3 = '0';

    if(!empty($_REQUEST['site_id_fri3']))
        $site_id_fri3 = @$_REQUEST['site_id_fri3'];
    else
        $site_id_fri3 = '0';

    if(!empty($_REQUEST['site_id_sat3']))
        $site_id_sat3 = @$_REQUEST['site_id_sat3'];
    else
        $site_id_sat3 = '0';

    if(!empty($_REQUEST['site_id_sun3']))
        $site_id_sun3 = @$_REQUEST['site_id_sun3'];
    else
        $site_id_sun3 = '0';

    if(!empty($_REQUEST['premium_id_mon3']))
        $premium_id_mon3 = implode(',', @$_REQUEST['premium_id_mon3']);
    else
        $premium_id_mon3 = '';

    if(!empty($_REQUEST['premium_id_tue3']))
        $premium_id_tue3 = implode(',', @$_REQUEST['premium_id_tue3']);
    else
        $premium_id_tue3 = '';

    if(!empty($_REQUEST['premium_id_wed3']))
        $premium_id_wed3 = implode(',', @$_REQUEST['premium_id_wed3']);
    else
        $premium_id_wed3 = '';

    if(!empty($_REQUEST['premium_id_thu3']))
        $premium_id_thu3 = implode(',', @$_REQUEST['premium_id_thu3']);
    else
        $premium_id_thu3 = '';

    if(!empty($_REQUEST['premium_id_fri3']))
        $premium_id_fri3 = implode(',', @$_REQUEST['premium_id_fri3']);
    else
        $premium_id_fri3 = '';

    if(!empty($_REQUEST['premium_id_sat3']))
        $premium_id_sat3 = implode(',', @$_REQUEST['premium_id_sat3']);
    else
        $premium_id_sat3 = '';

    if(!empty($_REQUEST['premium_id_sun3']))
        $premium_id_sun3 = implode(',', @$_REQUEST['premium_id_sun3']);
    else
        $premium_id_sun3 = '';

    $start_date3 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['start_date3']));
    $end_date3 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['end_date3']));


    /**************************schedule 4**********************************/
    $emp_id4 = @$_REQUEST['emp_id4'];

    if(!empty($_REQUEST['premium_id4']))
        $premium_ids4 = implode(',', $_REQUEST['premium_id4']);
    else
        $premium_ids4 = '0:00:00';

    if(!empty($_REQUEST['in_mon4']))
        $in_mon4 = @$_REQUEST['in_mon4'];
    else
        $in_mon4 = '0:00:00';

    if(!empty($_REQUEST['in_tue4']))
        $in_tue4 = @$_REQUEST['in_tue4'];
    else
        $in_tue4 = '0:00:00';

    if(!empty($_REQUEST['in_wed4']))
        $in_wed4 = @$_REQUEST['in_wed4'];
    else
        $in_wed4 = '0:00:00';

    if(!empty($_REQUEST['in_thu4']))
        $in_thu4 = @$_REQUEST['in_thu4'];
    else
        $in_thu4 = '0:00:00';

    if(!empty($_REQUEST['in_fri4']))
        $in_fri4 = @$_REQUEST['in_fri4'];
    else
        $in_fri4 = '0:00:00';

    if(!empty($_REQUEST['in_sat4']))
        $in_sat4 = @$_REQUEST['in_sat4'];
    else
        $in_sat4 = '0:00:00';

    if(!empty($_REQUEST['in_sun4']))
        $in_sun4 = @$_REQUEST['in_sun4'];
    else
        $in_sun4 = '0:00:00';

    if(!empty($_REQUEST['out_mon4']))
        $out_mon4 = @$_REQUEST['out_mon4'];
    else
        $out_mon4 = '0:00:00';

    if(!empty($_REQUEST['out_tue4']))
        $out_tue4 = @$_REQUEST['out_tue4'];
    else
        $out_tue4 = '0:00:00';

    if(!empty($_REQUEST['out_wed4']))
        $out_wed4 = @$_REQUEST['out_wed4'];
    else
        $out_wed4 = '0:00:00';

    if(!empty($_REQUEST['out_thu4']))
        $out_thu4 = @$_REQUEST['out_thu4'];
    else
        $out_thu4 = '0:00:00';

    if(!empty($_REQUEST['out_fri4']))
        $out_fri4 = @$_REQUEST['out_fri4'];
    else
        $out_fri4 = '0:00:00';

    if(!empty($_REQUEST['out_sat4']))
        $out_sat4 = @$_REQUEST['out_sat4'];

    else
        $out_sat4 = '0:00:00';

    if(!empty($_REQUEST['out_sun4']))
        $out_sun4 = @$_REQUEST['out_sun4'];
    else
        $out_sun4 = '0:00:00';

    if(!empty($_REQUEST['base_rate_mon4']))
        $base_rate_mon4 = @$_REQUEST['base_rate_mon4'];
    else
        $base_rate_mon4 = '0';

    if(!empty($_REQUEST['base_rate_tue4']))
        $base_rate_tue4 = @$_REQUEST['base_rate_tue4'];

    else
        $base_rate_tue4 = '0';

    if(!empty($_REQUEST['base_rate_wed4']))
        $base_rate_wed4 = @$_REQUEST['base_rate_wed4'];
    else
        $base_rate_wed4 = '0';

    if(!empty($_REQUEST['base_rate_thu4']))
        $base_rate_thu4 = @$_REQUEST['base_rate_thu4'];
    else
        $base_rate_thu4 = '0';

    if(!empty($_REQUEST['base_rate_fri4']))
        $base_rate_fri4 = @$_REQUEST['base_rate_fri4'];
    else
        $base_rate_fri4 = '0';

    if(!empty($_REQUEST['base_rate_sat4']))
        $base_rate_sat4 = @$_REQUEST['base_rate_sat4'];
    else
        $base_rate_sat4 = '0';

    if(!empty($_REQUEST['base_rate_sun4']))
        $base_rate_sun4 = @$_REQUEST['base_rate_sun4'];
    else
        $base_rate_sun4 = '0';

    if(!empty($_REQUEST['site_id_mon4']))
        $site_id_mon4 = @$_REQUEST['site_id_mon4'];
    else
        $site_id_mon4 = '0';

    if(!empty($_REQUEST['site_id_tue4']))
        $site_id_tue4 = @$_REQUEST['site_id_tue4'];
    else
        $site_id_tue4 = '0';

    if(!empty($_REQUEST['site_id_wed4']))
        $site_id_wed4 = @$_REQUEST['site_id_wed4'];
    else
        $site_id_wed4 = '0';

    if(!empty($_REQUEST['site_id_thu4']))
        $site_id_thu4 = @$_REQUEST['site_id_thu4'];
    else
        $site_id_thu4 = '0';

    if(!empty($_REQUEST['site_id_fri4']))
        $site_id_fri4 = @$_REQUEST['site_id_fri4'];
    else
        $site_id_fri4 = '0';

    if(!empty($_REQUEST['site_id_sat4']))
        $site_id_sat4 = @$_REQUEST['site_id_sat4'];
    else
        $site_id_sat4 = '0';

    if(!empty($_REQUEST['site_id_sun4']))
        $site_id_sun4 = @$_REQUEST['site_id_sun4'];
    else
        $site_id_sun4 = '0';

    if(!empty($_REQUEST['premium_id_mon4']))
        $premium_id_mon4 = implode(',', @$_REQUEST['premium_id_mon4']);
    else
        $premium_id_mon4 = '';

    if(!empty($_REQUEST['premium_id_tue4']))
        $premium_id_tue4 = implode(',', @$_REQUEST['premium_id_tue4']);
    else
        $premium_id_tue4 = '';

    if(!empty($_REQUEST['premium_id_wed4']))
        $premium_id_wed4 = implode(',', @$_REQUEST['premium_id_wed4']);
    else
        $premium_id_wed4 = '';

    if(!empty($_REQUEST['premium_id_thu4']))
        $premium_id_thu4 = implode(',', @$_REQUEST['premium_id_thu4']);
    else
        $premium_id_thu4 = '';

    if(!empty($_REQUEST['premium_id_fri4']))
        $premium_id_fri4 = implode(',', @$_REQUEST['premium_id_fri4']);
    else
        $premium_id_fri4 = '';

    if(!empty($_REQUEST['premium_id_sat4']))
        $premium_id_sat4 = implode(',', @$_REQUEST['premium_id_sat4']);
    else
        $premium_id_sat4 = '';

    if(!empty($_REQUEST['premium_id_sun4']))
        $premium_id_sun4 = implode(',', @$_REQUEST['premium_id_sun4']);
    else
        $premium_id_sun4 = '';

    $start_date4 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['start_date4']));
    $end_date4 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['end_date4']));


    /**************************schedule 5**********************************/
    $emp_id5 = $_REQUEST['emp_id5'];

    if(!empty($_REQUEST['premium_id5']))
        $premium_ids5 = implode(',', $_REQUEST['premium_id5']);
    else
        $premium_ids5 = '0:00:00';

    if(!empty($_REQUEST['in_mon5']))
        $in_mon5 = @$_REQUEST['in_mon5'];
    else
        $in_mon5 = '0:00:00';

    if(!empty($_REQUEST['in_tue5']))
        $in_tue5 = @$_REQUEST['in_tue5'];
    else
        $in_tue5 = '0:00:00';

    if(!empty($_REQUEST['in_wed5']))
        $in_wed5 = @$_REQUEST['in_wed5'];
    else
        $in_wed5 = '0:00:00';

    if(!empty($_REQUEST['in_thu5']))
        $in_thu5 = @$_REQUEST['in_thu5'];
    else
        $in_thu5 = '0:00:00';

    if(!empty($_REQUEST['in_fri5']))
        $in_fri5 = @$_REQUEST['in_fri5'];
    else
        $in_fri5 = '0:00:00';

    if(!empty($_REQUEST['in_sat5']))
        $in_sat5 = @$_REQUEST['in_sat5'];
    else
        $in_sat5 = '0:00:00';

    if(!empty($_REQUEST['in_sun5']))
        $in_sun5 = @$_REQUEST['in_sun5'];
    else
        $in_sun5 = '0:00:00';

    if(!empty($_REQUEST['out_mon5']))
        $out_mon5 = @$_REQUEST['out_mon5'];
    else
        $out_mon5 = '0:00:00';

    if(!empty($_REQUEST['out_tue5']))
        $out_tue5 = @$_REQUEST['out_tue5'];
    else
        $out_tue5 = '0:00:00';

    if(!empty($_REQUEST['out_wed5']))
        $out_wed5 = @$_REQUEST['out_wed5'];
    else
        $out_wed5 = '0:00:00';

    if(!empty($_REQUEST['out_thu5']))
        $out_thu5 = @$_REQUEST['out_thu5'];
    else
        $out_thu5 = '0:00:00';

    if(!empty($_REQUEST['out_fri5']))
        $out_fri5 = @$_REQUEST['out_fri5'];
    else
        $out_fri5 = '0:00:00';

    if(!empty($_REQUEST['out_sat5']))
        $out_sat5 = @$_REQUEST['out_sat5'];

    else
        $out_sat5 = '0:00:00';

    if(!empty($_REQUEST['out_sun5']))
        $out_sun5 = @$_REQUEST['out_sun5'];
    else
        $out_sun5 = '0:00:00';

    if(!empty($_REQUEST['base_rate_mon5']))
        $base_rate_mon5 = @$_REQUEST['base_rate_mon5'];
    else
        $base_rate_mon5 = '0';

    if(!empty($_REQUEST['base_rate_tue5']))
        $base_rate_tue5 = @$_REQUEST['base_rate_tue5'];

    else
        $base_rate_tue5 = '0';

    if(!empty($_REQUEST['base_rate_wed5']))
        $base_rate_wed5 = @$_REQUEST['base_rate_wed5'];
    else
        $base_rate_wed5 = '0';

    if(!empty($_REQUEST['base_rate_thu5']))
        $base_rate_thu5 = @$_REQUEST['base_rate_thu5'];
    else
        $base_rate_thu5 = '0';

    if(!empty($_REQUEST['base_rate_fri5']))
        $base_rate_fri5 = @$_REQUEST['base_rate_fri5'];
    else
        $base_rate_fri5 = '0';

    if(!empty($_REQUEST['base_rate_sat5']))
        $base_rate_sat5 = @$_REQUEST['base_rate_sat5'];
    else
        $base_rate_sat5 = '0';

    if(!empty($_REQUEST['base_rate_sun5']))
        $base_rate_sun5 = @$_REQUEST['base_rate_sun5'];
    else
        $base_rate_sun5 = '0';

    if(!empty($_REQUEST['site_id_mon5']))
        $site_id_mon5 = @$_REQUEST['site_id_mon5'];
    else
        $site_id_mon5 = '0';

    if(!empty($_REQUEST['site_id_tue5']))
        $site_id_tue5 = @$_REQUEST['site_id_tue5'];
    else
        $site_id_tue5 = '0';

    if(!empty($_REQUEST['site_id_wed5']))
        $site_id_wed5 = @$_REQUEST['site_id_wed5'];
    else
        $site_id_wed5 = '0';

    if(!empty($_REQUEST['site_id_thu5']))
        $site_id_thu5 = @$_REQUEST['site_id_thu5'];
    else
        $site_id_thu5 = '0';

    if(!empty($_REQUEST['site_id_fri5']))
        $site_id_fri5 = @$_REQUEST['site_id_fri5'];
    else
        $site_id_fri5 = '0';

    if(!empty($_REQUEST['site_id_sat5']))
        $site_id_sat5 = @$_REQUEST['site_id_sat5'];
    else
        $site_id_sat5 = '0';

    if(!empty($_REQUEST['site_id_sun5']))
        $site_id_sun5 = @$_REQUEST['site_id_sun5'];
    else
        $site_id_sun5 = '0';

    if(!empty($_REQUEST['premium_id_mon5']))
        $premium_id_mon5 = implode(',', @$_REQUEST['premium_id_mon5']);
    else
        $premium_id_mon5 = '';

    if(!empty($_REQUEST['premium_id_tue5']))
        $premium_id_tue5 = implode(',', @$_REQUEST['premium_id_tue5']);
    else
        $premium_id_tue5 = '';

    if(!empty($_REQUEST['premium_id_wed5']))
        $premium_id_wed5 = implode(',', @$_REQUEST['premium_id_wed5']);
    else
        $premium_id_wed5 = '';

    if(!empty($_REQUEST['premium_id_thu5']))
        $premium_id_thu5 = implode(',', @$_REQUEST['premium_id_thu5']);
    else
        $premium_id_thu5 = '';

    if(!empty($_REQUEST['premium_id_fri5']))
        $premium_id_fri5 = implode(',', @$_REQUEST['premium_id_fri5']);
    else
        $premium_id_fri5 = '';

    if(!empty($_REQUEST['premium_id_sat5']))
        $premium_id_sat5 = implode(',', @$_REQUEST['premium_id_sat5']);
    else
        $premium_id_sat5 = '';

    if(!empty($_REQUEST['premium_id_sun5']))
        $premium_id_sun5 = implode(',', @$_REQUEST['premium_id_sun5']);
    else
        $premium_id_sun5 = '';

    $start_date5 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['start_date5']));
    $end_date5 = date("Y-m-d H:i:s", strtotime(@$_REQUEST['end_date5']));

    if($tot1 == 1) {

        if(empty($emp_id1) || empty($_REQUEST['start_date1']))
        { $_SESSION['msg']='Please select employee and start date for employee 1';header('Location:'. $hurl);exit; }

        $sql_site1 = "INSERT INTO tbl_scheduling_by_supervisor(supervisor_id,employee_id,premium_id_mon,premium_id_tue,premium_id_wed,premium_id_thu,premium_id_fri,premium_id_sat,premium_id_sun,site_id_mon,site_id_tue,site_id_wed,site_id_thu,site_id_fri,site_id_sat,site_id_sun,base_rate_mon,base_rate_tue,base_rate_wed,base_rate_thu,base_rate_fri,base_rate_sat,base_rate_sun,in_mon,out_mon,in_tue,out_tue,in_wed,out_wed,in_thu,out_thu,in_fri,out_fri,in_sat,out_sat,in_sun,out_sun,start_date,end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id1."', '".$premium_id_mon1."', '".$premium_id_tue1."', '".$premium_id_wed1."', '".$premium_id_thu1."', '".$premium_id_fri1."', '".$premium_id_sat1."', '".$premium_id_sun1."', '".$site_id_mon1."', '".$site_id_tue1."', '".$site_id_wed1."', '".$site_id_thu1."', '".$site_id_fri1."', '".$site_id_sat1."', '".$site_id_sun1."', '".$base_rate_mon1."', '".$base_rate_tue1."', '".$base_rate_wed1."', '".$base_rate_thu1."', '".$base_rate_fri1."', '".$base_rate_sat1."', '".$base_rate_sun1."',  '".$in_mon1."',  '".$out_mon1."',  '".$in_tue1."',  '".$out_tue1."',  '".$in_wed1."',  '".$out_wed1."',  '".$in_thu1."',  '".$out_thu1."',  '".$in_fri1."',  '".$out_fri1."',  '".$in_sat1."',  '".$out_sat1."',  '".$in_sun1."',  '".$out_sun1."',  '".$start_date1."', '".$end_date1."')";
        //print_r($sql_site1);die;
        $client_data1 = mysqli_query($con, $sql_site1) or die('Something Problem in DB Connection or Query 303');
        mysqli_data_seek($client_data1,0);

        /*************************Save value in timesheet***************************/
            // $dqury = "delete from tbl_timesheet_data where user_id = '".$emp_id1."' and site_id= '".$site_id_mon1."' and in_time='".$in_mon1."' and out_time='".$out_mon1."' and premium_id='".$premium_id_mon1."' and base_rate='".$base_rate_mon1."' and survey_handset_datetime='".date('Y-m-d', strtotime($_REQUEST['start_date1']))."'";
        //$delres = mysqli_query($con, $dqury) ;


        $sqlTmSht1 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id1."', '".$site_id_mon1."', '".$in_mon1."', '".$out_mon1."', '".$premium_id_mon1."', '".$base_rate_mon1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1']))."' ), 
            ('".$emp_id1."', '".$site_id_tue1."', '".$in_tue1."', '".$out_tue1."', '".$premium_id_tue1."', '".$base_rate_tue1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+1 day'))."' ),
            ('".$emp_id1."', '".$site_id_wed1."', '".$in_wed1."', '".$out_wed1."', '".$premium_id_wed1."', '".$base_rate_wed1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+2 day'))."' ),
            ('".$emp_id1."', '".$site_id_thu1."', '".$in_thu1."', '".$out_thu1."', '".$premium_id_thu1."', '".$base_rate_thu1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+3 day'))."' ),
            ('".$emp_id1."', '".$site_id_fri1."', '".$in_fri1."', '".$out_fri1."', '".$premium_id_fri1."', '".$base_rate_fri1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id1."', '".$site_id_sat1."', '".$in_sat1."', '".$out_sat1."', '".$premium_id_sat1."', '".$base_rate_sat1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+5 day'))."' ),
            ('".$emp_id1."', '".$site_id_sun1."', '".$in_sun1."', '".$out_sun1."', '".$premium_id_sun1."', '".$base_rate_sun1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1); // or die('Something Problem in DB Connection or Query 216');
        mysqli_data_seek($res1,0);

        /*$sql_siteRng1 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date1."', '".$end_date1."',1)";
        $client_dataRng1 = mysqli_query($con, $sql_siteRng1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng1,0);*/
        /*********************************End**************************************/
        logger( $_SESSION["user_id"],strtolower($_SESSION["user_type"]),"Supervisor schedule add","Supervisor schedule added",$sqlTmSht1);

    }
    if($tot1 == 2) {

        if(empty($emp_id1) || empty($_REQUEST['start_date1']))
        { $_SESSION['msg']='Please select employee and start date for employee 1';header('Location:'. $hurl);exit;}

        if(empty($emp_id2) || empty($_REQUEST['start_date2']))
        { $_SESSION['msg']='Please select employee and start date for employee 2';header('Location:'. $hurl);exit;}

        $sql_site1 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id1."', '".$premium_id_mon1."', '".$premium_id_tue1."', '".$premium_id_wed1."', '".$premium_id_thu1."', '".$premium_id_fri1."', '".$premium_id_sat1."', '".$premium_id_sun1."', '".$site_id_mon1."', '".$site_id_tue1."', '".$site_id_wed1."', '".$site_id_thu1."', '".$site_id_fri1."', '".$site_id_sat1."', '".$site_id_sun1."', '".$base_rate_mon1."', '".$base_rate_tue1."', '".$base_rate_wed1."', '".$base_rate_thu1."', '".$base_rate_fri1."', '".$base_rate_sat1."', '".$base_rate_sun1."',  '".$in_mon1."',  '".$out_mon1."',  '".$in_tue1."',  '".$out_tue1."',  '".$in_wed1."',  '".$out_wed1."',  '".$in_thu1."',  '".$out_thu1."',  '".$in_fri1."',  '".$out_fri1."',  '".$in_sat1."',  '".$out_sat1."',  '".$in_sun1."',  '".$out_sun1."',  '".$start_date1."', '".$end_date1."')";
        $client_data1 = mysqli_query($con, $sql_site1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data1,0);

        $sql_site2 = "INSERT INTO tbl_scheduling_by_supervisor 
           (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id2."', '".$premium_id_mon2."', '".$premium_id_tue2."', '".$premium_id_wed2."', '".$premium_id_thu2."', '".$premium_id_fri2."', '".$premium_id_sat2."', '".$premium_id_sun2."', '".$site_id_mon2."', '".$site_id_tue2."', '".$site_id_wed2."', '".$site_id_thu2."', '".$site_id_fri2."', '".$site_id_sat2."', '".$site_id_sun2."', '".$base_rate_mon2."', '".$base_rate_tue2."', '".$base_rate_wed2."', '".$base_rate_thu2."', '".$base_rate_fri2."', '".$base_rate_sat2."', '".$base_rate_sun2."', '".$in_mon2."',  '".$out_mon2."',  '".$in_tue2."',  '".$out_tue2."',  '".$in_wed2."',  '".$out_wed2."',  '".$in_thu2."',  '".$out_thu2."',  '".$in_fri2."',  '".$out_fri2."',  '".$in_sat2."',  '".$out_sat2."',  '".$in_sun2."',  '".$out_sun2."',  '".$start_date2."', '".$end_date2."')";
        //echo $sql_site;die;
        $client_data2 = mysqli_query($con, $sql_site2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data2,0);

        /*************************Save value in timesheet***************************/
        $sqlTmSht1 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id1."', '".$site_id_mon1."', '".$in_mon1."', '".$out_mon1."', '".$premium_id_mon1."', '".$base_rate_mon1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1']))."' ), 
            ('".$emp_id1."', '".$site_id_tue1."', '".$in_tue1."', '".$out_tue1."', '".$premium_id_tue1."', '".$base_rate_tue1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+1 day'))."' ),
            ('".$emp_id1."', '".$site_id_wed1."', '".$in_wed1."', '".$out_wed1."', '".$premium_id_wed1."', '".$base_rate_wed1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+2 day'))."' ),
            ('".$emp_id1."', '".$site_id_thu1."', '".$in_thu1."', '".$out_thu1."', '".$premium_id_thu1."', '".$base_rate_thu1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+3 day'))."' ),
            ('".$emp_id1."', '".$site_id_fri1."', '".$in_fri1."', '".$out_fri1."', '".$premium_id_fri1."', '".$base_rate_fri1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id1."', '".$site_id_sat1."', '".$in_sat1."', '".$out_sat1."', '".$premium_id_sat1."', '".$base_rate_sat1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+5 day'))."' ),
            ('".$emp_id1."', '".$site_id_sun1."', '".$in_sun1."', '".$out_sun1."', '".$premium_id_sun1."', '".$base_rate_sun1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht2 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id2."', '".$site_id_mon2."', '".$in_mon2."', '".$out_mon2."', '".$premium_id_mon2."', '".$base_rate_mon2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2']))."' ), 
            ('".$emp_id2."', '".$site_id_tue2."', '".$in_tue2."', '".$out_tue2."', '".$premium_id_tue2."', '".$base_rate_tue2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+1 day'))."' ),
            ('".$emp_id2."', '".$site_id_wed2."', '".$in_wed2."', '".$out_wed2."', '".$premium_id_wed2."', '".$base_rate_wed2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+2 day'))."' ),
            ('".$emp_id2."', '".$site_id_thu2."', '".$in_thu2."', '".$out_thu2."', '".$premium_id_thu2."', '".$base_rate_thu2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+3 day'))."' ),
            ('".$emp_id2."', '".$site_id_fri2."', '".$in_fri2."', '".$out_fri2."', '".$premium_id_fri2."', '".$base_rate_fri2."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id2."', '".$site_id_sat2."', '".$in_sat2."', '".$out_sat2."', '".$premium_id_sat2."', '".$base_rate_sat2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+5 day'))."' ),
            ('".$emp_id2."', '".$site_id_sun2."', '".$in_sun2."', '".$out_sun2."', '".$premium_id_sun2."', '".$base_rate_sun2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        /*$sql_siteRng1 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date1."', '".$end_date1."',1)";
        $client_dataRng1 = mysqli_query($con, $sql_siteRng) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng1,0);

        $sql_siteRng2 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date2."', '".$end_date2."',1)";
        $client_dataRng2 = mysqli_query($con, $sql_siteRng2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng2,0);*/
        /*********************************End**************************************/
    }
    if($tot1 == 3) {

        if(empty($emp_id1) || empty($_REQUEST['start_date1']))
        { $_SESSION['msg']='Please select employee and start date for employee 1';header('Location:'. $hurl);exit; }

        if(empty($emp_id2) || empty($_REQUEST['start_date2']))
        { $_SESSION['msg']='Please select employee and start date for employee 2';header('Location:'. $hurl);exit; }

        if(empty($emp_id3) || empty($_REQUEST['start_date3']))
        { $_SESSION['msg']='Please select employee and start date for employee 3';header('Location:'. $hurl);exit; }

        $sql_site1 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id1."', '".$premium_id_mon1."', '".$premium_id_tue1."', '".$premium_id_wed1."', '".$premium_id_thu1."', '".$premium_id_fri1."', '".$premium_id_sat1."', '".$premium_id_sun1."', '".$site_id_mon1."', '".$site_id_tue1."', '".$site_id_wed1."', '".$site_id_thu1."', '".$site_id_fri1."', '".$site_id_sat1."', '".$site_id_sun1."', '".$base_rate_mon1."', '".$base_rate_tue1."', '".$base_rate_wed1."', '".$base_rate_thu1."', '".$base_rate_fri1."', '".$base_rate_sat1."', '".$base_rate_sun1."',  '".$in_mon1."',  '".$out_mon1."',  '".$in_tue1."',  '".$out_tue1."',  '".$in_wed1."',  '".$out_wed1."',  '".$in_thu1."',  '".$out_thu1."',  '".$in_fri1."',  '".$out_fri1."',  '".$in_sat1."',  '".$out_sat1."',  '".$in_sun1."',  '".$out_sun1."',  '".$start_date1."', '".$end_date1."')";
        $client_data1 = mysqli_query($con, $sql_site1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data1,0);

        $sql_site2 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id2."', '".$premium_id_mon2."', '".$premium_id_tue2."', '".$premium_id_wed2."', '".$premium_id_thu2."', '".$premium_id_fri2."', '".$premium_id_sat2."', '".$premium_id_sun2."', '".$site_id_mon2."', '".$site_id_tue2."', '".$site_id_wed2."', '".$site_id_thu2."', '".$site_id_fri2."', '".$site_id_sat2."', '".$site_id_sun2."', '".$base_rate_mon2."', '".$base_rate_tue2."', '".$base_rate_wed2."', '".$base_rate_thu2."', '".$base_rate_fri2."', '".$base_rate_sat2."', '".$base_rate_sun2."', '".$in_mon2."',  '".$out_mon2."',  '".$in_tue2."',  '".$out_tue2."',  '".$in_wed2."',  '".$out_wed2."',  '".$in_thu2."',  '".$out_thu2."',  '".$in_fri2."',  '".$out_fri2."',  '".$in_sat2."',  '".$out_sat2."',  '".$in_sun2."',  '".$out_sun2."',  '".$start_date2."', '".$end_date2."')";
        //echo $sql_site;die;
        $client_data2 = mysqli_query($con, $sql_site2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data2,0);

        $sql_site3 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id3."', '".$premium_id_mon3."', '".$premium_id_tue3."', '".$premium_id_wed3."', '".$premium_id_thu3."', '".$premium_id_fri3."', '".$premium_id_sat3."', '".$premium_id_sun3."', '".$site_id_mon3."', '".$site_id_tue3."', '".$site_id_wed3."', '".$site_id_thu3."', '".$site_id_fri3."', '".$site_id_sat3."', '".$site_id_sun3."', '".$base_rate_mon3."', '".$base_rate_tue3."', '".$base_rate_wed3."', '".$base_rate_thu3."', '".$base_rate_fri3."', '".$base_rate_sat3."', '".$base_rate_sun3."', '".$in_mon3."',  '".$out_mon3."',  '".$in_tue3."',  '".$out_tue3."',  '".$in_wed3."',  '".$out_wed3."',  '".$in_thu3."',  '".$out_thu3."',  '".$in_fri3."',  '".$out_fri3."',  '".$in_sat3."',  '".$out_sat3."',  '".$in_sun3."', '".$out_sun3."', '".$start_date1."', '".$end_date1."')";
        //echo $sql_site;die;
        $client_data3 = mysqli_query($con, $sql_site3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data3,0);

        /*************************Save value in timesheet***************************/
        $sqlTmSht1 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id1."', '".$site_id_mon1."', '".$in_mon1."', '".$out_mon1."', '".$premium_id_mon1."', '".$base_rate_mon1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1']))."' ), 
            ('".$emp_id1."', '".$site_id_tue1."', '".$in_tue1."', '".$out_tue1."', '".$premium_id_tue1."', '".$base_rate_tue1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+1 day'))."' ),
            ('".$emp_id1."', '".$site_id_wed1."', '".$in_wed1."', '".$out_wed1."', '".$premium_id_wed1."', '".$base_rate_wed1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+2 day'))."' ),
            ('".$emp_id1."', '".$site_id_thu1."', '".$in_thu1."', '".$out_thu1."', '".$premium_id_thu1."', '".$base_rate_thu1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+3 day'))."' ),
            ('".$emp_id1."', '".$site_id_fri1."', '".$in_fri1."', '".$out_fri1."', '".$premium_id_fri1."', '".$base_rate_fri1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id1."', '".$site_id_sat1."', '".$in_sat1."', '".$out_sat1."', '".$premium_id_sat1."', '".$base_rate_sat1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+5 day'))."' ),
            ('".$emp_id1."', '".$site_id_sun1."', '".$in_sun1."', '".$out_sun1."', '".$premium_id_sun1."', '".$base_rate_sun1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht2 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id2."', '".$site_id_mon2."', '".$in_mon2."', '".$out_mon2."', '".$premium_id_mon2."', '".$base_rate_mon2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2']))."' ), 
            ('".$emp_id2."', '".$site_id_tue2."', '".$in_tue2."', '".$out_tue2."', '".$premium_id_tue2."', '".$base_rate_tue2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+1 day'))."' ),
            ('".$emp_id2."', '".$site_id_wed2."', '".$in_wed2."', '".$out_wed2."', '".$premium_id_wed2."', '".$base_rate_wed2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+2 day'))."' ),
            ('".$emp_id2."', '".$site_id_thu2."', '".$in_thu2."', '".$out_thu2."', '".$premium_id_thu2."', '".$base_rate_thu2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+3 day'))."' ),
            ('".$emp_id2."', '".$site_id_fri2."', '".$in_fri2."', '".$out_fri2."', '".$premium_id_fri2."', '".$base_rate_fri2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+4 day'))."' ),
            ('".$emp_id2."', '".$site_id_sat2."', '".$in_sat2."', '".$out_sat2."', '".$premium_id_sat2."', '".$base_rate_sat2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+5 day'))."' ),
            ('".$emp_id2."', '".$site_id_sun2."', '".$in_sun2."', '".$out_sun2."', '".$premium_id_sun2."', '".$base_rate_sun2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht3 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id3."', '".$site_id_mon3."', '".$in_mon3."', '".$out_mon3."', '".$premium_id_mon3."', '".$base_rate_mon3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3']))."' ), 
            ('".$emp_id3."', '".$site_id_tue3."', '".$in_tue3."', '".$out_tue3."', '".$premium_id_tue3."', '".$base_rate_tue3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+1 day'))."' ),
            ('".$emp_id3."', '".$site_id_wed3."', '".$in_wed3."', '".$out_wed3."', '".$premium_id_wed3."', '".$base_rate_wed3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+2 day'))."' ),
            ('".$emp_id3."', '".$site_id_thu3."', '".$in_thu3."', '".$out_thu3."', '".$premium_id_thu3."', '".$base_rate_thu3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+3 day'))."' ),
            ('".$emp_id3."', '".$site_id_fri3."', '".$in_fri3."', '".$out_fri3."', '".$premium_id_fri3."', '".$base_rate_fri3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+4 day'))."' ),
            ('".$emp_id3."', '".$site_id_sat3."', '".$in_sat3."', '".$out_sat3."', '".$premium_id_sat3."', '".$base_rate_sat3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+5 day'))."' ),
            ('".$emp_id3."', '".$site_id_sun3."', '".$in_sun3."', '".$out_sun3."', '".$premium_id_sun3."', '".$base_rate_sun3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+6 day'))."' )";
        $res3 = mysqli_query($con, $sqlTmSht3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res3,0);

        /*$sql_siteRng1 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date1."', '".$end_date1."',1)";
        $client_dataRng1 = mysqli_query($con, $sql_siteRng) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng1,0);

        $sql_siteRng2 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date2."', '".$end_date2."',1)";
        $client_dataRng2 = mysqli_query($con, $sql_siteRng2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng2,0);

        $sql_siteRng3 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date3."', '".$end_date3."',1)";
        $client_dataRng3 = mysqli_query($con, $sql_siteRng3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng3,0);*/

        /*********************************End**************************************/
    }
    if($tot1 == 4) {

        if(empty($emp_id1) || empty($_REQUEST['start_date1']))
        { $_SESSION['msg']='Please select employee and start date for employee 1';header('Location:'. $hurl);exit; }

        if(empty($emp_id2) || empty($_REQUEST['start_date2']))
        { $_SESSION['msg']='Please select employee and start date for employee 2';header('Location:'. $hurl);exit; }

        if(empty($emp_id3) || empty($_REQUEST['start_date3']))
        { $_SESSION['msg']='Please select employee and start date for employee 3';header('Location:'. $hurl);exit; }

        if(empty($emp_id4) || empty($_REQUEST['start_date4']))
        { $_SESSION['msg']='Please select employee and start date for employee 4';header('Location:'. $hurl);exit; }

        $sql_site1 = "INSERT INTO tbl_scheduling_by_supervisor 
           (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id1."', '".$premium_id_mon1."', '".$premium_id_tue1."', '".$premium_id_wed1."', '".$premium_id_thu1."', '".$premium_id_fri1."', '".$premium_id_sat1."', '".$premium_id_sun1."', '".$site_id_mon1."', '".$site_id_tue1."', '".$site_id_wed1."', '".$site_id_thu1."', '".$site_id_fri1."', '".$site_id_sat1."', '".$site_id_sun1."', '".$base_rate_mon1."', '".$base_rate_tue1."', '".$base_rate_wed1."', '".$base_rate_thu1."', '".$base_rate_fri1."', '".$base_rate_sat1."', '".$base_rate_sun1."',  '".$in_mon1."',  '".$out_mon1."',  '".$in_tue1."',  '".$out_tue1."',  '".$in_wed1."',  '".$out_wed1."',  '".$in_thu1."',  '".$out_thu1."',  '".$in_fri1."',  '".$out_fri1."',  '".$in_sat1."',  '".$out_sat1."',  '".$in_sun1."',  '".$out_sun1."',  '".$start_date1."', '".$end_date1."')";
        $client_data1 = mysqli_query($con, $sql_site1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data1,0);

        $sql_site2 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id2."', '".$premium_id_mon2."', '".$premium_id_tue2."', '".$premium_id_wed2."', '".$premium_id_thu2."', '".$premium_id_fri2."', '".$premium_id_sat2."', '".$premium_id_sun2."', '".$site_id_mon2."', '".$site_id_tue2."', '".$site_id_wed2."', '".$site_id_thu2."', '".$site_id_fri2."', '".$site_id_sat2."', '".$site_id_sun2."', '".$base_rate_mon2."', '".$base_rate_tue2."', '".$base_rate_wed2."', '".$base_rate_thu2."', '".$base_rate_fri2."', '".$base_rate_sat2."', '".$base_rate_sun2."', '".$in_mon2."',  '".$out_mon2."',  '".$in_tue2."',  '".$out_tue2."',  '".$in_wed2."',  '".$out_wed2."',  '".$in_thu2."',  '".$out_thu2."',  '".$in_fri2."',  '".$out_fri2."',  '".$in_sat2."',  '".$out_sat2."',  '".$in_sun2."',  '".$out_sun2."',  '".$start_date2."', '".$end_date2."')";
        //echo $sql_site;die;
        $client_data2 = mysqli_query($con, $sql_site2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data2,0);

        $sql_site3 = "INSERT INTO tbl_scheduling_by_supervisor 
           (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id3."', '".$premium_id_mon3."', '".$premium_id_tue3."', '".$premium_id_wed3."', '".$premium_id_thu3."', '".$premium_id_fri3."', '".$premium_id_sat3."', '".$premium_id_sun3."', '".$site_id_mon3."', '".$site_id_tue3."', '".$site_id_wed3."', '".$site_id_thu3."', '".$site_id_fri3."', '".$site_id_sat3."', '".$site_id_sun3."', '".$base_rate_mon3."', '".$base_rate_tue3."', '".$base_rate_wed3."', '".$base_rate_thu3."', '".$base_rate_fri3."', '".$base_rate_sat3."', '".$base_rate_sun3."', '".$in_mon3."',  '".$out_mon3."',  '".$in_tue3."',  '".$out_tue3."',  '".$in_wed3."',  '".$out_wed3."',  '".$in_thu3."',  '".$out_thu3."',  '".$in_fri3."',  '".$out_fri3."',  '".$in_sat3."',  '".$out_sat3."',  '".$in_sun3."', '".$out_sun3."', '".$start_date1."', '".$end_date1."')";
        //echo $sql_site;die;
        $client_data3 = mysqli_query($con, $sql_site3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data3,0);

        $sql_site4 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id4."', '".$premium_id_mon4."', '".$premium_id_tue4."', '".$premium_id_wed4."', '".$premium_id_thu4."', '".$premium_id_fri4."', '".$premium_id_sat4."', '".$premium_id_sun4."', '".$site_id_mon4."', '".$site_id_tue4."', '".$site_id_wed4."', '".$site_id_thu4."', '".$site_id_fri4."', '".$site_id_sat4."', '".$site_id_sun4."', '".$base_rate_mon4."', '".$base_rate_tue4."', '".$base_rate_wed4."', '".$base_rate_thu4."', '".$base_rate_fri4."', '".$base_rate_sat4."', '".$base_rate_sun4."', '".$in_mon4."',  '".$out_mon4."',  '".$in_tue4."',  '".$out_tue4."',  '".$in_wed4."',  '".$out_wed4."',  '".$in_thu4."',  '".$out_thu4."',  '".$in_fri4."',  '".$out_fri4."',  '".$in_sat4."',  '".$out_sat4."',  '".$in_sun4."',  '".$out_sun4."', '".$start_date4."', '".$end_date4."')";
        //echo $sql_site;die;
        $client_data4 = mysqli_query($con, $sql_site4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data4,0);

        /*************************Save value in timesheet***************************/
        $sqlTmSht1 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id1."', '".$site_id_mon1."', '".$in_mon1."', '".$out_mon1."', '".$premium_id_mon1."', '".$base_rate_mon1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1']))."' ), 
            ('".$emp_id1."', '".$site_id_tue1."', '".$in_tue1."', '".$out_tue1."', '".$premium_id_tue1."', '".$base_rate_tue1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+1 day'))."' ),
            ('".$emp_id1."', '".$site_id_wed1."', '".$in_wed1."', '".$out_wed1."', '".$premium_id_wed1."', '".$base_rate_wed1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+2 day'))."' ),
            ('".$emp_id1."', '".$site_id_thu1."', '".$in_thu1."', '".$out_thu1."', '".$premium_id_thu1."', '".$base_rate_thu1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+3 day'))."' ),
            ('".$emp_id1."', '".$site_id_fri1."', '".$in_fri1."', '".$out_fri1."', '".$premium_id_fri1."', '".$base_rate_fri1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id1."', '".$site_id_sat1."', '".$in_sat1."', '".$out_sat1."', '".$premium_id_sat1."', '".$base_rate_sat1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+5 day'))."' ),
            ('".$emp_id1."', '".$site_id_sun1."', '".$in_sun1."', '".$out_sun1."', '".$premium_id_sun1."', '".$base_rate_sun1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht2 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id2."', '".$site_id_mon2."', '".$in_mon2."', '".$out_mon2."', '".$premium_id_mon2."', '".$base_rate_mon2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2']))."' ), 
            ('".$emp_id2."', '".$site_id_tue2."', '".$in_tue2."', '".$out_tue2."', '".$premium_id_tue2."', '".$base_rate_tue2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+1 day'))."' ),
            ('".$emp_id2."', '".$site_id_wed2."', '".$in_wed2."', '".$out_wed2."', '".$premium_id_wed2."', '".$base_rate_wed2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+2 day'))."' ),
            ('".$emp_id2."', '".$site_id_thu2."', '".$in_thu2."', '".$out_thu2."', '".$premium_id_thu2."', '".$base_rate_thu2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+3 day'))."' ),
            ('".$emp_id2."', '".$site_id_fri2."', '".$in_fri2."', '".$out_fri2."', '".$premium_id_fri2."', '".$base_rate_fri2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+4 day'))."' ),
            ('".$emp_id2."', '".$site_id_sat2."', '".$in_sat2."', '".$out_sat2."', '".$premium_id_sat2."', '".$base_rate_sat2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+5 day'))."' ),
            ('".$emp_id2."', '".$site_id_sun2."', '".$in_sun2."', '".$out_sun2."', '".$premium_id_sun2."', '".$base_rate_sun2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht3 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id3."', '".$site_id_mon3."', '".$in_mon3."', '".$out_mon3."', '".$premium_id_mon3."', '".$base_rate_mon3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3']))."' ), 
            ('".$emp_id3."', '".$site_id_tue3."', '".$in_tue3."', '".$out_tue3."', '".$premium_id_tue3."', '".$base_rate_tue3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+1 day'))."' ),
            ('".$emp_id3."', '".$site_id_wed3."', '".$in_wed3."', '".$out_wed3."', '".$premium_id_wed3."', '".$base_rate_wed3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+2 day'))."' ),
            ('".$emp_id3."', '".$site_id_thu3."', '".$in_thu3."', '".$out_thu3."', '".$premium_id_thu3."', '".$base_rate_thu3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+3 day'))."' ),
            ('".$emp_id3."', '".$site_id_fri3."', '".$in_fri3."', '".$out_fri3."', '".$premium_id_fri3."', '".$base_rate_fri3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+4 day'))."' ),
            ('".$emp_id3."', '".$site_id_sat3."', '".$in_sat3."', '".$out_sat3."', '".$premium_id_sat3."', '".$base_rate_sat3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+5 day'))."' ),
            ('".$emp_id3."', '".$site_id_sun3."', '".$in_sun3."', '".$out_sun3."', '".$premium_id_sun3."', '".$base_rate_sun3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+6 day'))."' )";
        $res3 = mysqli_query($con, $sqlTmSht3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res3,0);

        $sqlTmSht4 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id4."', '".$site_id_mon4."', '".$in_mon4."', '".$out_mon4."', '".$premium_id_mon4."', '".$base_rate_mon4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4']))."' ), 
            ('".$emp_id4."', '".$site_id_tue4."', '".$in_tue4."', '".$out_tue4."', '".$premium_id_tue4."', '".$base_rate_tue4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+1 day'))."' ),
            ('".$emp_id4."', '".$site_id_wed4."', '".$in_wed4."', '".$out_wed4."', '".$premium_id_wed4."', '".$base_rate_wed4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+2 day'))."' ),
            ('".$emp_id4."', '".$site_id_thu4."', '".$in_thu4."', '".$out_thu4."', '".$premium_id_thu4."', '".$base_rate_thu4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+3 day'))."' ),
            ('".$emp_id4."', '".$site_id_fri4."', '".$in_fri4."', '".$out_fri4."', '".$premium_id_fri4."', '".$base_rate_fri4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+4 day'))."' ),
            ('".$emp_id4."', '".$site_id_sat4."', '".$in_sat4."', '".$out_sat4."', '".$premium_id_sat4."', '".$base_rate_sat4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+5 day'))."' ),
            ('".$emp_id4."', '".$site_id_sun4."', '".$in_sun4."', '".$out_sun4."', '".$premium_id_sun4."', '".$base_rate_sun4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+6 day'))."' )";
        $res4 = mysqli_query($con, $sqlTmSht4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res4,0);

        /*$sql_siteRng1 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date1."', '".$end_date1."',1)";
        $client_dataRng1 = mysqli_query($con, $sql_siteRng) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng1,0);

        $sql_siteRng2 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date2."', '".$end_date2."',1)";
        $client_dataRng2 = mysqli_query($con, $sql_siteRng2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng2,0);

        $sql_siteRng3 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date3."', '".$end_date3."',1)";
        $client_dataRng3 = mysqli_query($con, $sql_siteRng3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng3,0);

        $sql_siteRng4 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date4."', '".$end_date4."',1)";
        $client_dataRng4 = mysqli_query($con, $sql_siteRng4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng4,0);*/
        /*********************************End**************************************/
    }
    if($tot1 == 5) {

        if(empty($emp_id1) || empty($_REQUEST['start_date1']))
        { $_SESSION['msg']='Please select employee and start date for employee 1';header('Location:'. $hurl);exit; }

        if(empty($emp_id2) || empty($_REQUEST['start_date2']))
        { $_SESSION['msg']='Please select employee and start date for employee 2';header('Location:'. $hurl);exit; }

        if(empty($emp_id3) || empty($_REQUEST['start_date3']))
        { $_SESSION['msg']='Please select employee and start date for employee 3';header('Location:'. $hurl);exit; }

        if(empty($emp_id4) || empty($_REQUEST['start_date4']))
        { $_SESSION['msg']='Please select employee and start date for employee 4';header('Location:'. $hurl);exit; }

        if(empty($emp_id5) || empty($_REQUEST['start_date5']))
        { $_SESSION['msg']='Please select employee and start date for employee 5';header('Location:'. $hurl);exit; }

        echo $sql_site1 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id1."', '".$premium_id_mon1."', '".$premium_id_tue1."', '".$premium_id_wed1."', '".$premium_id_thu1."', '".$premium_id_fri1."', '".$premium_id_sat1."', '".$premium_id_sun1."', '".$site_id_mon1."', '".$site_id_tue1."', '".$site_id_wed1."', '".$site_id_thu1."', '".$site_id_fri1."', '".$site_id_sat1."', '".$site_id_sun1."', '".$base_rate_mon1."', '".$base_rate_tue1."', '".$base_rate_wed1."', '".$base_rate_thu1."', '".$base_rate_fri1."', '".$base_rate_sat1."', '".$base_rate_sun1."',  '".$in_mon1."',  '".$out_mon1."',  '".$in_tue1."',  '".$out_tue1."',  '".$in_wed1."',  '".$out_wed1."',  '".$in_thu1."',  '".$out_thu1."',  '".$in_fri1."',  '".$out_fri1."',  '".$in_sat1."',  '".$out_sat1."',  '".$in_sun1."',  '".$out_sun1."',  '".$start_date1."', '".$end_date1."')";
        $client_data1 = mysqli_query($con, $sql_site1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data1,0);

        $sql_site2 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id2."', '".$premium_id_mon2."', '".$premium_id_tue2."', '".$premium_id_wed2."', '".$premium_id_thu2."', '".$premium_id_fri2."', '".$premium_id_sat2."', '".$premium_id_sun2."', '".$site_id_mon2."', '".$site_id_tue2."', '".$site_id_wed2."', '".$site_id_thu2."', '".$site_id_fri2."', '".$site_id_sat2."', '".$site_id_sun2."', '".$base_rate_mon2."', '".$base_rate_tue2."', '".$base_rate_wed2."', '".$base_rate_thu2."', '".$base_rate_fri2."', '".$base_rate_sat2."', '".$base_rate_sun2."', '".$in_mon2."',  '".$out_mon2."',  '".$in_tue2."',  '".$out_tue2."',  '".$in_wed2."',  '".$out_wed2."',  '".$in_thu2."',  '".$out_thu2."',  '".$in_fri2."',  '".$out_fri2."',  '".$in_sat2."',  '".$out_sat2."',  '".$in_sun2."',  '".$out_sun2."',  '".$start_date2."', '".$end_date2."')";
        //echo $sql_site;die;
        $client_data2 = mysqli_query($con, $sql_site2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data2,0);

        $sql_site3 = "INSERT INTO tbl_scheduling_by_supervisor 
            (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id3."', '".$premium_id_mon3."', '".$premium_id_tue3."', '".$premium_id_wed3."', '".$premium_id_thu3."', '".$premium_id_fri3."', '".$premium_id_sat3."', '".$premium_id_sun3."', '".$site_id_mon3."', '".$site_id_tue3."', '".$site_id_wed3."', '".$site_id_thu3."', '".$site_id_fri3."', '".$site_id_sat3."', '".$site_id_sun3."', '".$base_rate_mon3."', '".$base_rate_tue3."', '".$base_rate_wed3."', '".$base_rate_thu3."', '".$base_rate_fri3."', '".$base_rate_sat3."', '".$base_rate_sun3."', '".$in_mon3."',  '".$out_mon3."',  '".$in_tue3."',  '".$out_tue3."',  '".$in_wed3."',  '".$out_wed3."',  '".$in_thu3."',  '".$out_thu3."',  '".$in_fri3."',  '".$out_fri3."',  '".$in_sat3."',  '".$out_sat3."',  '".$in_sun3."', '".$out_sun3."', '".$start_date1."', '".$end_date1."')";
        //echo $sql_site;die;
        $client_data3 = mysqli_query($con, $sql_site3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data3,0);

        $sql_site4 = "INSERT INTO tbl_scheduling_by_supervisor 
           (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date)  
            VALUES 
            ('".$_SESSION['id']."', '".$emp_id4."', '".$premium_id_mon4."', '".$premium_id_tue4."', '".$premium_id_wed4."', '".$premium_id_thu4."', '".$premium_id_fri4."', '".$premium_id_sat4."', '".$premium_id_sun4."', '".$site_id_mon4."', '".$site_id_tue4."', '".$site_id_wed4."', '".$site_id_thu4."', '".$site_id_fri4."', '".$site_id_sat4."', '".$site_id_sun4."', '".$base_rate_mon4."', '".$base_rate_tue4."', '".$base_rate_wed4."', '".$base_rate_thu4."', '".$base_rate_fri4."', '".$base_rate_sat4."', '".$base_rate_sun4."', '".$in_mon4."',  '".$out_mon4."',  '".$in_tue4."',  '".$out_tue4."',  '".$in_wed4."',  '".$out_wed4."',  '".$in_thu4."',  '".$out_thu4."',  '".$in_fri4."',  '".$out_fri4."',  '".$in_sat4."',  '".$out_sat4."',  '".$in_sun4."',  '".$out_sun4."', '".$start_date4."', '".$end_date4."')";
        //echo $sql_site;die;
        $client_data4 = mysqli_query($con, $sql_site4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data4,0);

        $sql_site5 = "INSERT INTO tbl_scheduling_by_supervisor 
          (
            supervisor_id, employee_id, 

            premium_id_mon, premium_id_tue, premium_id_wed, premium_id_thu, premium_id_fri, premium_id_sat, premium_id_sun,

            site_id_mon, site_id_tue, site_id_wed, site_id_thu, site_id_fri, site_id_sat, site_id_sun, 
            
            base_rate_mon, base_rate_tue, base_rate_wed, base_rate_thu, base_rate_fri, base_rate_sat, base_rate_sun, 
            
            in_mon, out_mon, in_tue, out_tue, in_wed, out_wed, in_thu, out_thu, in_fri, out_fri, in_sat, out_sat, in_sun, out_sun, 

            start_date, end_date) 
            VALUES 
            (
              '".$_SESSION['id']."', '".$emp_id5."', '".$premium_id_mon5."', '".$premium_id_tue5."', '".$premium_id_wed5."', '".$premium_id_thu5."', '".$premium_id_fri5."', '".$premium_id_sat5."', '".$site_id_mon5."', '".$site_id_tue5."', '".$site_id_wed5."', '".$site_id_thu5."', '".$site_id_fri5."', '".$site_id_sat5."', '".$site_id_sun5."', '".$base_rate_mon5."', '".$base_rate_tue5."', '".$base_rate_wed5."', '".$base_rate_thu5."', '".$base_rate_fri5."', '".$base_rate_sat5."', '".$base_rate_sun5."', '".$in_mon5."',  '".$out_mon5."',  '".$in_tue5."',  '".$out_tue5."',  '".$in_wed5."',  '".$out_wed5."',  '".$in_thu5."',  '".$out_thu5."',  '".$in_fri5."',  '".$out_fri5."',  '".$in_sat5."',  '".$out_sat5."',  '".$in_sun5."',  '".$out_sun5."', '".$start_date5."', '".$end_date5."')";
        //echo $sql_site;die;
        $client_data5 = mysqli_query($con, $sql_site5) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data5,0);

        /*************************Save value in timesheet***************************/
        $sqlTmSht1 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id1."', '".$site_id_mon1."', '".$in_mon1."', '".$out_mon1."', '".$premium_id_mon1."', '".$base_rate_mon1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1']))."' ), 
            ('".$emp_id1."', '".$site_id_tue1."', '".$in_tue1."', '".$out_tue1."', '".$premium_id_tue1."', '".$base_rate_tue1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+1 day'))."' ),
            ('".$emp_id1."', '".$site_id_wed1."', '".$in_wed1."', '".$out_wed1."', '".$premium_id_wed1."', '".$base_rate_wed1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+2 day'))."' ),
            ('".$emp_id1."', '".$site_id_thu1."', '".$in_thu1."', '".$out_thu1."', '".$premium_id_thu1."', '".$base_rate_thu1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+3 day'))."' ),
            ('".$emp_id1."', '".$site_id_fri1."', '".$in_fri1."', '".$out_fri1."', '".$premium_id_fri1."', '".$base_rate_fri1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+4 day'))."' ),
            ('".$emp_id1."', '".$site_id_sat1."', '".$in_sat1."', '".$out_sat1."', '".$premium_id_sat1."', '".$base_rate_sat1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+5 day'))."' ),
            ('".$emp_id1."', '".$site_id_sun1."', '".$in_sun1."', '".$out_sun1."', '".$premium_id_sun1."', '".$base_rate_sun1."', '".date('Y-m-d', strtotime($_REQUEST['start_date1'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht2 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id2."', '".$site_id_mon2."', '".$in_mon2."', '".$out_mon2."', '".$premium_id_mon2."', '".$base_rate_mon2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2']))."' ), 
            ('".$emp_id2."', '".$site_id_tue2."', '".$in_tue2."', '".$out_tue2."', '".$premium_id_tue2."', '".$base_rate_tue2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+1 day'))."' ),
            ('".$emp_id2."', '".$site_id_wed2."', '".$in_wed2."', '".$out_wed2."', '".$premium_id_wed2."', '".$base_rate_wed2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+2 day'))."' ),
            ('".$emp_id2."', '".$site_id_thu2."', '".$in_thu2."', '".$out_thu2."', '".$premium_id_thu2."', '".$base_rate_thu2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+3 day'))."' ),
            ('".$emp_id2."', '".$site_id_fri2."', '".$in_fri2."', '".$out_fri2."', '".$premium_id_fri2."', '".$base_rate_fri2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+4 day'))."' ),
            ('".$emp_id2."', '".$site_id_sat2."', '".$in_sat2."', '".$out_sat2."', '".$premium_id_sat2."', '".$base_rate_sat2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+5 day'))."' ),
            ('".$emp_id2."', '".$site_id_sun2."', '".$in_sun2."', '".$out_sun2."', '".$premium_id_sun2."', '".$base_rate_sun2."', '".date('Y-m-d', strtotime($_REQUEST['start_date2'].'+6 day'))."' )";
        $res1 = mysqli_query($con, $sqlTmSht1) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res1,0);

        $sqlTmSht3 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id3."', '".$site_id_mon3."', '".$in_mon3."', '".$out_mon3."', '".$premium_id_mon3."', '".$base_rate_mon3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3']))."' ), 
            ('".$emp_id3."', '".$site_id_tue3."', '".$in_tue3."', '".$out_tue3."', '".$premium_id_tue3."', '".$base_rate_tue3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+1 day'))."' ),
            ('".$emp_id3."', '".$site_id_wed3."', '".$in_wed3."', '".$out_wed3."', '".$premium_id_wed3."', '".$base_rate_wed3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+2 day'))."' ),
            ('".$emp_id3."', '".$site_id_thu3."', '".$in_thu3."', '".$out_thu3."', '".$premium_id_thu3."', '".$base_rate_thu3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+3 day'))."' ),
            ('".$emp_id3."', '".$site_id_fri3."', '".$in_fri3."', '".$out_fri3."', '".$premium_id_fri3."', '".$base_rate_fri3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+4 day'))."' ),
            ('".$emp_id3."', '".$site_id_sat3."', '".$in_sat3."', '".$out_sat3."', '".$premium_id_sat3."', '".$base_rate_sat3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+5 day'))."' ),
            ('".$emp_id3."', '".$site_id_sun3."', '".$in_sun3."', '".$out_sun3."', '".$premium_id_sun3."', '".$base_rate_sun3."', '".date('Y-m-d', strtotime($_REQUEST['start_date3'].'+6 day'))."' )";
        $res3 = mysqli_query($con, $sqlTmSht3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res3,0);

        $sqlTmSht4 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id4."', '".$site_id_mon4."', '".$in_mon4."', '".$out_mon4."', '".$premium_id_mon4."', '".$base_rate_mon4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4']))."' ), 
            ('".$emp_id4."', '".$site_id_tue4."', '".$in_tue4."', '".$out_tue4."', '".$premium_id_tue4."', '".$base_rate_tue4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+1 day'))."' ),
            ('".$emp_id4."', '".$site_id_wed4."', '".$in_wed4."', '".$out_wed4."', '".$premium_id_wed4."', '".$base_rate_wed4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+2 day'))."' ),
            ('".$emp_id4."', '".$site_id_thu4."', '".$in_thu4."', '".$out_thu4."', '".$premium_id_thu4."', '".$base_rate_thu4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+3 day'))."' ),
            ('".$emp_id4."', '".$site_id_fri4."', '".$in_fri4."', '".$out_fri4."', '".$premium_id_fri4."', '".$base_rate_fri4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+4 day'))."' ),
            ('".$emp_id4."', '".$site_id_sat4."', '".$in_sat4."', '".$out_sat4."', '".$premium_id_sat4."', '".$base_rate_sat4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+5 day'))."' ),
            ('".$emp_id4."', '".$site_id_sun4."', '".$in_sun4."', '".$out_sun4."', '".$premium_id_sun4."', '".$base_rate_sun4."', '".date('Y-m-d', strtotime($_REQUEST['start_date4'].'+6 day'))."' )";
        $res4 = mysqli_query($con, $sqlTmSht4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res4,0);

        $sqlTmSht5 = "INSERT INTO tbl_timesheet_data 
            (user_id,site_id,in_time,out_time,premium_id,base_rate,survey_handset_datetime)  VALUES 
            ('".$emp_id5."', '".$site_id_mon5."', '".$in_mon5."', '".$out_mon5."', '".$premium_id_mon5."', '".$base_rate_mon5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5']))."' ), 
            ('".$emp_id5."', '".$site_id_tue5."', '".$in_tue5."', '".$out_tue5."', '".$premium_id_tue5."', '".$base_rate_tue5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+1 day'))."' ),
            ('".$emp_id5."', '".$site_id_wed5."', '".$in_wed5."', '".$out_wed5."', '".$premium_id_wed5."', '".$base_rate_wed5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+2 day'))."' ),
            ('".$emp_id5."', '".$site_id_thu5."', '".$in_thu5."', '".$out_thu5."', '".$premium_id_thu5."', '".$base_rate_thu5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+3 day'))."' ),
            ('".$emp_id5."', '".$site_id_fri5."', '".$in_fri5."', '".$out_fri5."', '".$premium_id_fri5."', '".$base_rate_fri5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+4 day'))."' ),
            ('".$emp_id5."', '".$site_id_sat5."', '".$in_sat5."', '".$out_sat5."', '".$premium_id_sat5."', '".$base_rate_sat5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+5 day'))."' ),
            ('".$emp_id5."', '".$site_id_sun5."', '".$in_sun5."', '".$out_sun5."', '".$premium_id_sun5."', '".$base_rate_sun5."', '".date('Y-m-d', strtotime($_REQUEST['start_date5'].'+6 day'))."' )";
        $res5 = mysqli_query($con, $sqlTmSht5) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($res5,0);

        /*$sql_siteRng1 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date1."', '".$end_date1."',1)";
        $client_dataRng1 = mysqli_query($con, $sql_siteRng) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng1,0);

        $sql_siteRng2 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date2."', '".$end_date2."',1)";
        $client_dataRng2 = mysqli_query($con, $sql_siteRng2) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng2,0);

        $sql_siteRng3 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date3."', '".$end_date3."',1)";
        $client_dataRng3 = mysqli_query($con, $sql_siteRng3) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng3,0);

        $sql_siteRng4 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date4."', '".$end_date4."',1)";
        $client_dataRng4 = mysqli_query($con, $sql_siteRng4) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng4,0);

        $sql_siteRng5 = "INSERT INTO tbl_timesheet_range (start_date, end_date, status) VALUES ( '".$start_date5."', '".$end_date5."',1)";
        $client_dataRng5 = mysqli_query($con, $sql_siteRng5) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_dataRng5,0);*/
        /*********************************End**************************************/
    }
    //header('Location: supervisor-report.php?from_date='.$_REQUEST['start_date'].'&to_date='.$_REQUEST['end_date']);exit;
    header('Location: supervisor-report.php');exit;
}
?>
<div class="content-wrapper" style="min-height: 312px;">
    <section class="content-header">
        <h1 style="">
            Add a new schedule
            <small>#</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="supervisor-report.php">Schedule Report</a></li>
            <li>Add a new schedule</li>
        </ol>
    </section>
    <?php
    $select_sup_ste = "select site_id from tbl_supervisors where id = '".$_SESSION['id']."' ";
    $res_sup_rte = mysqli_query($con, $select_sup_ste) or die('Something Problem in DB Connection or Query');
    mysqli_data_seek($client_data,0);
    $listT = mysqli_fetch_assoc($res_sup_rte);
    if(empty($listT['site_id'])) {
        ?>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">There is no site mapping for this supervisor, please contact admin.</div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    } else {
        $select_site = "select site_id,client_id,id,site_name from tbl_sites where id IN (".$listT['site_id'].") order by site_id";
        $client_data = mysqli_query($con, $select_site) or die('Something Problem in DB Connection or Query');
        mysqli_data_seek($client_data,0);
        while ($list = mysqli_fetch_assoc($client_data))
        {
            $siteArr[]=$list;
        }
        ?>
        <!-- START PAGE CONTENT -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">

                        <div class="box-header">

                            <div class="modal-body">
                                <div class="main-content new" style="padding: 0 !important;">
                                    <div class="panel mb25">
                                        <div style="color:red;"><?php echo $_SESSION['msg']; unset($_SESSION['msg']);?></div>
                                        <form id="add_schedule_form" method="post" name="add_schedule_form"  class="p-t-15" role="form"  action="" autocomplete="off">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group adduser">
                                                        <label for="first-name">How many records to submit</label>
                                                        <select name="tot1" id="tot1" class="form-control" >

                                                            <option value="">-Select/Sélectionner-</option>
                                                            <?php for($ct=1;$ct<6;$ct++) { ?>
                                                                <option value="<?php echo $ct;?>"><?php echo $ct;?></option>
                                                            <?php }?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>

                                            <div id="rtw1" style="display:none;">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Select Employee/Sélectionner un employé</label>
                                                            <select  name="emp_id1" required class="form-control" >
                                                                <option value="">-Select/Sélectionner-</option>
                                                                <?php
                                                                $empId = explode(',', $_SESSION['emp_ids']);
                                                                foreach ($empId as $value)
                                                                {
                                                                    $select_client = "select * from tbl_users where user_id='".$value."'";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    $selected_client='0:00:00';
                                                                    mysqli_data_seek($client_data,0);
                                                                    $dtaClnt = mysqli_fetch_assoc($client_data);
                                                                    ?>
                                                                    <option value="<?php echo $dtaClnt['emp_no'];?>"><?php echo '('.$dtaClnt['emp_no'].') -'.$dtaClnt['first_name'];?></option>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                </div> <!-- row end -->

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul class="scheduletime">
                                                            <li>
                                                                <label>Monday/Lundi</label>
                                                                <input  type="text" name="in_mon1" class="form-control drp timepicker in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_mon1" class="form-control drp timepicker out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_mon1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_mon1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_mon1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val1) { ?>
                                                                        <option value="<?php echo $val1['id']; ?>"><?php echo '('.$val1['site_id'].') -'.$val1['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_mon" name="premium_id_mon1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Tuesday/Mardi</label>
                                                                <input  type="text" name="in_tue1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_tue1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_tue1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_tue1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_tue1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val2) { ?>
                                                                        <option value="<?php echo $val2['id']; ?>"><?php echo '('.$val2['site_id'].') -'.$val2['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_tue" name="premium_id_tue1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Wednesday/Mercredi</label>
                                                                <input  type="text" name="in_wed1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_wed1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_wed1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_wed1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_wed1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val3) { ?>
                                                                        <option value="<?php echo $val3['id']; ?>"><?php echo '('.$val3['site_id'].') -'.$val3['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_wed1" name="premium_id_wed1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Thursday/Jeudi</label>
                                                                <input  type="text" name="in_thu1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input   type="text" name="out_thu1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_thu1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_thu1" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_thu1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val4) { ?>
                                                                        <option value="<?php echo $val4['id']; ?>"><?php echo '('.$val4['site_id'].') -'.$val4['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_thu" name="premium_id_thu1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Friday/Vendredi</label>
                                                                <input  type="text" name="in_fri1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_fri1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_fri1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_fri1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_fri1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val5) { ?>
                                                                        <option value="<?php echo $val5['id']; ?>"><?php echo '('.$val5['site_id'].') -'.$val5['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_fri" name="premium_id_fri1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Saturday/Samedi</label>
                                                                <input  type="text" name="in_sat1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_sat1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_sat1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sat1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_sat1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val6) { ?>
                                                                        <option value="<?php echo $val6['id']; ?>"><?php echo '('.$val6['site_id'].') -'.$val6['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_sat" name="premium_id_sat1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Sunday/Dimanche</label>
                                                                <input  type="text" name="in_sun1" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input  type="text" name="out_sun1" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input  type="text" name="base_rate_sun1" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sun1" class="form-control" placeholder="Premium" >-->
                                                                <select  name="site_id_sun1" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val7) { ?>
                                                                        <option value="<?php echo $val7['id']; ?>"><?php echo '('.$val7['site_id'].') -'.$val7['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select  id="premium_id_sun" name="premium_id_sun1[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div> <!-- row end -->
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Start Date/Date de début</label>
                                                            <input required  type="text" name="start_date1" id="start_date111" class="form-control" >
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">End Date/Date de fin</label>
                                                            <input required  type="text" readonly name="end_date1" id="end_date111" class="form-control">
                                                        </div>
                                                    </div>
                                                </div> <!-- row end -->
                                            </div>

                                            <div id="rtw2" style="display:none;">
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Select Employee/Sélectionner un employé</label>
                                                            <select name="emp_id2" class="form-control" >
                                                                <option value="">-Select/Sélectionner-</option>

                                                                 <?php
                                                                $empId = explode(',', $_SESSION['emp_ids']);
                                                                foreach ($empId as $value)
                                                                {
                                                                    $select_client = "select * from tbl_users where user_id='".$value."'";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    $selected_client='0:00:00';
                                                                    mysqli_data_seek($client_data,0);
                                                                    $dtaClnt = mysqli_fetch_assoc($client_data);
                                                                    ?>
                                                                    <option value="<?php echo $dtaClnt['emp_no'];?>"><?php echo '('.$dtaClnt['emp_no'].') -'.$dtaClnt['first_name'];?></option>
                                                                <?php }?>


                                                            </select>
                                                        </div>
                                                    </div>

                                                </div> <!-- row end -->
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul class="scheduletime">
                                                            <li>
                                                                <label>Monday/Lundi</label>
                                                                <input type="text" name="in_mon2" class="form-control drp timepicker in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_mon2" class="form-control drp timepicker out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_mon2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_mon2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_mon2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val1) { ?>
                                                                        <option value="<?php echo $val1['id']; ?>"><?php echo $val1['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_mon2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Tuesday/Mardi</label>
                                                                <input type="text" name="in_tue2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_tue2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_tue2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_tue2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_tue2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val2) { ?>
                                                                        <option value="<?php echo $val2['id']; ?>"><?php echo $val2['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_tue2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Wednesday/Mercredi</label>
                                                                <input type="text" name="in_wed2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_wed2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_wed2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_wed2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_wed2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val3) { ?>
                                                                        <option value="<?php echo $val3['id']; ?>"><?php echo $val3['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_wed2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Thursday/Jeudi</label>
                                                                <input type="text" name="in_thu2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_thu2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_thu2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_thu2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_thu2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val4) { ?>
                                                                        <option value="<?php echo $val4['id']; ?>"><?php echo $val4['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_thu2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Friday/Vendredi</label>
                                                                <input type="text" name="in_fri2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_fri2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_fri2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_fri2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_fri2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val5) { ?>
                                                                        <option value="<?php echo $val5['id']; ?>"><?php echo $val5['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_fri2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Saturday/Samedi</label>
                                                                <input type="text" name="in_sat2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sat2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sat2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sat2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sat2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val6) { ?>
                                                                        <option value="<?php echo $val6['id']; ?>"><?php echo $val6['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sat2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Sunday/Dimanche</label>
                                                                <input type="text" name="in_sun2" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sun2" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sun2" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sun2" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sun2" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val7) { ?>
                                                                        <option value="<?php echo $val7['id']; ?>"><?php echo $val7['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sun2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div> <!-- row end -->
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Start Date/Date de début</label>
                                                            <input type="text" name="start_date2" id="start_date112" class="form-control" >
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">End Date/Date de fin</label>
                                                            <input type="text" readonly name="end_date2" id="end_date112" class="form-control">
                                                        </div>
                                                    </div>
                                                </div> <!-- row end -->

                                            </div>


                                            <div id="rtw3" style="display:none;">
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Select Employee/Sélectionner un employé</label>
                                                            <select name="emp_id3" class="form-control" >
                                                                <option value="">-Select/Sélectionner-</option>
                                                                <?php
                                                                $empId = explode(',', $_SESSION['emp_ids']);
                                                                foreach ($empId as $value)
                                                                {
                                                                    $select_client = "select * from tbl_users where user_id='".$value."'";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    $selected_client='0:00:00';
                                                                    mysqli_data_seek($client_data,0);
                                                                    $dtaClnt = mysqli_fetch_assoc($client_data);
                                                                    ?>
                                                                    <option value="<?php echo $dtaClnt['emp_no'];?>"><?php echo '('.$dtaClnt['emp_no'].') -'.$dtaClnt['first_name'];?></option>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> <!-- row end -->

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul class="scheduletime">
                                                            <li>
                                                                <label>Monday/Lundi</label>
                                                                <input type="text" name="in_mon3" class="form-control drp timepicker in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_mon3" class="form-control drp timepicker out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_mon3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_mon3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_mon3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val1) { ?>
                                                                        <option value="<?php echo $val1['id']; ?>"><?php echo $val1['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_mon3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Tuesday/Mardi</label>
                                                                <input type="text" name="in_tue3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_tue3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_tue3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_tue3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_tue3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val2) { ?>
                                                                        <option value="<?php echo $val2['id']; ?>"><?php echo $val2['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_tue3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Wednesday/Mercredi</label>
                                                                <input type="text" name="in_wed3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_wed3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_wed3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_wed3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_wed3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val3) { ?>
                                                                        <option value="<?php echo $val3['id']; ?>"><?php echo $val3['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_wed3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Thursday/Jeudi</label>
                                                                <input type="text" name="in_thu3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_thu3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_thu3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_thu3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_thu3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val4) { ?>
                                                                        <option value="<?php echo $val4['id']; ?>"><?php echo $val4['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_thu3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Friday/Vendredi</label>
                                                                <input type="text" name="in_fri3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_fri3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_fri3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_fri3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_fri3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val5) { ?>
                                                                        <option value="<?php echo $val5['id']; ?>"><?php echo $val5['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_fri3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Saturday/Samedi</label>
                                                                <input type="text" name="in_sat3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sat3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sat3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sat3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sat3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val6) { ?>
                                                                        <option value="<?php echo $val6['id']; ?>"><?php echo $val6['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sat2[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>

                                                            <li>
                                                                <label>Sunday/Dimanche</label>
                                                                <input type="text" name="in_sun3" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sun3" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sun3" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sun3" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sun3" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val7) { ?>
                                                                        <option value="<?php echo $val7['id']; ?>"><?php echo $val7['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sun3[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div> <!-- row end -->
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Start Date/Date de début</label>
                                                            <input type="text" name="start_date3" id="start_date113" class="form-control" >
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">End Date/Date de fin</label>
                                                            <input type="text" readonly name="end_date3" id="end_date113" class="form-control">
                                                        </div>
                                                    </div>
                                                </div> <!-- row end -->
                                            </div>

                                            <div id="rtw4" style="display:none;">
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Select Employee/Sélectionner un employé</label>
                                                            <select name="emp_id4" class="form-control" >
                                                                <option value="">-Select/Sélectionner-</option>
                                                                <?php
                                                                $empId = explode(',', $_SESSION['emp_ids']);
                                                                foreach ($empId as $value)
                                                                {
                                                                    $select_client = "select * from tbl_users where user_id='".$value."'";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    $selected_client='0:00:00';
                                                                    mysqli_data_seek($client_data,0);
                                                                    $dtaClnt = mysqli_fetch_assoc($client_data);
                                                                    ?>
                                                                   <option value="<?php echo $dtaClnt['emp_no'];?>"><?php echo '('.$dtaClnt['emp_no'].') -'.$dtaClnt['first_name'];?></option>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                </div> <!-- row end -->
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul class="scheduletime">
                                                            <li>
                                                                <label>Monday/Lundi</label>
                                                                <input type="text" name="in_mon4" class="form-control drp timepicker in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_mon4" class="form-control drp timepicker out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_mon4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_mon4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val1) { ?>
                                                                        <option value="<?php echo $val1['id']; ?>"><?php echo $val1['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_mon4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Tuesday/Mardi</label>
                                                                <input type="text" name="in_tue4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_tue4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_tue4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_tue4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val2) { ?>
                                                                        <option value="<?php echo $val2['id']; ?>"><?php echo $val2['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_tue4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Wednesday/Mercredi</label>
                                                                <input type="text" name="in_wed4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_wed4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_wed4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_wed4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val3) { ?>
                                                                        <option value="<?php echo $val3['id']; ?>"><?php echo $val3['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_wed4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Thursday/Jeudi</label>
                                                                <input type="text" name="in_thu4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_thu4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_thu4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_thu4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val4) { ?>
                                                                        <option value="<?php echo $val4['id']; ?>"><?php echo $val4['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_thu4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Friday/Vendredi</label>
                                                                <input type="text" name="in_fri4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_fri4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_fri4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_fri4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val5) { ?>
                                                                        <option value="<?php echo $val5['id']; ?>"><?php echo $val5['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>

                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_fri4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Saturday/Samedi</label>
                                                                <input type="text" name="in_sat4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sat4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sat4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_sat4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val6) { ?>
                                                                        <option value="<?php echo $val6['id']; ?>"><?php echo $val6['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sat4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Sunday/Dimanche</label>
                                                                <input type="text" name="in_sun4" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sun4" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sun4" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_sun4" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val7) { ?>
                                                                        <option value="<?php echo $val7['id']; ?>"><?php echo $val7['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sun4[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Start Date/Date de début</label>
                                                            <input type="text" name="start_date4" id="start_date114" class="form-control" >
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">End Date/Date de fin</label>
                                                            <input type="text" readonly name="end_date4" id="end_date114" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="rtw5" style="display:none;">
                                                <hr>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Select Employee/Sélectionner un employé</label>
                                                            <select name="emp_id5" class="form-control" >
                                                                <option value="">-Select/Sélectionner-</option>
                                                                <?php
                                                                $empId = explode(',', $_SESSION['emp_ids']);
                                                                foreach ($empId as $value) {
                                                                    $select_client = "select * from tbl_users where user_id='".$value."'";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    $selected_client='0:00:00';
                                                                    mysqli_data_seek($client_data,0);
                                                                    $dtaClnt = mysqli_fetch_assoc($client_data);
                                                                    ?>
                                                                    <option value="<?php echo $dtaClnt['emp_no'];?>"><?php echo '('.$dtaClnt['emp_no'].') -'.$dtaClnt['first_name'];?></option>
                                                                <?php }?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <ul class="scheduletime">
                                                            <li>
                                                                <label>Monday/Lundi</label>
                                                                <input type="text" name="in_mon5" class="form-control drp timepicker in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_mon5" class="form-control drp timepicker out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_mon5" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_mon5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val1) { ?>
                                                                        <option value="<?php echo $val1['id']; ?>"><?php echo $val1['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_mon5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Tuesday/Mardi</label>
                                                                <input type="text" name="in_tue5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_tue5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_tue5" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_tue" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val2) { ?>
                                                                        <option value="<?php echo $val2['id']; ?>"><?php echo $val2['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_tue5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Wednesday/Mercredi</label>
                                                                <input type="text" name="in_wed5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_wed5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_wed5" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_wed5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val3) { ?>
                                                                        <option value="<?php echo $val3['id']; ?>"><?php echo $val3['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_wed5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Thursday/Jeudi</label>
                                                                <input type="text" name="in_thu5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_thu5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_thu5" class="form-control" placeholder="Rate/Taux" >
                                                                <select name="site_id_thu5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val4) { ?>
                                                                        <option value="<?php echo $val4['id']; ?>"><?php echo $val4['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_thu5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Friday/Vendredi</label>
                                                                <input type="text" name="in_fri5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_fri5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_fri5" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_fri5" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_fri5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val5) { ?>
                                                                        <option value="<?php echo $val5['id']; ?>"><?php echo $val5['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_fri5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Saturday/Samedi</label>
                                                                <input type="text" name="in_sat5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sat5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sat5" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sat5" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sat5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val6) { ?>
                                                                        <option value="<?php echo $val6['id']; ?>"><?php echo $val6['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sat5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                            <li>
                                                                <label>Sunday/Dimanche</label>
                                                                <input type="text" name="in_sun5" class="form-control in_time" placeholder="In Time/À l'heure">
                                                                <input type="text" name="out_sun5" class="form-control out_time" placeholder="Out Time/Temps de sortie">
                                                                <input type="text" name="base_rate_sun5" class="form-control" placeholder="Rate/Taux" >
                                                                <!--<input type="text" name="site_premium_sun5" class="form-control" placeholder="Premium" >-->
                                                                <select name="site_id_sun5" class="form-control" >
                                                                    <option value="">-Site-</option>
                                                                    <?php foreach ($siteArr as $key => $val7) { ?>
                                                                        <option value="<?php echo $val7['id']; ?>"><?php echo $val7['site_name']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                                <label>Decret Premium</label>
                                                                <select name="premium_id_sun5[]" class="site_dropdown select2" multiple placeholder="Decret Premium">
                                                                    <?php
                                                                    $select_client = "select * from tbl_price";
                                                                    $client_data = mysqli_query($con, $select_client) or die('Something Problem in DB Connection or Query');
                                                                    mysqli_data_seek($client_data,0);
                                                                    while ($list = mysqli_fetch_assoc($client_data)) {
                                                                        ?>
                                                                        <option value="<?php echo $list['id']; ?>"><?php echo $list['prime_type']; ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                                <br>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">Start Date/Date de début</label>
                                                            <input type="text" name="start_date5" id="start_date115" class="form-control" >
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group adduser">
                                                            <label for="first-name">End Date/Date de fin</label>
                                                            <input type="text" readonly name="end_date5" id="end_date115" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row" id="bttnId" style="display:none;">
                                                <div class="col-md-12">
                                                    <input type="submit" name="insert_schedule" id="application-user" class="btn btn-primary button-next" value="Submit/Soumettre">
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php }?>
</div>
<link rel="stylesheet" href="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/ui-lightness/jquery-ui-1.10.0.custom.min.css" type="text/css" />
<link rel="stylesheet" href="assets/plugins/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.css?v=0.3.3" type="text/css" />
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.core.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.widget.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.tabs.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.position.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.js?v=0.3.3"></script>
<link rel="stylesheet" href="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/ui-lightness/jquery-ui-1.10.0.custom.min.css" type="text/css" />
<link rel="stylesheet" href="assets/plugins/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.css?v=0.3.3" type="text/css" />
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.core.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.widget.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.tabs.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/include/ui-1.10.0/jquery.ui.position.min.js"></script>
<script type="text/javascript" src="assets/plugins/jquery-ui-timepicker-0.3.3/jquery.ui.timepicker.js?v=0.3.3"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.in_time').timepicker({
            showLeadingZero: false,
            onSelect: tpStartSelect,
            hours: {
                starts: 0,                // First displayed hour
                ends: 24                  // Last displayed hour
            },
            minutes: {
                starts: 0,                // First displayed minute
                ends: 55,                 // Last displayed minute
                interval: 5,              // Interval of displayed minutes
                manual: []                // Optional extra entries for minutes
            },
            rows: 5,                      // Number of rows for the input tables, minimum 2, makes more sense if you use multiple of 2
            showHours: true,              // Define if the hours section is displayed or not. Set to false to get a minute only dialog
            showMinutes: true,            // Define if the minutes section is displayed or not. Set to false to get an hour only dialog

            maxTime: {
                hour: 23, minute: 55
            }
        });
        $('.out_time').timepicker({
            showLeadingZero: false,
            onSelect: tpEndSelect,
            hours: {
                starts: 0,                // First displayed hour
                ends: 24                  // Last displayed hour
            },
            minutes: {
                starts: 0,                // First displayed minute
                ends: 55,                 // Last displayed minute
                interval: 5,              // Interval of displayed minutes
                manual: []                // Optional extra entries for minutes
            },
            rows: 5,                      // Number of rows for the input tables, minimum 2, makes more sense if you use multiple of 2
            showHours: true,              // Define if the hours section is displayed or not. Set to false to get a minute only dialog
            showMinutes: true,            // Define if the minutes section is displayed or not. Set to false to get an hour only dialog

            minTime: {
                hour: 9, minute: 15
            }
        });
    });
    // when start time change, update minimum for end timepicker
    function tpStartSelect( time, endTimePickerInst ) {
        $('.out_time').timepicker('option', {
            minTime: {
                hour: endTimePickerInst.hours,
                minute: endTimePickerInst.minutes
            }
        });
    }
    // when end time change, update maximum for start timepicker
    function tpEndSelect( time, startTimePickerInst ) {
        $('.in_time').timepicker('option', {
            maxTime: {
                hour: startTimePickerInst.hours,
                minute: startTimePickerInst.minutes
            }
        });
    }
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $("#employee_filter_select").on('change', function(){
            var selected = $(this).val();
            if(selected !== null) {
                if(selected.indexOf('all') >= 0) {
                    $(this).val('all').select2();
                }
            }
        });
    });
</script>
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script>
    $( function() {
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date" )
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        //alert(date2);
                        //$('#end_date').datepicker('setDate', date2);
                        $('#end_date').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());
                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date111" )
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date111').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        $('#end_date111').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());
                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
    } );
    $( function() {
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date112" )
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date112').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        $('#end_date112').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());
                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
    } );
    $( function() {
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date113" )
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date113').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        $('#end_date113').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());

                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
    } );
    $( function() {
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date114" )
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date114').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        $('#end_date114').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());
                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
    } );
    $( function() {
        var dateFormat = "mm/dd/yy",
            from = $( "#start_date115")
                .datepicker({
                    defaultDate: "+1w",
                    changeMonth: true,
                    numberOfMonths: 1,
                    minDate: 0,
                    beforeShowDay: function(date) {
                        return [date.getDay() == 1];
                    },
                    onSelect: function (date) {
                        var date2 = $('#start_date115').datepicker('getDate');
                        date2.setDate(date2.getDate() + 6);
                        //alert(date2);
                        //$('#end_date').datepicker('setDate111', date2);
                        $('#end_date115').val((date2.getMonth() + 1) + '/' + date2.getDate() + '/' +  date2.getFullYear());
                    }
                })
                .on( "change", function() {
                    to.datepicker( "option", "minDate", getDate( this ) );
                });
    } );
    $(document).ready(function() {
        $("#tot1").change(function() {
            var vl = $('#tot1').val();
            if(vl == 1) {
                $('#rtw1').show();
                $('#rtw2').hide();
                $('#rtw3').hide();
                $('#rtw4').hide();
                $('#rtw5').hide();
                $('#bttnId').show();
            }
            else if(vl == 2) {
                $('#rtw1').show();
                $('#rtw2').show();
                $('#rtw3').hide();
                $('#rtw4').hide();
                $('#rtw5').hide();
                $('#bttnId').show();
            }
            else if(vl == 3) {
                $('#rtw1').show();
                $('#rtw2').show();
                $('#rtw3').show();
                $('#rtw4').hide();
                $('#rtw5').hide();
                $('#bttnId').show();
            }
            else if(vl == 4) {
                $('#rtw1').show();
                $('#rtw2').show();
                $('#rtw3').show();
                $('#rtw4').show();
                $('#rtw5').hide();
                $('#bttnId').show();
            }
            else if(vl == 5) {
                $('#rtw1').show();
                $('#rtw2').show();
                $('#rtw3').show();
                $('#rtw4').show();
                $('#rtw5').show();
                $('#bttnId').show();
            }
            else {
                $('#rtw1').hide();
                $('#rtw2').hide();
                $('#rtw3').hide();
                $('#rtw4').hide();
                $('#rtw5').hide();
                $('#bttnId').hide();
            }
        });
    });
</script>
<style>
    .daterangepicker td.in-range {
        background-color: #e0e0e0;
        border-color: transparent;
        color: #000;
        border-radius: 0;
    }
    .ui-timepicker-table td a, .ui-timepicker-table td span{width: 2.5em;}
    .select2-container--default .select2-selection--multiple .select2-selection__choice{background-color: #00BCD4!important;}
    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove { color: #F44336!important;}
    .scheduletime{list-style:none;width:100%;display:block;padding:0;margin:0;text-align:center;}
    .scheduletime:after{clear:both;display:table;content:"";}
    .scheduletime li{width:14.28%;float:left;padding:0 6px;}
    .scheduletime li:first-child{padding-left: 0}
    .scheduletime li:last-child{padding-right: 0}
    .scheduletime input::-webkit-input-placeholder { /* Chrome/Opera/Safari */font-size: 11px;}
    .scheduletime input::-moz-placeholder { /* Firefox 19+ */font-size: 11px;}
    .scheduletime input:-ms-input-placeholder { /* IE 10+ */font-size: 11px;}
    .scheduletime input:-moz-placeholder { /* Firefox 18- */font-size: 11px;}
    .scheduletime .form-control{padding: 3px 3px !important;}
    .scheduletime li label{font-size: 12px;}
    .select2-container--default .select2-selection--multiple .select2-selection__rendered li {width: 50px;}
    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{margin-right: 2px;
    @media (min-width: 992px) {
        .modal-lg {
            width: 1050px !important;
        }
    }
</style>
<?php include('inc/footer.php'); ?>
