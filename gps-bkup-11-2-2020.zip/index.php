<?php 
    $userid = $_REQUEST["user_id"];
    $domain = $_REQUEST["domain"];
?>
<!DOCTYPE html>
<html style="background: #eeeeee;">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="user-scalable=no">
  <title>Neptune inc</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  
    <link rel="stylesheet" href="https://www.neptunetimesheets.com/admin-v2/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="https://www.neptunetimesheets.com/admin-v2/assets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="https://www.neptunetimesheets.com/admin-v2/assets/dist/css/skins/_all-skins.min.css">
    
    <link rel="stylesheet" href="https://p1.neptunetimesheets.com/admin-v2/assets/plugins/select2/select2.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <style>.disabled{opacity: 1; background-color: #989898 !important; pointer-events: none;} .info-box{cursor: pointer;}
  .select2-container--open .select2-dropdown--below,.select2-container--default .select2-selection--single{min-height: 35px!important;width: 87vw!important;}
  .select2-container--default .select2-selection--single .select2-selection__arrow{display:none;}
  </style>
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a  class="logo">
      <span class="logo-lg"><b><?php  if (\strpos($domain, 'p1') !== false) { echo "P1";}else{ echo "P0"; } ?></b> : Neptune Punching</span>
    </a>
    
  </header>

  

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header" id="gps">Please wait</section>    
    <section class="content-header" id="gps">
        <a href="https://<?php  if (\strpos($domain, 'p1') !== false) { echo "P1.";}else{ echo "www."; } ?>neptunetimesheets.com/admin-v2/v3/tracking-management-system/mobile-view?user_id=<?php echo $userid; ?>" class="btn btn-warning">Start location syncing</a>
    </section> 
  </div>
   <section class="content" style="background: #eee;">
      <div class="box">
        <div class="box-body">
            
            <div class="form-group">
                <label for="first-name" style="width:100%;">Client/Site</label>
                <select required="" id="site_id" name="site_id" class="site_dropdown select2 select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                    <?php 
                        if (\strpos($domain, 'p1') !== false) { 
                            $site_api = "http://p1.neptunetimesheets.com/ajax/site_and_prime_list.php?&user_id=".$userid;
                        }else{ 
                            $site_api = "https://www.neptunetimesheets.com/ajax/site_and_prime_list.php?&user_id=".$userid;
                        } 
//                        echo $site_api;
                        $site_list = file_get_contents( $site_api );
                        $site_list = json_decode($site_list, true);
//                        print_r($site_list);
                        if(isset($_REQUEST["site_id"]) && $_REQUEST["site_id"] !="" ){
                            if( count($site_list["response_data"]["client_details"]) > 0 ){
                            foreach( $site_list["response_data"]["client_details"] as $site){
                                if($_REQUEST["site_id"] == $site["id"]){
                                echo '<option '.($_REQUEST["site_id"] == $site["id"] ? "selected":"").' value="'.$site["id"].'">'.$site["site_name"].'</option>';
                                
                                }
                            }
                        }
                        
                        }else{
                    ?>
                    <option value="">Select a site</option>
                    <?php 
                        if( count($site_list["response_data"]["client_details"]) > 0 ){
                            foreach( $site_list["response_data"]["client_details"] as $site){
                                echo '<option '.($_REQUEST["site_id"] == $site["id"] ? "selected":"").' value="'.$site["id"].'">'.$site["site_name"].'</option>';
                            }
                        }   
                        
                        
                        }
                        
                    ?>
                    
                    
                </select>
            </div>

            
            
            <!-- /.info-box -->
          <div class="info-box bg-green disabled"  id="punchin">
            <span class="info-box-icon"><i class="fa fa-calendar-plus-o"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">Punch in</span>
              <span class="info-box-text" id="punchin-time">-</span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
              <span class="progress-description" id="punchin-location">-</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
          
          <!-- /.info-box -->
         <div class="info-box bg-green disabled" id="punchout">
            <span class="info-box-icon"><i class="fa fa-calendar-check-o"></i></span>

             <div class="info-box-content">
              <span class="info-box-number">Punch out</span>
              <span class="info-box-text" id="punchout-time">-</span>

              <div class="progress">
                <div class="progress-bar" style="width: 100%"></div>
              </div>
              <span class="progress-description" id="punchout-location">-</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
            
            <br /> <br /> <br /> <br /> 
            <button id="reset_btn" type="button" class="btn btn-block btn-danger btn-xs">Click me to reset this, select a  new site or punch in again ?</button>
            
            
        </div>
      </div>
   </section>
</div>
</body>
</html>
<script src="https://www.neptunetimesheets.com/admin-v2/assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="https://p1.neptunetimesheets.com/admin-v2/assets/plugins/select2/select2.full.min.js"></script>


<script>
    

     <?php  if(isset($_REQUEST["site_id"]) && $_REQUEST["site_id"] !="" ){ ?>
        
    $(document).ready(function(){ 
            
            punchInDone();
            punchOutDone();
//            getLocation(); 
        });
    <?php } ?>
    window.setInterval(function(){
            getLocation();
            
      }, 5000);
    function punchInDone(){
            var punchin_data = localStorage.getItem("punchin_data");
                punchin_data = JSON.parse(punchin_data);
                
            if( punchin_data !== null ){
                //enable punch out
                $("#punchin").addClass("disabled");
                $("#punchout").removeClass("disabled");

                $("#punchin #punchin-time").html("Time : "+punchin_data.punchin_time);
                $("#punchin #punchin-location").html("Location : "+punchin_data.punchin_location);
            }else{
                //enable punch in
                $("#punchin").removeClass("disabled");
                $("#punchout").addClass("disabled");

                $("#punchin #punchin-time").html("-");
                $("#punchin #punchin-location").html("-");
            }
       }
    function punchOutDone(){
            var punchout_data = localStorage.getItem("punchout_data");
                punchout_data = JSON.parse(punchout_data);
                
            if( punchout_data !== null ){
                //enable punch out
                $("#punchin").addClass("disabled");
                $("#punchout").addClass("disabled");

                $("#punchout #punchout-time").html("Time : "+punchout_data.punchout_time);
                $("#punchout #punchout-location").html("Location : "+punchout_data.punchout_location);
            }else{
                //enable punch in
                $("#punchin").removeClass("disabled");
                $("#punchout").addClass("disabled");

                $("#punchout #punchout-time").html("-");
                $("#punchout #punchout-location").html("-");
            }
       }
       
    $(document).ready(function(){
       
       
       
       
        $("#reset_btn").click( function(){
            if(confirm("Are you sure you want to reset this screen ?")){
                localStorage.clear();
                var url = "https://www.neptunetimesheets.com/gps/?<?php echo str_replace('&site_id='.$_GET['site_id'], '', $_SERVER['QUERY_STRING']);?>";
            
            window.location = url;
            }else{
                alert("Cancelled");
            }
        });
        
        $(".select2").select2({
            sorter: function(data) {
                return data.sort();
            }
        });
       
       localStorage.setItem("userid","<?php echo $userid; ?>");
       
       $("#site_id").change(function () {
            var site_id = this.value;
            var url = "https://www.neptunetimesheets.com/gps/?<?php echo str_replace('&site_id='.$_GET['site_id'], '', $_SERVER['QUERY_STRING']);?>&site_id="+site_id;
            
            window.location = url;
        });
       $("#punchin").click(function (e) {
            e.preventDefault();
            var current_location = localStorage.getItem("location");
            var punchin_data = localStorage.getItem("punchin_data");
            $.ajax({
                url: '<?php echo $domain; ?>ajax/add-punch-in.php?&user_id=<?php echo $_REQUEST["user_id"]; ?>&site_id=<?php echo $_REQUEST["site_id"]; ?>&punch_in_location='+current_location,
                success: function (data) {
                    data = JSON.parse(data);
                    console.log(data);
                    console.log(data.response_data);
                    localStorage.setItem("punchin_data", JSON.stringify(data.response_data) );
                    punchInDone();
                }
            });
        });
       $("#punchout").click(function (e) {
            e.preventDefault();
            var current_location = localStorage.getItem("location");
            var punchin_data = localStorage.getItem("punchin_data");
                punchin_data = JSON.parse(punchin_data);
            $.ajax({
                url: '<?php echo $domain?>ajax/add-punch-out.php?punch_out_location='+current_location+'&punch_in_id='+punchin_data.punchin_id,
                success: function (data) {
                    data = JSON.parse(data);
                    $("#punchin").addClass("disabled");
                    $("#punchout").removeClass("disabled");
                  
                    localStorage.setItem("punchout_data", JSON.stringify(data.response_data) );
                    punchOutDone();
                }
            });
        });
        
       
       
       
       
       
    });
   
    
    
    
var x = document.getElementById("gps");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
    
    
navigator.permissions.query({
     name: 'geolocation'
 }).then(function(result) {
     if (result.state == 'granted') {
//         report(result.state);
//         geoBtn.style.display = 'none';
//        alert("granted");
     } else if (result.state == 'prompt') {
//         alert("prompt");
     } else if (result.state == 'denied') {
//         alert("denied");
         $("#gps").html('Seems that you have disallowed the location, please allow the same.');
     }else{
//         alert("else");
     }
     
 });
    
    
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Your location is " + position.coords.latitude + "," + position.coords.longitude;
  localStorage.setItem("location", position.coords.latitude + "," + position.coords.longitude);
  localStorage.setItem("location_store_time", Math.floor(Date.now() / 1000) );
}




</script>