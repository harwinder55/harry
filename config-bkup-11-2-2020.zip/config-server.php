<?php
error_reporting(0);
session_start();
date_default_timezone_set("Canada/Eastern");
//date_default_timezone_set("Asia/Kolkata");
define('DB_HOST', 'naptune-timesheet.cdqkjqzzhtsg.us-west-2.rds.amazonaws.com');
define('DB_USER', 'nap_timesheet');
define('DB_PASSWORD', 'Gulruba390*');
define('DB_NAME', 'naptune_timesheet');
define("PATH", "https://www.neptunetimesheets.com/testingserver/");
define('MAIN_URL', 'https://www.neptunetimesheets.com/testingserver/admin-v2/');
$con = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME) or die("do not connect");
mysqli_query($con,"SET SESSION group_concat_max_len = 1000000");
require_once("functions.php");
?>