<?php
$lang_array = array();
$lang_array["English"] = array();
$lang_array["French"] = array();

$lang_array["English"]["Dashboard"] = "Dashboard";
$lang_array["French"]["Dashboard"] = "Tableau de Bord";