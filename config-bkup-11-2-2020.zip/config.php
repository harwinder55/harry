<?php
error_reporting(0);
//error_reporting(E_ALL);
//ini_set('display_errors', 1);
session_start();
date_default_timezone_set("Canada/Eastern");
//date_default_timezone_set("Asia/Kolkata");
define('DB_HOST', 'naptune-timesheet.cdqkjqzzhtsg.us-west-2.rds.amazonaws.com');
define('DB_USER', 'nap_timesheet');
define('DB_PASSWORD', 'Gulruba390*');
define('DB_NAME', 'naptune_timesheet');
define("PATH", "https://www.neptunetimesheets.com/");
define('MAIN_URL', 'https://www.neptunetimesheets.com/admin-v2/');
define('CACHE_PATH','/var/www/html/');
$con = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME) or die("do not connect");


if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

mysqli_query($con,"SET SESSION group_concat_max_len = 1000000");
require_once("functions.php");
?>
