<?php

$response = array();
$response["status"] = "success";
$client_array = array();

$client_array[1] = array("client_name" => "Tata",
						"site_list" => array(
								"1"=>"patna",
								"2"=>"Shimla",
							)
					);


$client_array[4] = array("client_name" => "CI",
						"site_list" => array(
								"1121"=>"Badarpur",
								"28989"=>"Noida",
								"12738"=>"FBD",
							)
					);


$response["data"] = $client_array;

echo json_encode($response);