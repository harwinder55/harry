<?php
require_once('config/config.php');
header('Access-Control-Allow-Origin: *');
header("Content-Type: application/json;charset=utf-8");
date_default_timezone_set("Asia/Kolkata");

$response = array();
$client_details = array();
$location_details = array();
$site_detail = array();
$response["status"] = "success";
$client_array = array();
$clientID = $_REQUEST['client_id'];
if(isset($clientID) && $clientID != '')
    $client_detail = "select id,client_name from tbl_client where id='".$clientID."'";
else
    $client_detail = "select id,client_name from tbl_client";

$result = mysqli_query($con,$client_detail);
while($row = mysqli_fetch_assoc($result)){
    $client_details[$row['id']] = $row;
}
if(isset($clientID) && $clientID != '')
    $location = "select client_id,site_id,site_name from tbl_location where client_id='".$clientID."'";
else
    $location = "select client_id,site_id,site_name from tbl_location";
$result = mysqli_query($con,$location);
while($row = mysqli_fetch_assoc($result)) {
    $location_details[$row['client_id']][$row['site_id']][] = $row['site_name'];
}
foreach($client_details as $client_value) {
    foreach($location_details as $key=>$location_value) {
        if($client_value['id'] == $key)
            $site_detail['site_name'] = $location_value;
    }
    $response['data'][$client_value['id']] = array("client_id"=>$client_value['id'],"client_name"=>$client_value['client_name'],$site_detail);
}
echo json_encode($response);