<!DOCTYPE html> 
<html class=no-js>
   <head>
      <meta charset=utf-8>
      <title>Neptune - Admin Dashboard</title>
      <meta name=description content="">
      <meta name=viewport content="width=device-width">
      
      <link rel="shortcut icon" href=http://urban.nyasha.me/favicon.ec0f3a1b.ico>
      <link rel="stylesheet" href="admin/assets/styles/app.min.df5e9cc9.css">
   <body>
      <div class="app layout-fixed-header bg-white usersession">
         <div class=full-height>
            <div class=center-wrapper>
               <div class=center-content>
                  <div class="row no-margin">
					<div class="col-md-4">
						<form id="user-form-login" action="" class=form-layout method="post" style="margin-top: 30%;">
                           <div class="text-center mb15"> <img src="admin/assets/images/logologo.png" style="width:15%;"> </div>
                           <p class="text-center mb30">Please sign in to <b>user</b> account</p>
                           <div class=form-inputs> 
						   <input type=text name="emp_id" id="emp_id" class="form-control input-lg" placeholder="Enter Employee No" required>
						   <input type=password name="emp_password"  id="emp_password" class="form-control input-lg" placeholder=Password required>
						   </div>
                           <input type="submit" name="user_login" id="user_login" value="LogIn" class="btn btn-success btn-block btn-lg mb15"></a>
                        </form>
					</div> 
                     <div class="col-md-4 col-md-offset-2">
                        <form id="form-login" action="" class=form-layout method="post" style="margin-top: 30%;">
                           <div class="text-center mb15"> <img src="admin/assets/images/logologo.png" style="width:15%;"> </div>
                           <p class="text-center mb30">Please sign in to <b>admin</b> account</p>
                           <div class=form-inputs> 
						   <input type=text name="login_id" id="login_id" class="form-control input-lg" placeholder="Email Address" required>
						   <input type=password name="password"  id="password" class="form-control input-lg" placeholder=Password required>
						   </div>
                           <input type="submit" name="login" id="login" value="LogIn" class="btn btn-success btn-block btn-lg mb15"></a>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
    
	  
<script src="admin/assets/scripts/app.min.4fc8dd6e.js"></script> 
<script src="admin/assets/vendor/d3/d3.min.js"></script> 
<script src="admin/assets/vendor/rickshaw/rickshaw.min.js"></script>
<script src="admin/assets/vendor/flot/jquery.flot.js"></script> 
<script src="admin/assets/vendor/flot/jquery.flot.resize.js"></script>
<script src="admin/assets/vendor/flot/jquery.flot.categories.js"></script> 
<script src="admin/assets/vendor/flot/jquery.flot.pie.js"></script>
<script src="admin/assets/scripts/pages/dashboard.fe7e077d.js"></script> 
<script type="text/javascript"></script>
	  
<script>
$(document).ready(function(){
	//alert("hi");
	 $("#form-login").submit(function(){	
		var login_id	= $("#login_id").val();
		var password	= $("#password").val();
		if(login_id !="" && password !=""){
			$.ajax({
				url: "ajax/admin_login.php?&login_id="+login_id+"&password="+password,
				async: false,
				success: function(userData) {
					userData	= $.parseJSON(userData);
					if(userData.status=='failure'){
						//alert(userData.msg);
						swal("OOPS!", userData.msg, "error");
					}else{
						//swal("Woohoo!", userData.msg, "success");
						location.href = 'admin/dashboard.php';
					}
				}

				
			});
		}
		return false;
	});
	
	
	$("#user-form-login").submit(function(){	
		var emp_id	= $("#emp_id").val();
		var emp_password	= $("#emp_password").val();
		//alert(emp_id+'==='+password); 
		if(emp_id !="" && password !=""){
			$.ajax({
				url: "ajax/user_login.php?&emp_id="+emp_id+"&password="+emp_password,
				async: false,
				success: function(userData) {
					userData	= $.parseJSON(userData);
					if(userData.status=='failure'){
						//alert(userData.msg);
						swal("OOPS!", userData.msg, "error");
					}else{
						//swal("Woohoo!", userData.msg, "success");
						location.href = 'admin/user-dashboard.php';
					}
				}

				
			});
		}
		return false;
	});
});

</script>