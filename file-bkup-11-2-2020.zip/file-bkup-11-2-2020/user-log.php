<?php
ob_start();
include('inc/header.php'); 
				  
$admin_detail_data=array();
$admin_detail_result = mysqli_query($con,"SELECT * from tbl_admin");
while($active_employee_row = mysqli_fetch_assoc($admin_detail_result)) { 
	$admin_detail_data[$active_employee_row["user_id"]]=$active_employee_row["first_name"].' '.$active_employee_row["last_name"];
	}
?>

    
<div class="content-wrapper" style="min-height: 312px;">
		<section class="content-header">
				  <h1 style="">
			User's log <?php echo ($admin_detail_data[$_GET[user_id]] ? " of ".$admin_detail_data[$_GET[user_id]] :""); ?>
			<small></small>
		  </h1>
		  <ol class="breadcrumb">
			<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
			<li><a href="#">User's log</a></li>
		  </ol>
		</section>

        <!-- START PAGE CONTENT -->
        <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
					<div class="pull-left">
                      <h2 class="text-success no-margin"></h2>
					  
					  <div class="col-md-12">
							<form action="" id ="request_vaction_form" method="" class="filter-form">
										
											<div class="form-group form-group-default col-md-8">		
												<label>Select admin to see His log</label>
												<select name="user_id" id="employee_filter_select" class="select2" required="required" class="form-control">
													<option value="" >Select an admin</option>
													<?php 
													foreach($admin_detail_data as $admin_id=>$admin_name){
														?>
														<option value="<?php echo $admin_id; ?>"><?php echo $admin_name; ?></option>
														<?php
													}
													?>
												</select>
											</div>
										
										<div class="form-group form-group-default col-md-2">
											<label class="col-md-12">&nbsp;</label>
											<input type="hidden" name="user_type" value="admin">
											<button id="apply_filter" name="apply_filter" class="btn btn-primary btn-cons"><i class="fa fa-eye"></i> View log</button>
											
										</div>
										
							</form>	
										
						</div>
						
                    </div>
                    
					<div class="pull-right">
					  <div class="col-xs-12">
						<?php if($_SESSION["user_type"] == "Employee"){ ?>
							<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">Request for a vacation</button>
						<?php } ?>
					  </div>
					</div>
            </div>
            <!-- /.box-header -->
	<div class="box-body">	
		<div class="col-sm-12">
			<table id="datatable1" class="table table-striped table-bordered" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Event</th>
            </tr>
        </thead>
        <tbody>
		<?php 
		$user_log = file_get_contents(PATH."/cache/user_event_log/".$_GET[user_type]."/".$_GET[user_id]."");
		$user_log = explode("\n",$user_log);
		$user_log = array_reverse($user_log);
		 foreach($user_log as $user_log_row){ 
				
				$user_log_row = json_decode($user_log_row, TRUE);
				if(!isset($user_log_row["event_desc"]) || $user_log_row["event_desc"] =="")
					continue;
			?>
			<tr>
					<td><?php echo $user_log_row["date_time"]; ?> - <?php echo $admin_detail_data[$_GET[user_id]] ?> has <?php echo $user_log_row["event_desc"]; ?>.</td>
			</tr>		
		<?php }?>
        </tbody>
    </table>
	</div>
	</div>
	</div>
	</div>
	</div>
</div>
<?php
include('inc/footer.php'); 
?>