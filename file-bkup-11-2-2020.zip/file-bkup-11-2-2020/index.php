<?php
//print_r($_SERVER); die();
if($_SERVER["HTTP_X_FORWARDED_PROTO"] != "https") {  
//    header('Location: https://www.neptunetimesheets.com/');
//    exit();
}
require_once('config/config.php');
if($_REQUEST["action"] == "logout" ) {
    unset($_SESSION['user_type']);
    session_unset();
    session_destroy();
}
if(($_SESSION['user_type'])) {
    header("location:".PATH."/admin-v2/dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>Neptune - Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link rel="stylesheet" href="<?php echo MAIN_URL ?>assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo MAIN_URL ?>assets/plugins/sweetalert/sweetalert.css">
    <link rel="stylesheet" href="<?php echo MAIN_URL ?>assets/pages.css">
    <!--[if lte IE 9]>
    <link href="<?php echo MAIN_URL ?>assets/pages/css/ie9.css" rel="stylesheet" type="text/css" />
    <![endif]-->
    <script type="text/javascript">
        window.onload = function() {
            if (navigator.appVersion.indexOf("Windows NT 6.2") != -1)
                document.head.innerHTML += '<link rel="stylesheet" type="text/css" href="<?php echo MAIN_URL ?>assets/pages/css/windows.chrome.fix.css" />'
        }
    </script>
    <style>
        .login-wrapper .bg-caption {width: 38%;}
    </style>
</head>
<body class="fixed-header">
<div class="login-wrapper">
    <div class="bg-pic">
        <img src="<?php echo MAIN_URL ?>assets/background-new.jpg" alt="" class="lazy">
        <div class="bg-caption pull-bottom sm-pull-bottom text-white p-l-20 m-b-20">
            <h2 class="semi-bold text-white">
                Welcome to NEPTUNE!</h2>
            <p class="small">
                We look forward to keeping your family, property and business more secure. Explore this site to learn more about how Neptune Security’s experienced security guards, advanced Alarm Monitoring and Operations Centre, and security technologies can give you peace of mind.
            </p>
        </div>
    </div>
    <div class="login-container bg-white">
        <div class="p-l-50 m-l-20 p-r-50 m-r-20 p-t-50 m-t-30 sm-p-l-15 sm-p-r-15 sm-p-t-40">
            <h6 class="text-center">
                <img src="<?php echo MAIN_URL ?>assets/logo.png" alt="logo" data-src="<?php echo MAIN_URL ?>assets/logo.png" data-src-retina="<?php echo MAIN_URL ?>assets/logo.png" style="width:30%">
            </h6>
            <p class="p-t-35">Sign in into your Neptune account</p>
            <form id="form-login" class="p-t-15" role="form" action="">
                <div class="form-group form-group-default">
                    <label>Login ID</label>
                    <div class="controls">
                        <input type="text" name="login_id" id="login_id" placeholder="Login ID" class="form-control" required>
                    </div>
                </div>
                <div class="form-group form-group-default">
                    <label>Password</label>
                    <div class="controls">
                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                    </div>
                </div>
        </div>
        <div class="col-md-12 text-center">
            <h5>login as </h5>
            <input type="hidden" id="user_type">
            <input type="submit" name="login" value="Admin" class="btn btn-info btn-cons m-t-10">
            <input type="submit" name="login" value="Supervisor" class="btn btn-complete btn-cons m-t-10">
            <input type="submit" name="login" value="Employee" class="btn btn-danger btn-cons m-t-10">
        </div>
        </form>
        <div class="pull-bottom sm-pull-bottom">
            <div class="m-b-30 p-r-80 sm-m-t-20 sm-p-r-15 sm-p-b-20 clearfix">
                <div class="col-sm-3 col-md-2 no-padding">
                </div>
                <div class="col-sm-9 no-padding m-t-10">
                    <p>
                        Download Manual | <a href="<?php echo MAIN_URL; ?>assets/manual/Manual%20in%20English.pdf?forcedownload=1"  download="Manual in English.pdf">English</a> | <a href="<?php echo MAIN_URL; ?>assets/manual/Manual%20in%20French.pdf?forcedownload=1"  download="Manual in French.pdf">French</a>
                    </p>
                    <p>
                        Download mobile app  <a href="neptune-v2-1.apk" download="neptune-v2-1.apk"><img style="width: 38%;" src="android.jpg"></a>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="<?php echo MAIN_URL ?>assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo MAIN_URL ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo MAIN_URL ?>assets/plugins/jquery-validation/js/jquery.validate.min.js"></script>
<script src="<?php echo MAIN_URL ?>assets/plugins/sweetalert/sweetalert.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/script.js/2.5.8/script.min.js" type="text/javascript"></script>
<script>
    $(function() {
        $('#form-login').validate()
    })
</script>
</body>
</html>
<script>
    $(document).ready(function() {
        $(":submit").click(function () { $("#user_type").val(this.value); });
        $("#form-login").submit(function(){
            var login_id	= $("#login_id").val();
            var password	= $("#password").val();
            var user_type	= $("#user_type").val();
            if(login_id !="" && password !=""  && user_type !="" ){
                $.ajax({
                    url: "ajax/login.php?&login_id="+login_id+"&password="+password+"&user_type="+user_type,
                    async: false,
                    success: function(userData) {
                        userData	= $.parseJSON(userData);
                        if(userData.status=='failure'){
                            //alert(userData.msg);
                            swal("OOPS!", userData.msg, "error");
                        }else if(userData.response_data.admin_type == "Server Manager"){
                            location.href = '<?php echo MAIN_URL ?>disaster-management-solution/';
                        }else{
                            location.href = '<?php echo MAIN_URL ?>dashboard.php';
                           // alert(location.href);
                        }
                    }
                });
            }
            return false;
        });
    });
</script>
