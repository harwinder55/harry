<?php
/*
 * Template Name: Home page
 * */
	get_header();
 ?>
<div class="background-image-class">
	<div class="all-title-class">
	<?php
		$title = get_field('first_image_title');
	?>
		<div class="first-title-class">
			<h2><?php echo $title[0]['main_title'];?></h2>
		</div>
		<div class="second-title-class">
			<h2><?php echo $title[1]['main_title'];?></h2>
		</div>
		<div class="third-title-class">
			<h2><?php echo $title[2]['main_title'];?></h2>
		</div>
		<img class="gif-file-class" src="<?php bloginfo('template_directory');?>/images/chef-animation-final.gif">
	</div>
</div>
<div class="about-class">
	<!--<h3><strong><?php //echo get_field('about_us');?></strong></h3>-->
	<div>
		<h3><strong class="title_bg"><?php echo get_field('about_us');?></strong></h3>
		<!--img src="<?php bloginfo('template_directory');?>/images/about.png"-->
	</div>
	<div>
		<span><?php echo get_field('about_us_content');?></span>
	</div>
</div>
<div class="order-now-class">
	<div class="row">
		<div class="col-md-6 inner-col order-images-class" style="background-image:url('<?php echo get_field('touranga_images');?>')">
			<div class="touranga-class">
				<h3><?php echo get_field('order_by_touranga');?></h3>
				<a href="<?php echo get_field('order_now');?>"><strong>Order Now</strong></a>
			</div>
		</div>
		<div class="col-md-6 inner-col order-images-oto-class" style="background-image:url('<?php echo get_field('otorohanga_images');?>')">
			<div class="otorohanga-class">
				<h3><?php echo get_field('order_by_otorohanga');?></h3>
				<a href="<?php echo get_field('order_now_oto');?>"><strong>Order Now</strong></a>
			</div>
		</div>
	</div>
</div>
<div class="chef-special-class">
	<div class="chef-special-class" style="background-image:url('<?php bloginfo('template_directory');?>/images/chef-special.png')">
		<h3><?php echo get_field('chef_special');?></h3>
		<!--<img src="<?php //bloginfo('template_directory');?>/images/chef-special-design.png">-->
	</div>
</div>
<table class="chicken-table-class"><?php $chef = get_field('chef_special_rep');	?>
	<tr>
		<td class="punjabi-chicken-class" style="background-image:url('<?php echo $chef[0]['chef_images'];?>')">
			<a class="punjabi-chicken" href="<?php echo $chef[0]['chef_url'];?>"><strong>Punjabi Chicken</strong></a>
		</td>
		<td class="chef-images-class" style="background-image:url('<?php echo $chef[2]['chef_images'];?>')" rowspan="2">
		</td>
		<td class="drueken-chicken-class" style="background-image:url('<?php echo $chef[3]['chef_images'];?>')">
			<a class="punjabi-chicken" href="<?php echo $chef[3]['chef_url'];?>"><strong>Drunken Chicken</strong></a>
		</td>
		<td class="cort-chicken-class" style="background-image:url('<?php echo $chef[4]['chef_images'];?>')">
			<a class="punjabi-chicken" href="<?php echo $chef[4]['chef_url'];?>"><strong>Goat Curry</strong></a>
		</td>
	</tr>
	<tr>

		<td class="punjabi-chicken-class" style="background-image:url('<?php echo $chef[1]['chef_images'];?>')">
			<a class="punjabi-chicken" href="<?php echo $chef[1]['chef_url'];?>"><strong>Malayi Kofta</strong></a>
		</td>
		<td class="chej-special-content" colspan="2">
			<h3 class="chej-special-content-class"><strong><?php echo get_field('chef_title');?></strong></h3><br>
			<span class="chej-special-content-class"><?php echo get_field('chef_content');?></span>
		</td>
	</tr>
</table>
<div class="menu-image-class">
	<h3><strong class="title_bg">Menu</strong></h3>
	<!--img src="<?php bloginfo('template_directory');?>/images/menu.png"-->
</div>
<div class="background-image-padding-class">
	<div class="menu-cards-class" style="background-image:url('<?php bloginfo('template_directory');?>/images/menu-back.jpg')">
	<div class="animate-image-class">
		<img src="<?php bloginfo('template_directory');?>/images/animate-dish.png">
	</div>
		<div class="container-fluid menu-card-class">
		<?php
			$menucard = get_field('menu_card');
		?>
			<div class="row row-menu-class">
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[0]['menu_images'];?>">
					<h3><?php echo $menucard[0]['menu_title'];?></h3>
					<p><?php echo $menucard[0]['menu_content'];?></p>
				</div>
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[1]['menu_images'];?>">
					<h3><?php echo $menucard[1]['menu_title'];?></h3>
					<p><?php echo $menucard[1]['menu_content'];?></p>
				</div>
			</div>
			<div class="row row-menu-class">
				<div class="col-lg-4 col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[2]['menu_images'];?>">
					<h3><?php echo $menucard[2]['menu_title'];?></h3>
					<p><?php echo $menucard[2]['menu_content'];?></p>
				</div>
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[3]['menu_images'];?>">
					<h3><?php echo $menucard[3]['menu_title'];?></h3>
					<p><?php echo $menucard[3]['menu_content'];?></p>
				</div>
			</div>
			<div class="row row-menu-class">
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[4]['menu_images'];?>">
					<h3><?php echo $menucard[4]['menu_title'];?></h3>
					<p><?php echo $menucard[4]['menu_content'];?></p>
				</div>
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[5]['menu_images'];?>">
					<h3><?php echo $menucard[5]['menu_title'];?></h3>
					<p><?php echo $menucard[5]['menu_content'];?></p>
				</div>
			</div>
			<div class="row row-menu-class">
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[6]['menu_images'];?>">
					<h3><?php echo $menucard[6]['menu_title'];?></h3>
					<p><?php echo $menucard[6]['menu_content'];?></p>
				</div>
				<div class="col-md-4 col-xm-12 dahi-de-kebab">
					<img src="<?php echo $menucard[7]['menu_images'];?>">
					<h3><?php echo $menucard[7]['menu_title'];?></h3>
					<p><?php echo $menucard[7]['menu_content'];?></p>
				</div>

			</div>
		</div>
		<div class="read-more-btn-class">
			<a class="read-more-class" href="<?php echo get_the_permalink(1183);?>" target="_blank">Read More</a>
		</div>
	</div>
</div>
<div class="booking-form-class" style="background-image:url('<?php bloginfo('template_directory');?>/images/Dinner-Background-01.jpg')">
	<div class="container booking-background-color-class">
		<div class="row">
			<div class="col-md-4 col-xm-12 book-a-now col-lg-4">
			<h3>Book Now</h3>
				<!--form>
					<input type="text" name="Name" placeholder="NAME"><br><br>
					<input type="text" name="Telephone" placeholder="TELEPHONE"><br><br>
					<input type="text" name="date" placeholder="12/6/2019"><br><br>
					<input type="text" name="guest" placeholder="NUMBER OF GUEST"><br><br>
					<input class="booking-submit-class" type="submit" name="submit" value="SUBMIT">
				</form-->
				<?php echo do_shortcode('[booking-form]');?>
			</div>
			<div class="col-md-4 col-xm-12 images-contact-class col-lg-4">
				<img class="responsives" src="<?php echo get_field('contact_images');?>">
			</div>
			<div class="col-md-4 col-xm-12 contact-and-email col-lg-4">
				<?php $contact =  get_field('contact_us'); ?>
				<h2>Contact us</h2>
				<span>Phone:</span><br>
				<span><?php echo $contact[0]['contact_and_address'];?></span><br>
				<span><?php echo $contact[1]['contact_and_address'];?></span><br><br>

				<span>Email:</span><br>
				<span><?php echo $contact[2]['contact_and_address'];?></span><br><br>

				<h2>Working Hours</h2>
				<?php $working_hours = get_field('working_hours'); ?>
				<?php echo $working_hours; ?>
			</div>
		</div>
	</div>
	<div class="animation-image-class">
		<!--img src="<?php bloginfo('template_directory');?>/images/img1.png"> 
		<img src="<?php bloginfo('template_directory');?>/images/img2.png"> 
		<img src="<?php bloginfo('template_directory');?>/images/img3.png"> 
		<img src="<?php bloginfo('template_directory');?>/images/img4.png"> 
		<img src="<?php bloginfo('template_directory');?>/images/img5.png"> 
		<img src="<?php bloginfo('template_directory');?>/images/castle91-cook.gif" /-->
	</div>
	<div class="animation-image-cook">
		<img src="<?php bloginfo('template_directory');?>/images/castle91-cook.gif" />
		<span class="animate-cook-text">We do outdoor catering <a class="animated tada" href="tel:64221615476"><i class="fa fa-phone"></i> Call Now</a></span>
	</div>
</div>
<?php get_footer(); ?>
