<a href="itms-services://?action=download-manifest&url=https://gitlab.com/programmersujeet/neptune-app-build/raw/master/manifest.plist">Download Appppppp!</a>
